# ADIMS: Ameen Digitech Integrated Management System

Enterprise management platform for Ameen Digitech Ltd covering Research and Data Analysis, Digital Skills Training and Digital Services for small businesses.

Currency: NGN (stored as integer kobo). Time zone: Africa/Lagos.

## Status

All 12 modules are implemented at API level (about 100 tables, 105 routes, 20 roles, 155 permissions), with a Next.js web app, an Expo mobile shell, shared packages, Docker, CI and docs.

**Honest caveat: nothing has been executed yet.** The code was written in an environment without network access, so it was only linted/parsed statically. Run `./infrastructure/scripts/setup.sh`, then the test suites, before relying on it.

Known gaps: mobile attendance screen is a stub; SMS/WhatsApp/push are log-driver placeholders; bank reconciliation UI, ODK sync and phone verification are not built. See `docs/architecture/roadmap.md`.

## Key rules enforced
Integer-kobo money; two distinct approvers above the configurable threshold (default NGN 100,000); a receipt is never proof of payment; dashboards read real records; confidential datasets never public; public certificate verification shows approved fields only; unique project references; configurable deposit (default 50%).

## Repo map
`apps/api` Laravel API · `apps/web` Next.js · `apps/mobile` Expo · `packages/*` shared code · `infrastructure` Docker/scripts · `tools/schema` generator · `docs` architecture, API, DB, security, deployment, guides.

## Stack

Next.js + TypeScript + Tailwind (web), Laravel + PHP (API), PostgreSQL, Redis, S3-compatible private storage, React Native + Expo (mobile), Docker.

## Getting started

```bash
cp .env.example .env
docker compose up -d --build
docker compose exec api composer install
docker compose exec api php artisan key:generate
docker compose exec api php artisan migrate --seed
npm install            # workspaces: web, mobile, packages
npm run dev:web
```

Web: http://localhost:3000 · API: http://localhost:8080/api/v1 · Mailpit: http://localhost:8025 · MinIO console: http://localhost:9001

Run backend tests: `docker compose exec api php artisan test`

## Repository map

- `apps/web`: Next.js application (feature-based structure).
- `apps/api`: Laravel API (Actions, Services, Policies, Enums, DTOs).
- `apps/mobile`: Expo application.
- `packages/*`: shared types, API contracts, validation schemas, design tokens, utilities.
- `infrastructure/`: Docker, Nginx, deployment scripts.
- `docs/`: architecture, database, security, API and deployment documentation.

## Key engineering rules

1. Money is integer kobo, never floats. See `apps/api/app/Support/Money.php`.
2. Authorisation is enforced on the backend by policies and permission middleware; hiding menu items is cosmetic only.
3. Any financial transaction above the configured threshold (default ₦100,000) needs two distinct approvers, neither of whom is the requester. See `ApprovalService`.
4. An uploaded transfer receipt never marks an invoice paid. Only a verified payment does.
5. Confidential datasets live in private object storage and are served via short-lived signed URLs after a permission check.
6. Dashboard figures are computed from real records; no seeded fake statistics.
