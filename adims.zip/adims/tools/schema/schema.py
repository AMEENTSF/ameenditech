# Compact schema DSL. Column: "type:name[opts]"
# types: s(string) s30(string len) t(text) i(unsigned int) si(small) bi(bigint) k(kobo) d(date) dt(timestamp)
#        b(bool) j(json) dec(decimal 5,2) f(foreignId, name>table) u(uuid)
# opts: ?=nullable  =val default  #=index  !=unique  *=cascade(fk)  {a,b}=enum
# Table tuple: (group, table, module, perm_resource, [cols], flags)
# flags: soft, readonly, existing, uniq=[[..]], idx=[[..]], search=[..], check=[sql]
G = []
def T(group, table, module, res, cols, **flags):
    G.append(dict(group=group, table=table, module=module, res=res, cols=cols, **flags))

# ---------------- CRM ----------------
T('crm','organisations','crm','organisations',[
 's:name#','s:type?{company,ngo,government,school,other}','s:registration_number?','s:email?','s30:phone?','t:address?','s:state?','s:website?','s:category?',
 'f:created_by>users?'], soft=True, search=['name','email'])
T('crm','enquiries','crm','enquiries',[
 's:reference!','f:contact_id>contacts','f:organisation_id>organisations?','s:service_line={research,training,digital_services,other}#',
 's:subject','t:message?','s:source?={web,phone,walk_in,referral,social,other}','s:status=new{new,contacted,qualified,quoted,won,lost}#',
 'f:assigned_to>users?','dt:converted_at?','dt:follow_up_at?#'], search=['reference','subject'])
T('crm','opportunities','crm','enquiries',[
 'f:enquiry_id>enquiries*','s:title','k:value_kobo?','s:stage=prospect{prospect,proposal,negotiation,won,lost}#','d:expected_close_on?','f:owner_id>users?'])
T('crm','communications','crm','contacts',[
 'f:contact_id>contacts*','s:channel{email,phone,sms,whatsapp,meeting,note}','s:direction=outbound{inbound,outbound}','s:subject?','t:body?','f:logged_by>users?','dt:occurred_at',
 'dt:follow_up_at?#','b:follow_up_done=false'])
T('crm','customer_notes','crm','contacts',['f:contact_id>contacts*','t:body','f:author_id>users?'])
T('crm','customer_feedback','crm','contacts',['f:contact_id>contacts*','s:subject_type?','i:subject_id?','si:rating','t:comment?'])
T('crm','quotations','crm','quotations',[
 's:number!','f:contact_id>contacts','f:enquiry_id>enquiries?','s:service_line','s:title','k:total_kobo','s:status=draft{draft,sent,accepted,rejected,expired}#',
 'i:revision=1','d:valid_until?','dt:accepted_at?','f:created_by>users?','j:lines?'], search=['number','title'])

# ---------------- Research ----------------
T('research','research_projects','research','projects',[
 's:reference!','f:client_contact_id>contacts','s:title','t:scope?','s:stage=enquiry#','k:quoted_kobo?','si:deposit_basis_points=5000','k:deposit_kobo?','f:manager_id>users?','d:due_on?#','dt:closed_at?'],
 existing=True, search=['reference','title'])
T('research','datasets','research','datasets',['f:research_project_id>research_projects*','f:file_id>files','s:label','s:classification=confidential'], existing=True)
T('research','project_quotes','research','projects',[
 'f:research_project_id>research_projects*','i:revision=1','k:amount_kobo','t:scope_summary?','s:status=draft{draft,sent,accepted,rejected,superseded}#','dt:accepted_at?','f:created_by>users?'],
 uniq=[['research_project_id','revision']])
T('research','project_tasks','research','projects',[
 'f:research_project_id>research_projects*','s:title','t:description?','s:status=todo{todo,in_progress,blocked,done}#','s:phase?{scope,design,collection,cleaning,analysis,reporting,review}','f:assignee_id>users?','d:due_on?#','dt:completed_at?'])
T('research','project_team_members','research','projects',[
 'f:research_project_id>research_projects*','f:user_id>users*','s:project_role'], uniq=[['research_project_id','user_id']])
T('research','survey_forms','research','projects',[
 'f:research_project_id>research_projects*','s:title','s:odk_form_id?','s:status=draft{draft,active,closed}'])
T('research','survey_versions','research','projects',[
 'f:survey_form_id>survey_forms*','i:version','j:definition?','f:file_id>files?','dt:published_at?','f:created_by>users?'], uniq=[['survey_form_id','version']])
T('research','field_assignments','research','projects',[
 'f:survey_version_id>survey_versions*','f:enumerator_id>users','f:supervisor_id>users?','s:area?','i:target_count?','s:status=assigned{assigned,in_field,completed}'])
T('research','survey_submissions','research','projects',[
 'f:field_assignment_id>field_assignments*','s:external_id?!','j:payload?','s:status=received{received,accepted,flagged,rejected}#','dt:collected_at?','dt:synced_at?','dec:gps_accuracy?'])
T('research','deliverables','research','deliverables',[
 'f:research_project_id>research_projects*','s:title','i:version=1','f:file_id>files?','s:status=draft{draft,in_review,approved,delivered,superseded}#','f:created_by>users?','dt:delivered_at?'])
T('research','quality_reviews','research','deliverables',[
 'f:deliverable_id>deliverables*','f:reviewer_id>users','s:outcome{approved,changes_requested}','t:comments?','dt:reviewed_at'])
T('research','project_feedback','research','projects',[
 'f:research_project_id>research_projects*','f:contact_id>contacts?','si:rating','t:comment?'])

# ---------------- Training ----------------
T('training','courses','training','courses',[
 's:slug!','s:title','t:description?','k:fee_kobo','si:duration_weeks','s:status=draft#'], existing=True)
T('training','course_categories','training','courses',['s:name!','t:description?'])
T('training','course_prerequisites','training','courses',['f:course_id>courses*','f:prerequisite_course_id>courses*'], uniq=[['course_id','prerequisite_course_id']])
T('training','course_modules','training','courses',['f:course_id>courses*','s:title','t:outline?','si:position=0','si:hours?'])
T('training','cohorts','training','courses',['f:course_id>courses','s:name','d:starts_on','d:ends_on?','si:capacity?'], existing=True)
T('training','cohort_instructors','training','courses',['f:cohort_id>cohorts*','f:user_id>users*'], uniq=[['cohort_id','user_id']])
T('training','rooms','training','courses',['s:name!','si:capacity?','s:location?'])
T('training','class_sessions','training','attendance',[
 'f:cohort_id>cohorts*','f:course_module_id>course_modules?','f:room_id>rooms?','f:instructor_id>users?','dt:starts_at#','dt:ends_at','s:topic?','s:status=scheduled{scheduled,held,cancelled}'])
T('training','applications','training','applications',[
 's:reference!','f:contact_id>contacts','f:course_id>courses','f:cohort_id>cohorts?','s:status=submitted{submitted,under_review,admitted,waitlisted,declined,withdrawn}#','t:statement?','f:decided_by>users?','dt:decided_at?','t:decision_note?'])
T('training','enrolments','training','enrolments',['f:cohort_id>cohorts','f:contact_id>contacts','s:status=enrolled#'], existing=True)
T('training','enrolment_instalments','training','enrolments',[
 'f:enrolment_id>enrolments*','f:invoice_id>invoices?','i:sequence','k:amount_kobo','d:due_on#','s:status=pending{pending,paid,overdue,waived}'], uniq=[['enrolment_id','sequence']])
T('training','attendance_records','training','attendance',[
 'f:class_session_id>class_sessions*','f:enrolment_id>enrolments*','s:status{present,absent,late,excused}','f:recorded_by>users?','dt:recorded_at?'], uniq=[['class_session_id','enrolment_id']])
T('training','laptop_allocations','training','enrolments',['f:cohort_id>cohorts*','f:enrolment_id>enrolments*','f:asset_id>assets','d:allocated_on','d:returned_on?'])
T('training','learning_resources','training','courses',['f:course_module_id>course_modules*','s:title','s:kind{document,video,link,exercise}','f:file_id>files?','s:url?','b:published=true'])
T('training','assignments','training','assessments',['f:cohort_id>cohorts*','s:title','t:instructions?','dt:due_at?','si:max_score=100'])
T('training','assessments','training','assessments',['f:cohort_id>cohorts*','s:title','s:kind{quiz,practical,project,presentation,exam}','si:max_score=100','si:weight_percent=0','dt:held_at?'])
T('training','assessment_results','training','assessments',[
 'f:assessment_id>assessments*','f:enrolment_id>enrolments*','dec:score','t:feedback?','f:graded_by>users?','dt:graded_at?'], uniq=[['assessment_id','enrolment_id']])
T('training','assignment_submissions','training','assessments',[
 'f:assignment_id>assignments*','f:enrolment_id>enrolments*','f:file_id>files?','t:notes?','dec:score?','dt:submitted_at'], uniq=[['assignment_id','enrolment_id']])
T('training','certificates','training','certificates',['f:enrolment_id>enrolments','s:verification_number!','dt:issued_at','f:issued_by>users?','dt:revoked_at?'], existing=True)
T('training','alumni_records','training','enrolments',['f:contact_id>contacts!','f:enrolment_id>enrolments?','s:current_employer?','s:current_role?','b:open_to_mentoring=false','b:consent_to_contact=false'])

# ---------------- Digital services ----------------
T('services','service_catalogue','services','projects',[
 's:slug!','s:name','t:description?','s:category?{website,social_media,branding,marketing,digitalisation,maintenance,support}','k:base_price_kobo?','b:active=true'],
 model='ServiceCatalogueItem')
T('services','service_projects','services','projects',[
 's:reference!','f:contact_id>contacts','f:service_catalogue_id>service_catalogue?','f:quotation_id>quotations?','s:title','s:status=draft{draft,agreed,in_progress,client_review,completed,on_hold,cancelled}#',
 'f:project_manager_id>users?','k:agreed_kobo?','d:starts_on?','d:due_on?#','dt:agreement_accepted_at?','dt:completed_at?'], search=['reference','title'])
T('services','service_tasks','services','projects',['f:service_project_id>service_projects*','s:title','t:description?','s:status=todo{todo,in_progress,blocked,done}#','f:assignee_id>users?','d:due_on?'])
T('services','milestones','services','projects',[
 'f:service_project_id>service_projects*','s:title','d:due_on?','k:amount_kobo?','s:status=pending{pending,in_progress,submitted,approved,rejected}#','f:approved_by_contact_id>contacts?','dt:approved_at?'])
T('services','support_tickets','services','tickets',[
 's:reference!','f:contact_id>contacts','f:service_project_id>service_projects?','f:care_plan_id>care_plans?','s:subject','t:description?','s:priority=normal{low,normal,high,urgent}','s:status=open{open,in_progress,waiting_client,resolved,closed}#','f:assignee_id>users?','dt:resolved_at?'], search=['reference','subject'])
T('services','ticket_replies','services','tickets',['f:support_ticket_id>support_tickets*','f:author_id>users?','t:body','b:internal=false'])
T('services','care_plans','services','care_plans',[
 'f:contact_id>contacts','s:name','s:tier?','k:monthly_fee_kobo','d:starts_on','d:renews_on#','s:status=active{active,paused,cancelled,expired}#','b:auto_renew=true'])
T('services','care_plan_renewals','services','care_plans',[
 'f:care_plan_id>care_plans*','f:invoice_id>invoices?','d:period_start','d:period_end','s:status=due{due,invoiced,paid,lapsed}#','dt:reminded_at?'])

# ---------------- Finance (supporting; invoices/payments/expenses handled by dedicated controllers) ----------------
T('finance','account_categories','finance','accounts',['s:name!','s:kind{income,expense,asset,liability,equity}'])
T('finance','accounts','finance','accounts',['s:code!','s:name','f:account_category_id>account_categories','f:parent_id>accounts?','b:active=true'])
T('finance','expense_categories','finance','expenses',['s:name!','f:account_id>accounts?','b:active=true'])
T('finance','bank_accounts','finance','bank',['s:name','s:bank_name?','s:account_number_last4?','s:kind=bank{bank,cash,petty_cash}','f:account_id>accounts?','k:opening_balance_kobo=0','b:active=true'])
T('finance','journal_entries','finance','accounts',['s:number!','d:entry_date#','s:memo?','s:source_type?','i:source_id?','f:posted_by>users?','dt:reversed_at?'], readonly=True)
T('finance','journal_entry_lines','finance','accounts',['f:journal_entry_id>journal_entries*','f:account_id>accounts','k:debit_kobo=0','k:credit_kobo=0'], readonly=True)
T('finance','reconciliations','finance','bank',['f:bank_account_id>bank_accounts','d:period_start','d:period_end','k:statement_balance_kobo','k:book_balance_kobo','s:status=open{open,reconciled}','f:reconciled_by>users?','dt:reconciled_at?'])
T('finance','petty_cash_entries','finance','bank',['f:bank_account_id>bank_accounts','s:description','k:amount_kobo','s:direction{in,out}','f:expense_id>expenses?','f:recorded_by>users?','d:entry_date'])
T('finance','supplier_invoices','finance','invoices',[
 's:number','f:supplier_id>suppliers','k:total_kobo','k:paid_kobo=0','s:status=received{received,pending_approval,approved,paid,rejected}#','d:received_on','d:due_on?#','f:file_id>files?'], uniq=[['supplier_id','number']])

# ---------------- HR ----------------
T('hr','departments','hr','staff',['s:name!','f:head_id>users?'])
T('hr','job_titles','hr','staff',['s:name!','f:department_id>departments?'])
T('hr','staff_profiles','hr','staff',[
 'f:user_id>users!','f:contact_id>contacts','s:staff_number!','f:department_id>departments?','f:job_title_id>job_titles?','f:line_manager_id>users?','s:employment_type{full_time,part_time,contract,intern,volunteer}',
 'd:hired_on','d:left_on?','s:status=active{active,on_leave,terminated}#'])
T('hr','employment_contracts','hr','staff',['f:staff_profile_id>staff_profiles*','s:contract_type','d:starts_on','d:ends_on?','f:file_id>files?','k:monthly_pay_kobo?'])
T('hr','leave_types','hr','leave',['s:name!','si:default_days','b:paid=true'])
T('hr','leave_requests','hr','leave',[
 'f:staff_profile_id>staff_profiles*','f:leave_type_id>leave_types','d:starts_on','d:ends_on','t:reason?','s:status=pending{pending,approved,rejected,cancelled}#','f:decided_by>users?','dt:decided_at?'])
T('hr','staff_assignments','hr','staff',['f:staff_profile_id>staff_profiles*','s:assignable_type','i:assignable_id','s:assignment_role?','d:starts_on?','d:ends_on?'])
T('hr','performance_reviews','hr','reviews',['f:staff_profile_id>staff_profiles*','f:reviewer_id>users','s:period','dec:rating?','t:strengths?','t:improvement_areas?','s:status=draft{draft,submitted,acknowledged}'])
T('hr','staff_training_records','hr','staff',['f:staff_profile_id>staff_profiles*','s:title','s:provider?','d:completed_on?','f:file_id>files?'])
T('hr','staff_attendance','hr','staff',['f:staff_profile_id>staff_profiles*','d:work_date#','dt:clock_in?','dt:clock_out?'], uniq=[['staff_profile_id','work_date']], model='StaffAttendanceRecord')
T('hr','payroll_inputs','hr','staff',['f:staff_profile_id>staff_profiles*','s:period','s:kind{base,allowance,deduction,bonus,overtime}','s:label','k:amount_kobo','s:status=draft{draft,approved,exported}'])

# ---------------- Procurement & assets ----------------
T('procurement','suppliers','procurement','orders',['s:name#','s:email?','s30:phone?','t:address?','s:tax_id?','s:status=active{active,blocked}'], soft=True, search=['name'])
T('procurement','purchase_requests','procurement','requests',[
 's:reference!','f:requested_by>users','f:department_id>departments?','s:title','t:justification?','k:estimated_kobo','s:status=draft{draft,pending_approval,approved,rejected,ordered}#'])
T('procurement','purchase_orders','procurement','orders',[
 's:number!','f:supplier_id>suppliers','f:purchase_request_id>purchase_requests?','k:total_kobo','s:status=draft{draft,pending_approval,approved,sent,partially_received,received,cancelled}#','d:expected_on?','f:created_by>users?'])
T('procurement','purchase_order_lines','procurement','orders',['f:purchase_order_id>purchase_orders*','f:inventory_item_id>inventory_items?','s:description','i:quantity','k:unit_price_kobo','i:received_quantity=0'])
T('procurement','goods_receipts','procurement','orders',['f:purchase_order_id>purchase_orders','s:number!','d:received_on','f:received_by>users?','t:notes?'])
T('procurement','goods_receipt_lines','procurement','orders',['f:goods_receipt_id>goods_receipts*','f:purchase_order_line_id>purchase_order_lines','i:quantity'])
T('procurement','inventory_items','procurement','assets',['s:sku!','s:name','s:unit=each','i:quantity_on_hand=0','i:reorder_level=0'])
T('procurement','stock_movements','procurement','assets',['f:inventory_item_id>inventory_items','s:kind{receipt,issue,adjustment,return}','i:quantity','s:reason?','f:recorded_by>users?'])
T('procurement','assets','procurement','assets',[
 's:tag!','s:name','s:category{laptop,projector,furniture,network,vehicle,other}#','s:serial_number?','d:purchased_on?','k:cost_kobo?','s:condition=good{new,good,fair,poor}','s:status=available{available,assigned,maintenance,disposed}#','f:assignee_id>users?','s:location?','dt:disposed_at?','t:disposal_reason?'], soft=True, search=['tag','name'])
T('procurement','asset_movements','procurement','assets',['f:asset_id>assets*','s:kind{assign,return,transfer,disposal}','f:from_user_id>users?','f:to_user_id>users?','s:location?','f:recorded_by>users?'])
T('procurement','maintenance_records','procurement','assets',['f:asset_id>assets*','t:description','k:cost_kobo?','d:performed_on','d:next_due_on?','s:performed_by?'])

# ---------------- Governance & platform ----------------
T('governance','documents','governance','documents',[
 's:title','s:category{policy,procedure,contract,minutes,report,other}#','s:confidentiality=internal{public,internal,confidential,restricted}','f:owner_id>users?','i:current_version=1','d:review_on?','d:retain_until?','s:status=active{draft,active,archived}'], soft=True, search=['title'])
T('governance','document_versions','governance','documents',['f:document_id>documents*','i:version','f:file_id>files','t:change_note?','f:uploaded_by>users?'], uniq=[['document_id','version']])
T('governance','board_meetings','governance','documents',['s:title','dt:held_at','s:location?','t:agenda?','t:minutes?','f:minutes_file_id>files?','s:status=scheduled{scheduled,held,minuted}'])
T('governance','consents','governance','documents',['f:contact_id>contacts','s:purpose','s:status{granted,withdrawn}','s:source?','dt:recorded_at'])
T('governance','risks','governance','risks',['s:title','t:description?','si:likelihood','si:impact','s:status=open{open,mitigating,accepted,closed}','f:owner_id>users?','t:mitigation?','d:review_on?'])
T('governance','compliance_items','governance','risks',['s:title','d:due_on#','s:authority?','s:status=upcoming{upcoming,done,overdue}','f:owner_id>users?'])
T('governance','incidents','governance','incidents',['s:reference!','s:title','t:description?','s:severity=low{low,medium,high,critical}','s:status=reported{reported,investigating,resolved,closed}','f:reported_by>users?','dt:occurred_at?'])
T('platform','notification_templates','admin','settings',['s:code!','s:channel{in_app,email,sms,whatsapp,push}','s:subject?','t:body','b:active=true'], uniq=[])
T('platform','notifications','admin','settings',[
 'f:user_id>users?','f:contact_id>contacts?','f:notification_template_id>notification_templates?','s:channel','s:subject?','t:body','s:status=queued{queued,sent,delivered,failed}#','s:provider_message_id?','t:failure_reason?','dt:sent_at?','dt:read_at?'], readonly=True)
T('platform','integration_events','admin','settings',['s:provider','s:event_type','s:external_id?','j:payload?','s:status=received{received,processed,failed}#','dt:processed_at?'], uniq=[['provider','external_id']])
