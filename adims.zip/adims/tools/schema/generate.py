import re, os, json, sys
sys.path.insert(0, os.path.dirname(__file__))
from schema import G
import pathlib
ROOT = pathlib.Path(__file__).resolve().parents[2]
API = str(ROOT / 'apps/api')
DOCS = str(ROOT / 'docs')

EXIST = {'users':'User','contacts':'Contact','files':'File','invoices':'Invoice','expenses':'Expense','payments':'Payment','roles':'Role'}
SINGULAR_OVERRIDE = {'service_catalogue':'ServiceCatalogueItem','attendance':'AttendanceRecord','project_feedback':'ProjectFeedback','customer_feedback':'CustomerFeedback','staff_attendance':'StaffAttendanceRecord'}
def studly(s): return ''.join(p.capitalize() for p in s.split('_'))
def singular(w):
    if w.endswith('ies'): return w[:-3]+'y'
    if w.endswith('sses'): return w[:-2]
    if w.endswith('ses') and not w.endswith('ases'): return w[:-2] if w.endswith('sses') else w[:-1]
    if w.endswith('s') and not w.endswith('ss'): return w[:-1]
    return w
def model_name(t, g=None):
    if g and g.get('model'): return g['model']
    if t in SINGULAR_OVERRIDE: return SINGULAR_OVERRIDE[t]
    parts = t.split('_'); parts[-1] = singular(parts[-1])
    return ''.join(p.capitalize() for p in parts)

TABLE2MODEL = dict(EXIST)
for g in G: TABLE2MODEL[g['table']] = model_name(g['table'], g)

PAT = re.compile(r'^([a-z0-9_]+)(?:>([a-z_]+))?([?#!*]*)(?:=([^{?#!*]*))?(\{[^}]*\})?([?#!*]*)$')
def parse(c):
    typ, rest = c.split(':',1)
    m = PAT.match(rest)
    assert m, c
    name, ref, f1, default, enum, f2 = m.groups()
    flags = f1 + f2
    return dict(type=typ, name=name, ref=ref, null='?' in flags, idx='#' in flags, uniq='!' in flags, cascade='*' in flags,
                default=default if default not in (None,'') else None, has_default=default not in (None,''),
                enum=enum[1:-1].split(',') if enum else None)

def col_php(c):
    t, n = c['type'], c['name']
    if t == 'f':
        line = f"$table->foreignId('{n}')"
        if c['null']: line += '->nullable()'
        line += f"->constrained('{c['ref']}')"
        line += '->cascadeOnDelete()' if c['cascade'] else ('->nullOnDelete()' if c['null'] else '->restrictOnDelete()')
        if c['uniq']: line += '->unique()'
        return line + ';'
    m = {'s':f"string('{n}')",'t':f"text('{n}')",'i':f"unsignedInteger('{n}')",'si':f"unsignedSmallInteger('{n}')",'bi':f"bigInteger('{n}')",
         'k':f"bigInteger('{n}')",'d':f"date('{n}')",'dt':f"timestamp('{n}')",'b':f"boolean('{n}')",'j':f"json('{n}')",'dec':f"decimal('{n}', 6, 2)",'u':f"uuid('{n}')"}
    if re.match(r's\d+$', t): m[t] = f"string('{n}', {t[1:]})"
    line = '$table->' + m[t]
    if c['null']: line += '->nullable()'
    if c['has_default']:
        d = c['default']
        if t == 'b': line += f"->default({d})"
        elif t in ('i','si','bi','k','dec'): line += f"->default({d})"
        else: line += f"->default('{d}')"
    if c['uniq']: line += '->unique()'
    elif c['idx']: line += '->index()'
    return line + ';'

def rule_for(c, table):
    t, n = c['type'], c['name']
    r = []
    r.append('nullable' if (c['null'] or c['has_default']) and not (c['has_default'] and not c['null']) else ('sometimes' if c['has_default'] else 'required'))
    if c['has_default'] or c['null']:
        r[0] = 'nullable' if c['null'] else 'sometimes'
    if t == 'f': r += ['integer', f"exists:{c['ref']},id"]
    elif t in ('s',) or re.match(r's\d+$', t): r += ['string', f"max:{t[1:] or 255}"]
    elif t == 't': r += ['string']
    elif t in ('i','si','bi'): r += ['integer','min:0']
    elif t == 'k': r += ['integer','min:0']
    elif t in ('d',): r += ['date']
    elif t == 'dt': r += ['date']
    elif t == 'b': r += ['boolean']
    elif t == 'j': r += ['array']
    elif t == 'dec': r += ['numeric']
    if c['enum']: r += ['in:' + ','.join(c['enum'])]
    return r

# ---------- ordering ----------
by_table = {g['table']: g for g in G}
deps = {}
for g in G:
    d = set()
    for c in map(parse, g['cols']):
        if c['type']=='f' and c['ref'] in by_table and c['ref']!=g['table'] and not by_table[c['ref']].get('existing'): d.add(c['ref'])
    deps[g['table']] = d
order, seen = [], set()
def visit(t, stack=()):
    if t in seen: return
    assert t not in stack, f'cycle {stack} {t}'
    for d in sorted(deps[t]): visit(d, stack+(t,))
    seen.add(t); order.append(t)
for g in G:
    if not g.get('existing'): visit(g['table'])

# ---------- migrations ----------
mig_dir = f'{API}/database/migrations'
for f in os.listdir(mig_dir):
    if f.startswith('2026_02_'): os.remove(f'{mig_dir}/{f}')
mig_index = []
for i, t in enumerate(order, 1):
    g = by_table[t]
    cols = [parse(c) for c in g['cols']]
    body = ['            $table->id();']
    body += ['            ' + col_php(c) for c in cols]
    body.append('            $table->timestamps();')
    if g.get('soft'): body.append('            $table->softDeletes();')
    for u in g.get('uniq', []): body.append("            $table->unique([" + ', '.join(f"'{x}'" for x in u) + "]);")
    for u in g.get('idx', []): body.append("            $table->index([" + ', '.join(f"'{x}'" for x in u) + "]);")
    extra = ''
    checks = []
    for c in cols:
        if c['type']=='k' and c['name'] not in ('opening_balance_kobo',) and not c['null']:
            pass
    if t == 'journal_entry_lines':
        checks.append("ALTER TABLE journal_entry_lines ADD CONSTRAINT jel_one_side CHECK ((debit_kobo > 0 AND credit_kobo = 0) OR (credit_kobo > 0 AND debit_kobo = 0))")
    if t in ('quality_reviews',): pass
    if t == 'project_feedback' or t == 'customer_feedback':
        checks.append(f"ALTER TABLE {t} ADD CONSTRAINT {t}_rating_range CHECK (rating BETWEEN 1 AND 5)")
    if t == 'risks':
        checks.append("ALTER TABLE risks ADD CONSTRAINT risks_scale CHECK (likelihood BETWEEN 1 AND 5 AND impact BETWEEN 1 AND 5)")
    if checks:
        extra = "\n        if (DB::getDriverName() === 'pgsql') {\n" + '\n'.join(f"            DB::statement('{c}');" for c in checks) + "\n        }"
    fname = f'2026_02_01_{i:06d}_create_{t}_table.php'
    php = f"""<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\DB;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{{
    public function up(): void
    {{
        Schema::create('{t}', function (Blueprint $table) {{
{chr(10).join(body)}
        }});{extra}
    }}

    public function down(): void
    {{
        Schema::dropIfExists('{t}');
    }}
}};
"""
    open(f'{mig_dir}/{fname}','w').write(php)
    mig_index.append((fname,t))
# FK from contacts.organisation_id -> organisations (+ constraint for existing tables referencing later tables)
n = len(order)+1
open(f'{mig_dir}/2026_02_01_{n:06d}_add_organisation_foreign_key_to_contacts.php','w').write("""<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('contacts', function (Blueprint $table) {
            $table->foreign('organisation_id')->references('id')->on('organisations')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('contacts', function (Blueprint $table) {
            $table->dropForeign(['organisation_id']);
        });
    }
};
""")
n += 1
open(f'{mig_dir}/2026_02_01_{n:06d}_create_reference_counters_table.php','w').write("""<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Gap-free yearly counters for human-readable references (ENQ-2026-0001 ...).
        Schema::create('reference_counters', function (Blueprint $table) {
            $table->string('prefix', 20);
            $table->unsignedSmallInteger('year');
            $table->unsignedInteger('last_number')->default(0);
            $table->primary(['prefix', 'year']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('reference_counters');
    }
};
""")

# ---------- models ----------
LOCKED = {
 'purchase_requests':['status'], 'purchase_orders':['status'], 'supplier_invoices':['status','paid_kobo'],
 'leave_requests':['status','decided_by','decided_at'], 'applications':['status','decided_by','decided_at','cohort_id'],
 'quotations':['status','accepted_at','revision'], 'payroll_inputs':['status'], 'reconciliations':['status','reconciled_by','reconciled_at'],
 'deliverables':['status','delivered_at'], 'milestones':['status','approved_by_contact_id','approved_at'], 'assets':['status','assignee_id','disposed_at','disposal_reason'],
 'inventory_items':['quantity_on_hand'], 'project_quotes':['status','accepted_at','revision'], 'purchase_order_lines':['received_quantity'],
 'enrolment_instalments':['status'], 'care_plan_renewals':['status'], 'survey_submissions':['status'], 'support_tickets':['status','resolved_at'],
 'staff_profiles':[], 'documents':['current_version'], 'enquiries':['status','converted_at'], 'service_projects':['status','agreement_accepted_at','completed_at'],
 'care_plans':['status'], 'incidents':[], 'consents':[], 'alumni_records':[],
}
ACTOR_COLS = ['created_by','author_id','logged_by','recorded_by','uploaded_by','requested_by','reported_by','received_by','posted_by']
AUTO_REF = {'enquiries':('reference','ENQ'),'quotations':('number','QUO'),'applications':('reference','APP'),'service_projects':('reference','DSP'),
            'support_tickets':('reference','TKT'),'purchase_requests':('reference','PR'),'purchase_orders':('number','PO'),'goods_receipts':('number','GRN'),
            'incidents':('reference','INC'),'journal_entries':('number','JE')}
READONLY = {'research_projects','datasets','certificates','journal_entries','journal_entry_lines','notifications','enrolments','supplier_invoices_x'}
GENERIC_EXCLUDE = {'files'}

models_written = []
registry = {}
hasmany = {}  # target table -> list of (child table, fkcol)
for g in G:
    for c in map(parse, g['cols']):
        if c['type']=='f': hasmany.setdefault(c['ref'], []).append((g['table'], c['name']))

def rel_name(fk): return re.sub(r'_(id)$','',fk).replace('_id','') and ''.join([p if i==0 else p.capitalize() for i,p in enumerate(re.sub(r'_id$','',fk).split('_'))])
def camel(s): return ''.join([p if i==0 else p.capitalize() for i,p in enumerate(s.split('_'))])
def plural_rel(table): return camel(table)

CASTS = {'k':'integer','b':'boolean','j':'array','d':'date','dt':'datetime','dec':'decimal:2','i':'integer','si':'integer'}
for g in G:
    t = g['table']; M = model_name(t, g)
    path = f"{API}/app/Models/{M}.php"
    cols = [parse(c) for c in g['cols']]
    # registry
    if t not in GENERIC_EXCLUDE:
        locked = set(LOCKED.get(t, []))
        auto = AUTO_REF.get(t)
        actor = next((a for a in ACTOR_COLS if any(c['name']==a for c in cols)), None)
        rules, unique = {}, []
        for c in cols:
            if c['name'] in locked or (auto and c['name']==auto[0]) or c['name']==actor: continue
            if t=='research_projects' and c['name'] in ('reference','stage','deposit_kobo','closed_at'): continue
            r = rule_for(c, t)
            rules[c['name']] = r
            if c['uniq']: unique.append(c['name'])
        sec = {'module': g['module'], 'resource': g['res'], 'model': M, 'table': t,
               'readonly': bool(g.get('readonly') or t in READONLY), 'rules': rules, 'unique': unique,
               'search': g.get('search', []), 'actor': actor, 'auto_ref': list(auto) if auto else None,
               'with': [camel(re.sub(r'_id$','',c['name'])) for c in cols if c['type']=='f' and c['ref'] in ('contacts','users','courses','cohorts','suppliers','organisations') ][:3]}
        slug = t.replace('_','-')
        registry[slug] = sec
    if os.path.exists(path):
        continue
    imports = {'Illuminate\\Database\\Eloquent\\Model'}
    casts = {}
    rels = []
    for c in cols:
        if c['type'] in CASTS and not c['name'].endswith('_id'): casts[c['name']] = CASTS[c['type']]
        if c['type']=='f':
            imports.add('Illuminate\\Database\\Eloquent\\Relations\\BelongsTo')
            tgt = TABLE2MODEL[c['ref']]
            rels.append(f"    public function {camel(re.sub(r'_id$','',c['name']))}(): BelongsTo\n    {{\n        return $this->belongsTo({tgt}::class, '{c['name']}');\n    }}\n")
    for child, fk in hasmany.get(t, []):
        imports.add('Illuminate\\Database\\Eloquent\\Relations\\HasMany')
        cm = TABLE2MODEL[child]
        name = camel(child) if sum(1 for ch,_ in hasmany[t] if ch==child)==1 else camel(child)+'By'+studly(re.sub(r'_id$','',fk))
        rels.append(f"    public function {name}(): HasMany\n    {{\n        return $this->hasMany({cm}::class, '{fk}');\n    }}\n")
    if g.get('soft'): imports.add('Illuminate\\Database\\Eloquent\\SoftDeletes')
    imp = '\n'.join(f'use {i};' for i in sorted(imports))
    cast_block = ''
    if casts:
        cast_block = "\n    protected function casts(): array\n    {\n        return [\n" + ''.join(f"            '{k}' => '{v}',\n" for k,v in casts.items()) + "        ];\n    }\n"
    tbl = f"    protected $table = '{t}';\n\n"
    php = f"""<?php

declare(strict_types=1);

namespace App\\Models;

{imp}

class {M} extends Model
{{
{'    use SoftDeletes;' + chr(10) + chr(10) if g.get('soft') else ''}{tbl}    protected $guarded = ['id'];
{cast_block}
{chr(10).join(rels)}}}
"""
    php = re.sub(r'\n\n\n+', '\n\n', php).replace("{\n\n}", "{\n}")
    open(path,'w').write(php)
    models_written.append(M)

# Add inverse relations to handwritten models
def inject(model, methods, uses):
    p = f"{API}/app/Models/{model}.php"
    s = open(p).read()
    add = ''
    for name, ret, tgt, fk in methods:
        if f'function {name}(' in s: continue
        add += f"\n    public function {name}(): {ret}\n    {{\n        return $this->{ 'hasMany' if ret=='HasMany' else 'hasOne'}({tgt}::class, '{fk}');\n    }}\n"
    for u in uses:
        line = f'use Illuminate\\Database\\Eloquent\\Relations\\{u};'
        if line not in s: s = s.replace('\nclass ', f'{line}\n\nclass ',1) if False else s.replace('use Illuminate\\Database\\Eloquent\\Model;', f'use Illuminate\\Database\\Eloquent\\Model;\n{line}',1)
    idx = s.rstrip().rfind('}')
    s = s[:idx].rstrip('\n') + '\n' + add + '}\n'
    open(p,'w').write(s)
inject('Course',[('modules','HasMany','CourseModule','course_id'),('cohorts','HasMany','Cohort','course_id'),('applications','HasMany','Application','course_id')],['HasMany'])
inject('Cohort',[('sessions','HasMany','ClassSession','cohort_id'),('assessments','HasMany','Assessment','cohort_id'),('assignments','HasMany','Assignment','cohort_id'),('enrolments','HasMany','Enrolment','cohort_id')],['HasMany'])
inject('Enrolment',[('instalments','HasMany','EnrolmentInstalment','enrolment_id'),('attendance','HasMany','AttendanceRecord','enrolment_id'),('results','HasMany','AssessmentResult','enrolment_id')],['HasMany'])
inject('Contact',[('enquiries','HasMany','Enquiry','contact_id'),('enrolments','HasMany','Enrolment','contact_id'),('researchProjects','HasMany','ResearchProject','client_contact_id'),('serviceProjects','HasMany','ServiceProject','contact_id'),('invoices','HasMany','Invoice','contact_id'),('notes','HasMany','CustomerNote','contact_id'),('communications','HasMany','Communication','contact_id')],['HasMany'])
# Contact organisation relation
p=f"{API}/app/Models/Contact.php"; s=open(p).read()
if 'function organisation' not in s:
    s=s.replace('use Illuminate\\Database\\Eloquent\\Relations\\HasOne;','use Illuminate\\Database\\Eloquent\\Relations\\BelongsTo;\nuse Illuminate\\Database\\Eloquent\\Relations\\HasOne;',1)
    idx=s.rstrip().rfind('}'); s=s[:idx].rstrip('\n')+"\n\n    public function organisation(): BelongsTo\n    {\n        return $this->belongsTo(Organisation::class);\n    }\n}\n"
    open(p,'w').write(s)

# ---------- registry PHP ----------
def phpval(v, ind=0):
    pad = '    '*ind
    if isinstance(v, dict):
        if not v: return '[]'
        return '[\n' + ''.join(f"{pad}    '{k}' => {phpval(x, ind+1)},\n" for k,x in v.items()) + pad + ']'
    if isinstance(v, list):
        return '[' + ', '.join(phpval(x, ind) for x in v) + ']'
    if isinstance(v, bool): return 'true' if v else 'false'
    if v is None: return 'null'
    if isinstance(v, int): return str(v)
    return "'" + str(v).replace("'", "\\'") + "'"
reg_php = "<?php\n\n// GENERATED by tools/schema (see docs/developer-guides/schema-generator.md). Do not edit by hand.\n// Declares every generic CRUD resource: model, permission scope, validation rules and locked columns.\n\nreturn " + phpval(registry) + ";\n"
os.makedirs(f'{API}/config', exist_ok=True)
open(f'{API}/config/resources.php','w').write(reg_php)

# permission map
perm = {}
for slug, r in registry.items():
    perm.setdefault(r['module'], {}).setdefault(r['resource'], True)
open(f'{API}/config/.perm_dump.json','w').write(json.dumps(perm)); os.remove(f'{API}/config/.perm_dump.json')

# ---------- ERD ----------
groups = {}
for g in G: groups.setdefault(g['group'], []).append(g)
out = ["# Entity Relationship Diagram", "", "Generated from `tools/schema/schema.py`. Core identity, finance control and platform tables are in the first four migrations; every other table has one migration in `apps/api/database/migrations/2026_02_01_*`.", "",
       "Design rules: one `contacts` row per person (customer, learner, staff, partner) linked 1:1 to an optional `users` login; money is integer kobo; deletes are `RESTRICT` for business records and `CASCADE` only for owned child rows.", ""]
core = """erDiagram
  contacts ||--o| users : "login"
  organisations ||--o{ contacts : employs
  users }o--o{ roles : user_roles
  roles }o--o{ permissions : role_permissions
  contacts ||--o{ invoices : billed
  invoices ||--o{ invoice_lines : has
  payments ||--o{ payment_allocations : allocated
  invoices ||--o{ payment_allocations : settled_by
  approval_requests ||--o{ approval_decisions : decided_by
"""
out += ["## Core and finance control", "```mermaid", core.rstrip(), "```", ""]
for grp, items in groups.items():
    out += [f"## {grp.capitalize()}", "", "```mermaid", "erDiagram"]
    for g in items:
        for c in map(parse, g['cols']):
            if c['type']=='f' and c['ref']!=g['table']:
                out.append(f"  {c['ref']} ||--{'o|' if c['null'] else 'o{'} {g['table']} : {c['name']}")
    out.append("```"); out.append("")
    out += ["| Table | Columns | Deletion behaviour |", "|---|---|---|"]
    for g in items:
        cl = ', '.join(parse(c)['name'] for c in g['cols'])
        fks = [parse(c) for c in g['cols'] if parse(c)['type']=='f']
        beh = '; '.join(f"{f['name']}: " + ('cascade' if f['cascade'] else 'set null' if f['null'] else 'restrict') for f in fks[:6]) or '-'
        out.append(f"| `{g['table']}`{' (soft delete)' if g.get('soft') else ''} | {cl} | {beh} |")
    out.append("")
open(f'{DOCS}/database/erd.md','w').write('\n'.join(out))
pass
print(len(order),'migrations;',len(models_written),'models;',len(registry),'resources')
