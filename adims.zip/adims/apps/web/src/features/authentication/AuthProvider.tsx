"use client";

import { createContext, useCallback, useContext, useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api, ApiError, post } from "@/lib/api-client";
import type { AuthUser } from "@/types/api";

interface AuthContextValue {
  user: AuthUser | null;
  loading: boolean;
  /** UI convenience only. The API re-checks every permission on the server. */
  can: (permission: string) => boolean;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["me"],
    retry: false,
    staleTime: 60_000,
    queryFn: async () => {
      try {
        return (await api<{ user: AuthUser }>("/auth/me")).user;
      } catch (e) {
        if (e instanceof ApiError && e.status === 401) return null;
        throw e;
      }
    },
  });

  const user = data ?? null;
  const can = useCallback(
    (permission: string) => !!user && (user.permissions.includes("*") || user.permissions.includes(permission)),
    [user],
  );

  const signOut = useCallback(async () => {
    await post("/auth/logout").catch(() => undefined);
    qc.clear();
    window.location.href = "/login";
  }, [qc]);

  const value = useMemo(() => ({ user, loading: isLoading, can, signOut }), [user, isLoading, can, signOut]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
