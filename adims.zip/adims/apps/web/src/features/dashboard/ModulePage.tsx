"use client";

import { useState } from "react";
import { ResourceForm } from "@/components/forms/ResourceForm";
import { ResourceTable } from "@/components/tables/ResourceTable";
import { MODULES } from "@/constants/modules";
import { useAuth } from "@/features/authentication/AuthProvider";

/** One reusable page for every module: permission-filtered tabs, each a paginated table with an optional create form. */
export function ModulePage({ module }: { module: keyof typeof MODULES }) {
  const def = MODULES[module];
  const { can } = useAuth();
  const tabs = def.tabs.filter((t) => t.permissions.some(can));
  const [active, setActive] = useState(tabs[0]?.id);
  const [showForm, setShowForm] = useState(false);
  const [refresh, setRefresh] = useState(0);
  const tab = tabs.find((t) => t.id === active) ?? tabs[0];

  if (!tab) return <p className="text-sm text-slate-500">You do not have access to this module.</p>;

  return (
    <div>
      <h1 className="text-xl font-semibold">{def.title}</h1>
      <p className="mt-1 text-sm text-slate-500">{def.description}</p>

      <div role="tablist" aria-label={def.title} className="mt-5 flex flex-wrap gap-1 border-b border-slate-200">
        {tabs.map((t) => (
          <button key={t.id} role="tab" aria-selected={t.id === tab.id} onClick={() => { setActive(t.id); setShowForm(false); }}
            className={`-mb-px border-b-2 px-3 py-2 text-sm ${t.id === tab.id ? "border-brand-600 font-medium text-brand-700" : "border-transparent text-slate-600 hover:text-slate-900"}`}>
            {t.label}
          </button>
        ))}
      </div>

      <div role="tabpanel" className="mt-4">
        {tab.create && can(tab.create.permission) && (
          <div className="mb-3">
            <button className="btn-primary" onClick={() => setShowForm(!showForm)}>{showForm ? "Close" : `New ${tab.label.toLowerCase().replace(/s$/, "")}`}</button>
          </div>
        )}
        {showForm && tab.create && (
          <ResourceForm endpoint={tab.endpoint} fields={tab.create.fields} onDone={() => { setShowForm(false); setRefresh((n) => n + 1); }} />
        )}
        <ResourceTable key={tab.id} endpoint={tab.endpoint} columns={tab.columns} refreshKey={refresh} />
      </div>
    </div>
  );
}
