"use client";

import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api-client";
import { formatKobo } from "@/lib/money";

interface Overview {
  invoices: { id: number; number: string; status: string; total_kobo: number; paid_kobo: number; due_on: string | null }[];
  research_projects: { id: number; reference: string; title: string; stage: string; due_on: string | null }[];
  service_projects: { id: number; reference: string; title: string; status: string; due_on: string | null }[];
  enrolments: { id: number; status: string; cohort: { name: string; course: { title: string } } }[];
  tickets: { id: number; reference: string; subject: string; status: string }[];
  quotations: { id: number; number: string; title: string; total_kobo: number; status: string }[];
}

type Section = "invoices" | "research" | "services" | "learning" | "tickets" | "quotations";

/** Self-service view for clients and learners. The API scopes everything to the signed-in person. */
export function PortalOverview({ title, sections }: { title: string; sections: Section[] }) {
  const { data, isLoading } = useQuery({ queryKey: ["portal"], queryFn: () => api<Overview>("/portal/overview") });
  if (isLoading || !data) return <p className="text-sm text-slate-500">Loading…</p>;

  const Block = ({ name, children, empty }: { name: string; children: React.ReactNode; empty: boolean }) => (
    <section className="card" aria-label={name}>
      <h2 className="mb-2 text-sm font-medium text-slate-700">{name}</h2>
      {empty ? <p className="text-sm text-slate-500">Nothing here yet.</p> : <ul className="divide-y divide-slate-100 text-sm">{children}</ul>}
    </section>
  );

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">{title}</h1>
      <div className="grid gap-4 lg:grid-cols-2">
        {sections.includes("learning") && (
          <Block name="My courses" empty={!data.enrolments.length}>
            {data.enrolments.map((e) => <li key={e.id} className="flex justify-between py-2"><span>{e.cohort.course.title} · {e.cohort.name}</span><span className="text-slate-500">{e.status}</span></li>)}
          </Block>
        )}
        {sections.includes("quotations") && (
          <Block name="Quotations" empty={!data.quotations.length}>
            {data.quotations.map((q) => <li key={q.id} className="flex justify-between py-2"><span>{q.number} · {q.title}</span><span>{formatKobo(q.total_kobo)} · {q.status}</span></li>)}
          </Block>
        )}
        {sections.includes("research") && (
          <Block name="Research projects" empty={!data.research_projects.length}>
            {data.research_projects.map((p) => <li key={p.id} className="flex justify-between py-2"><span>{p.reference} · {p.title}</span><span className="text-slate-500">{p.stage.replace(/_/g, " ")}</span></li>)}
          </Block>
        )}
        {sections.includes("services") && (
          <Block name="Digital service projects" empty={!data.service_projects.length}>
            {data.service_projects.map((p) => <li key={p.id} className="flex justify-between py-2"><span>{p.reference} · {p.title}</span><span className="text-slate-500">{p.status.replace(/_/g, " ")}</span></li>)}
          </Block>
        )}
        {sections.includes("invoices") && (
          <Block name="Invoices" empty={!data.invoices.length}>
            {data.invoices.map((i) => <li key={i.id} className="flex justify-between py-2"><span>{i.number} <span className="text-slate-500">({i.status.replace(/_/g, " ")})</span></span><span className="tabular-nums">{formatKobo(i.total_kobo - i.paid_kobo)} due</span></li>)}
          </Block>
        )}
        {sections.includes("tickets") && (
          <Block name="Support tickets" empty={!data.tickets.length}>
            {data.tickets.map((t) => <li key={t.id} className="flex justify-between py-2"><span>{t.reference} · {t.subject}</span><span className="text-slate-500">{t.status.replace(/_/g, " ")}</span></li>)}
          </Block>
        )}
      </div>
      <p className="text-xs text-slate-500">A transfer receipt you upload is recorded as a claim and only counts once our team verifies it.</p>
    </div>
  );
}
