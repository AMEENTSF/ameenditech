export interface NavItem {
  label: string;
  href: string;
  /** Any of these shows the link. Used only to hide links; the API enforces access. */
  permissions: string[];
}

export const NAV: NavItem[] = [
  { label: "Dashboard", href: "/dashboard", permissions: ["dashboard.executive.view"] },
  { label: "Customers", href: "/clients", permissions: ["crm.contacts.view", "crm.enquiries.view"] },
  { label: "Research", href: "/research", permissions: ["research.projects.view"] },
  { label: "Training", href: "/training", permissions: ["training.courses.view"] },
  { label: "Digital Services", href: "/digital-services", permissions: ["services.projects.view", "services.tickets.view"] },
  { label: "Finance", href: "/finance", permissions: ["finance.invoices.view", "finance.expenses.view", "finance.expenses.create"] },
  { label: "Approvals", href: "/management/approvals", permissions: ["finance.expenses.approve", "finance.payments.verify", "procurement.requests.approve", "finance.invoices.approve"] },
  { label: "Reports", href: "/management/reports", permissions: ["reports.view"] },
  { label: "Management", href: "/management", permissions: ["procurement.assets.view", "governance.documents.view", "governance.risks.view"] },
  { label: "Staff & HR", href: "/staff", permissions: ["hr.staff.view", "hr.leave.view", "hr.leave.create"] },
  { label: "Administration", href: "/admin", permissions: ["admin.users.manage", "admin.audit.view", "admin.roles.manage"] },
];
