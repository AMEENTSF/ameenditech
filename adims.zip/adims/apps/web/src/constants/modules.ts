export type ColumnType = "text" | "kobo" | "date" | "badge" | "datetime";

export interface ColumnDef {
  key: string; // dotted path allowed, e.g. "contact.first_name"
  label: string;
  type?: ColumnType;
}

export interface FieldDef {
  name: string;
  label: string;
  type: "text" | "textarea" | "number" | "date" | "select" | "naira";
  required?: boolean;
  options?: string[];
  /** For `naira` fields the value is converted to integer kobo before sending. The API field name must end in _kobo. */
}

export interface TabDef {
  id: string;
  label: string;
  endpoint: string; // relative to /api/v1
  columns: ColumnDef[];
  /** Hides the tab unless the user holds one of these permissions (UI convenience only). */
  permissions: string[];
  create?: { permission: string; fields: FieldDef[] };
}

export interface ModuleDef {
  title: string;
  description: string;
  tabs: TabDef[];
}

const STATUS_OPTS = (xs: string[]) => xs;

export const MODULES: Record<string, ModuleDef> = {
  clients: {
    title: "Customers (CRM)",
    description: "Organisations, enquiries, quotations and communication history.",
    tabs: [
      { id: "enquiries", label: "Enquiries", endpoint: "/enquiries", permissions: ["crm.enquiries.view"],
        columns: [{ key: "reference", label: "Reference" }, { key: "subject", label: "Subject" }, { key: "service_line", label: "Service line", type: "badge" }, { key: "status", label: "Status", type: "badge" }, { key: "created_at", label: "Received", type: "date" }],
        create: { permission: "crm.enquiries.create", fields: [
          { name: "contact_id", label: "Contact ID", type: "number", required: true },
          { name: "service_line", label: "Service line", type: "select", required: true, options: ["research", "training", "digital_services", "other"] },
          { name: "subject", label: "Subject", type: "text", required: true },
          { name: "message", label: "Message", type: "textarea" },
        ] } },
      { id: "organisations", label: "Organisations", endpoint: "/organisations", permissions: ["crm.organisations.view"],
        columns: [{ key: "name", label: "Name" }, { key: "type", label: "Type", type: "badge" }, { key: "email", label: "Email" }, { key: "phone", label: "Phone" }, { key: "state", label: "State" }],
        create: { permission: "crm.organisations.create", fields: [
          { name: "name", label: "Name", type: "text", required: true },
          { name: "type", label: "Type", type: "select", options: ["company", "ngo", "government", "school", "other"] },
          { name: "email", label: "Email", type: "text" }, { name: "phone", label: "Phone", type: "text" }, { name: "state", label: "State", type: "text" },
        ] } },
      { id: "quotations", label: "Quotations", endpoint: "/quotations", permissions: ["crm.quotations.view"],
        columns: [{ key: "number", label: "Number" }, { key: "title", label: "Title" }, { key: "total_kobo", label: "Total", type: "kobo" }, { key: "status", label: "Status", type: "badge" }, { key: "valid_until", label: "Valid until", type: "date" }] },
      { id: "communications", label: "Communications", endpoint: "/communications", permissions: ["crm.contacts.view"],
        columns: [{ key: "channel", label: "Channel", type: "badge" }, { key: "subject", label: "Subject" }, { key: "occurred_at", label: "When", type: "datetime" }, { key: "follow_up_at", label: "Follow up", type: "datetime" }] },
    ],
  },
  research: {
    title: "Research & Data Analysis",
    description: "Enquiry to closure, with deposit, second-reader review and delivery gates.",
    tabs: [
      { id: "projects", label: "Projects", endpoint: "/research/projects", permissions: ["research.projects.view"],
        columns: [{ key: "reference", label: "Reference" }, { key: "title", label: "Title" }, { key: "stage", label: "Stage", type: "badge" }, { key: "quoted_kobo", label: "Quoted", type: "kobo" }, { key: "due_on", label: "Due", type: "date" }],
        create: { permission: "research.projects.create", fields: [
          { name: "client_contact_id", label: "Client contact ID", type: "number", required: true },
          { name: "title", label: "Title", type: "text", required: true },
          { name: "scope", label: "Scope", type: "textarea" }, { name: "due_on", label: "Due date", type: "date" },
        ] } },
      { id: "surveys", label: "Surveys", endpoint: "/survey-forms", permissions: ["research.projects.view"],
        columns: [{ key: "title", label: "Title" }, { key: "odk_form_id", label: "ODK form" }, { key: "status", label: "Status", type: "badge" }] },
      { id: "tasks", label: "Tasks", endpoint: "/project-tasks", permissions: ["research.projects.view"],
        columns: [{ key: "title", label: "Task" }, { key: "phase", label: "Phase", type: "badge" }, { key: "status", label: "Status", type: "badge" }, { key: "due_on", label: "Due", type: "date" }] },
      { id: "deliverables", label: "Deliverables", endpoint: "/deliverables", permissions: ["research.deliverables.view"],
        columns: [{ key: "title", label: "Title" }, { key: "version", label: "Version" }, { key: "status", label: "Status", type: "badge" }, { key: "delivered_at", label: "Delivered", type: "date" }] },
    ],
  },
  training: {
    title: "Digital Skills Training",
    description: "Courses, admissions, cohorts, attendance, assessment and certificates.",
    tabs: [
      { id: "courses", label: "Courses", endpoint: "/courses", permissions: ["training.courses.view"],
        columns: [{ key: "title", label: "Course" }, { key: "fee_kobo", label: "Fee", type: "kobo" }, { key: "duration_weeks", label: "Weeks" }, { key: "status", label: "Status", type: "badge" }],
        create: { permission: "training.courses.create", fields: [
          { name: "slug", label: "Slug", type: "text", required: true }, { name: "title", label: "Title", type: "text", required: true },
          { name: "description", label: "Description", type: "textarea" }, { name: "fee_kobo", label: "Fee (₦)", type: "naira", required: true },
          { name: "duration_weeks", label: "Duration (weeks)", type: "number", required: true },
          { name: "status", label: "Status", type: "select", options: STATUS_OPTS(["draft", "published", "archived"]) },
        ] } },
      { id: "applications", label: "Applications", endpoint: "/applications", permissions: ["training.applications.view"],
        columns: [{ key: "reference", label: "Reference" }, { key: "status", label: "Status", type: "badge" }, { key: "created_at", label: "Applied", type: "date" }] },
      { id: "cohorts", label: "Cohorts", endpoint: "/cohorts", permissions: ["training.courses.view"],
        columns: [{ key: "name", label: "Cohort" }, { key: "starts_on", label: "Starts", type: "date" }, { key: "ends_on", label: "Ends", type: "date" }, { key: "capacity", label: "Capacity" }],
        create: { permission: "training.courses.create", fields: [
          { name: "course_id", label: "Course ID", type: "number", required: true }, { name: "name", label: "Name", type: "text", required: true },
          { name: "starts_on", label: "Starts", type: "date", required: true }, { name: "ends_on", label: "Ends", type: "date" }, { name: "capacity", label: "Capacity", type: "number" },
        ] } },
      { id: "enrolments", label: "Enrolments", endpoint: "/enrolments", permissions: ["training.enrolments.view"],
        columns: [{ key: "cohort_id", label: "Cohort ID" }, { key: "contact_id", label: "Learner ID" }, { key: "status", label: "Status", type: "badge" }] },
      { id: "certificates", label: "Certificates", endpoint: "/certificates", permissions: ["training.certificates.view"],
        columns: [{ key: "verification_number", label: "Verification no." }, { key: "issued_at", label: "Issued", type: "date" }, { key: "revoked_at", label: "Revoked", type: "date" }] },
    ],
  },
  "digital-services": {
    title: "Digital Services",
    description: "Service projects, milestones, support tickets and monthly care plans.",
    tabs: [
      { id: "projects", label: "Projects", endpoint: "/service-projects", permissions: ["services.projects.view"],
        columns: [{ key: "reference", label: "Reference" }, { key: "title", label: "Title" }, { key: "status", label: "Status", type: "badge" }, { key: "agreed_kobo", label: "Agreed", type: "kobo" }, { key: "due_on", label: "Due", type: "date" }] },
      { id: "tickets", label: "Support tickets", endpoint: "/support-tickets", permissions: ["services.tickets.view"],
        columns: [{ key: "reference", label: "Reference" }, { key: "subject", label: "Subject" }, { key: "priority", label: "Priority", type: "badge" }, { key: "status", label: "Status", type: "badge" }] },
      { id: "care-plans", label: "Care plans", endpoint: "/care-plans", permissions: ["services.care_plans.view"],
        columns: [{ key: "name", label: "Plan" }, { key: "monthly_fee_kobo", label: "Monthly fee", type: "kobo" }, { key: "renews_on", label: "Renews", type: "date" }, { key: "status", label: "Status", type: "badge" }] },
      { id: "catalogue", label: "Service catalogue", endpoint: "/service-catalogue", permissions: ["services.projects.view"],
        columns: [{ key: "name", label: "Service" }, { key: "category", label: "Category", type: "badge" }, { key: "base_price_kobo", label: "From", type: "kobo" }] },
    ],
  },
  finance: {
    title: "Finance & Accounting",
    description: "Invoices, payments, expenses and the chart of accounts. Amounts above the threshold need two approvers.",
    tabs: [
      { id: "invoices", label: "Invoices", endpoint: "/finance/invoices", permissions: ["finance.invoices.view"],
        columns: [{ key: "number", label: "Number" }, { key: "status", label: "Status", type: "badge" }, { key: "total_kobo", label: "Total", type: "kobo" }, { key: "paid_kobo", label: "Paid", type: "kobo" }, { key: "due_on", label: "Due", type: "date" }] },
      { id: "payments", label: "Payments", endpoint: "/finance/payments", permissions: ["finance.payments.view"],
        columns: [{ key: "reference", label: "Reference" }, { key: "method", label: "Method", type: "badge" }, { key: "amount_kobo", label: "Amount", type: "kobo" }, { key: "status", label: "Status", type: "badge" }] },
      { id: "expenses", label: "Expenses", endpoint: "/finance/expenses", permissions: ["finance.expenses.view", "finance.expenses.create"],
        columns: [{ key: "reference", label: "Reference" }, { key: "description", label: "Description" }, { key: "amount_kobo", label: "Amount", type: "kobo" }, { key: "status", label: "Status", type: "badge" }],
        create: { permission: "finance.expenses.create", fields: [
          { name: "description", label: "Description", type: "text", required: true }, { name: "amount_kobo", label: "Amount (₦)", type: "naira", required: true }, { name: "incurred_on", label: "Date incurred", type: "date" },
        ] } },
      { id: "accounts", label: "Chart of accounts", endpoint: "/accounts", permissions: ["finance.accounts.view"],
        columns: [{ key: "code", label: "Code" }, { key: "name", label: "Account" }, { key: "active", label: "Active" }] },
      { id: "bank", label: "Bank & cash", endpoint: "/bank-accounts", permissions: ["finance.bank.view"],
        columns: [{ key: "name", label: "Account" }, { key: "kind", label: "Kind", type: "badge" }, { key: "opening_balance_kobo", label: "Opening", type: "kobo" }] },
    ],
  },
  staff: {
    title: "Staff & HR",
    description: "Staff records, leave and performance reviews.",
    tabs: [
      { id: "staff", label: "Staff", endpoint: "/staff-profiles", permissions: ["hr.staff.view"],
        columns: [{ key: "staff_number", label: "Staff no." }, { key: "employment_type", label: "Type", type: "badge" }, { key: "hired_on", label: "Hired", type: "date" }, { key: "status", label: "Status", type: "badge" }] },
      { id: "leave", label: "Leave", endpoint: "/leave-requests", permissions: ["hr.leave.view"],
        columns: [{ key: "starts_on", label: "From", type: "date" }, { key: "ends_on", label: "To", type: "date" }, { key: "status", label: "Status", type: "badge" }] },
      { id: "reviews", label: "Reviews", endpoint: "/performance-reviews", permissions: ["hr.reviews.view"],
        columns: [{ key: "period", label: "Period" }, { key: "rating", label: "Rating" }, { key: "status", label: "Status", type: "badge" }] },
      { id: "departments", label: "Departments", endpoint: "/departments", permissions: ["hr.staff.view"], columns: [{ key: "name", label: "Department" }] },
    ],
  },
  management: {
    title: "Management",
    description: "Procurement, assets and governance.",
    tabs: [
      { id: "requests", label: "Purchase requests", endpoint: "/purchase-requests", permissions: ["procurement.requests.view"],
        columns: [{ key: "reference", label: "Reference" }, { key: "title", label: "Title" }, { key: "estimated_kobo", label: "Estimate", type: "kobo" }, { key: "status", label: "Status", type: "badge" }] },
      { id: "orders", label: "Purchase orders", endpoint: "/purchase-orders", permissions: ["procurement.orders.view"],
        columns: [{ key: "number", label: "Number" }, { key: "total_kobo", label: "Total", type: "kobo" }, { key: "status", label: "Status", type: "badge" }, { key: "expected_on", label: "Expected", type: "date" }] },
      { id: "suppliers", label: "Suppliers", endpoint: "/suppliers", permissions: ["procurement.orders.view"],
        columns: [{ key: "name", label: "Supplier" }, { key: "email", label: "Email" }, { key: "status", label: "Status", type: "badge" }] },
      { id: "assets", label: "Assets", endpoint: "/assets", permissions: ["procurement.assets.view"],
        columns: [{ key: "tag", label: "Tag" }, { key: "name", label: "Asset" }, { key: "category", label: "Category", type: "badge" }, { key: "status", label: "Status", type: "badge" }] },
      { id: "documents", label: "Documents", endpoint: "/governance/documents", permissions: ["governance.documents.view"],
        columns: [{ key: "title", label: "Title" }, { key: "category", label: "Category", type: "badge" }, { key: "confidentiality", label: "Access", type: "badge" }, { key: "current_version", label: "Version" }] },
      { id: "risks", label: "Risk register", endpoint: "/risks", permissions: ["governance.risks.view"],
        columns: [{ key: "title", label: "Risk" }, { key: "likelihood", label: "Likelihood" }, { key: "impact", label: "Impact" }, { key: "status", label: "Status", type: "badge" }] },
      { id: "compliance", label: "Compliance calendar", endpoint: "/compliance-items", permissions: ["governance.risks.view"],
        columns: [{ key: "title", label: "Item" }, { key: "due_on", label: "Due", type: "date" }, { key: "status", label: "Status", type: "badge" }] },
    ],
  },
  admin: {
    title: "Administration",
    description: "Users, roles and the audit trail.",
    tabs: [
      { id: "users", label: "Users", endpoint: "/admin/users", permissions: ["admin.users.manage"],
        columns: [{ key: "email", label: "Email" }, { key: "status", label: "Status", type: "badge" }, { key: "last_login_at", label: "Last login", type: "datetime" }] },
      { id: "roles", label: "Roles", endpoint: "/admin/roles", permissions: ["admin.roles.manage"],
        columns: [{ key: "name", label: "Role" }, { key: "users_count", label: "Users" }, { key: "requires_mfa", label: "MFA required" }] },
      { id: "audit", label: "Audit log", endpoint: "/admin/audit-logs", permissions: ["admin.audit.view"],
        columns: [{ key: "created_at", label: "When", type: "datetime" }, { key: "action", label: "Action" }, { key: "user_id", label: "User ID" }, { key: "ip_address", label: "IP" }] },
    ],
  },
};
