export interface Paginated<T> {
  data: T[];
  current_page: number;
  last_page: number;
  total: number;
  per_page: number;
}

export interface AuthUser {
  id: number;
  email: string;
  name: string | null;
  status: string;
  roles: { slug: string; name: string }[];
  permissions: string[]; // ["*"] for super administrators
  mfa_enabled: boolean;
}

export interface ExecutiveDashboard {
  period: { from: string; to: string };
  finance?: {
    revenue_billed_kobo: number;
    revenue_collected_kobo: number;
    expenses_kobo: number;
    net_operating_kobo: number;
    outstanding_invoices_kobo: number;
    overdue_kobo: number;
    monthly: { month: string; revenue_kobo: number; expenses_kobo: number }[];
  };
  research?: { active: number; completed: number; by_stage: Record<string, number>; avg_turnaround_days: number | null };
  training?: { active_learners: number; enrolments_in_period: number; completion_rate_percent: number | null; certificates_issued_in_period: number };
  digital_services?: { active_projects: number; by_status: Record<string, number>; open_tickets: number; active_care_plans: number };
  customers: { total: number; new_in_period: number; monthly_new: { month: string; n: number }[] };
  staff_activity?: { active_users: number; actions: number };
  pending_approvals: number;
  upcoming_deadlines: { type: string; label: string; due_on: string }[];
}

export interface Report {
  title: string;
  columns: Record<string, [string, "text" | "int" | "kobo" | "date" | "percent" | "decimal"]>;
  rows: Record<string, string | number | null>[];
}
