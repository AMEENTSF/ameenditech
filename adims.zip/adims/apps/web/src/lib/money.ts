/** All amounts cross the API as integer kobo. Convert only for display. */
export function formatKobo(kobo: number): string {
  const sign = kobo < 0 ? "-" : "";
  const abs = Math.abs(kobo);
  const naira = Math.trunc(abs / 100);
  const rem = String(abs % 100).padStart(2, "0");
  return `${sign}₦${naira.toLocaleString("en-NG")}.${rem}`;
}

/** Compact form for chart axes: ₦1.2M, ₦350K. */
export function formatKoboCompact(kobo: number): string {
  const naira = kobo / 100; // display only
  const abs = Math.abs(naira);
  if (abs >= 1_000_000) return `₦${(naira / 1_000_000).toFixed(1)}M`;
  if (abs >= 1_000) return `₦${(naira / 1_000).toFixed(0)}K`;
  return `₦${naira.toFixed(0)}`;
}

/** Parse user-typed naira ("1,500.50") to integer kobo without floating-point arithmetic. */
export function nairaToKobo(input: string): number | null {
  const m = input.replace(/[,\s₦]/g, "").match(/^(\d+)(?:\.(\d{1,2}))?$/);
  if (!m) return null;
  return Number(m[1]) * 100 + Number((m[2] ?? "").padEnd(2, "0") || 0);
}
