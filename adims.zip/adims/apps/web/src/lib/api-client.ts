const ORIGIN = process.env.NEXT_PUBLIC_API_ORIGIN ?? "http://localhost:8080";
export const API_BASE = `${ORIGIN}/api/v1`;

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public errors?: Record<string, string[]>,
    public body?: Record<string, unknown>,
  ) {
    super(message);
  }
}

function xsrfToken(): string | undefined {
  if (typeof document === "undefined") return undefined;
  const m = document.cookie.match(/(?:^|; )XSRF-TOKEN=([^;]+)/);
  return m ? decodeURIComponent(m[1]) : undefined;
}

let csrfReady = false;
async function ensureCsrf() {
  if (csrfReady) return;
  await fetch(`${ORIGIN}/sanctum/csrf-cookie`, { credentials: "include" });
  csrfReady = true;
}

/**
 * Single entry point for API calls. Uses the Sanctum session cookie plus the XSRF header,
 * never stores tokens in JavaScript-readable storage.
 */
export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  const method = (init.method ?? "GET").toUpperCase();
  const isForm = typeof FormData !== "undefined" && init.body instanceof FormData;
  const headers: Record<string, string> = { Accept: "application/json", ...(init.headers as Record<string, string>) };
  if (!isForm) headers["Content-Type"] = "application/json";

  if (method !== "GET") {
    await ensureCsrf();
    const t = xsrfToken();
    if (t) headers["X-XSRF-TOKEN"] = t;
  }

  const res = await fetch(`${API_BASE}${path}`, { ...init, credentials: "include", headers });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    if (res.status === 419) csrfReady = false;
    throw new ApiError(res.status, body.message ?? res.statusText, body.errors, body);
  }

  return res.status === 204 ? (undefined as T) : ((await res.json()) as T);
}

export const post = <T>(path: string, data?: unknown) =>
  api<T>(path, { method: "POST", body: data === undefined ? undefined : JSON.stringify(data) });

/** URL for browser-initiated downloads (reports); the session cookie authorises them. */
export const downloadUrl = (path: string) => `${API_BASE}${path}`;
