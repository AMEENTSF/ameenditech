import { describe, expect, it } from "vitest";
import { formatKobo, nairaToKobo } from "./money";

describe("money", () => {
  it("formats integer kobo without float error", () => {
    expect(formatKobo(150005)).toBe("₦1,500.05");
    expect(formatKobo(-99)).toBe("-₦0.99");
    expect(formatKobo(10_000_000)).toBe("₦100,000.00");
  });

  it("parses typed naira to kobo", () => {
    expect(nairaToKobo("1,500.50")).toBe(150050);
    expect(nairaToKobo("0.1")).toBe(10);
    expect(nairaToKobo("12.345")).toBeNull();
    expect(nairaToKobo("abc")).toBeNull();
  });
});
