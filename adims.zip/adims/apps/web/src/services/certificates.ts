import { api } from "@/lib/api-client";

export interface CertificateVerification {
  valid: boolean;
  holder: string;
  course: string;
  issued_on: string;
}

export const verifyCertificate = (number: string) =>
  api<CertificateVerification>(`/certificates/verify/${encodeURIComponent(number)}`);
