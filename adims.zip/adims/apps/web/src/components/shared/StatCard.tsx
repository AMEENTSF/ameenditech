interface Props {
  label: string;
  value: string | null; // null means "no data", never a made-up number
  hint?: string;
  tone?: "default" | "warn";
}

export function StatCard({ label, value, hint, tone = "default" }: Props) {
  return (
    <div className={`rounded-lg border bg-white p-4 ${tone === "warn" ? "border-amber-300" : "border-slate-200"}`}>
      <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-2 text-2xl font-semibold text-slate-900">{value ?? "No data"}</p>
      {hint && <p className="mt-1 text-xs text-slate-500">{hint}</p>}
    </div>
  );
}
