"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { NAV } from "@/constants/navigation";
import { useAuth } from "@/features/authentication/AuthProvider";

export function Sidebar() {
  const pathname = usePathname();
  const { can, user } = useAuth();
  const items = NAV.filter((i) => i.permissions.some(can));
  // Portal users (clients, learners) have no staff permissions and get their own entries.
  const portal = user && items.length === 0;

  return (
    <aside className="hidden w-60 shrink-0 border-r border-slate-200 bg-white md:block">
      <div className="px-5 py-5 text-lg font-semibold text-brand-700">ADIMS</div>
      <nav aria-label="Primary" className="flex flex-col gap-1 px-3">
        {(portal
          ? [{ label: "My account", href: "/clients" }, { label: "My learning", href: "/learners" }]
          : items
        ).map((item) => {
          const active = pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href + "/"));
          return (
            <Link
              key={item.href}
              href={item.href}
              aria-current={active ? "page" : undefined}
              className={`rounded-md px-3 py-2 text-sm ${active ? "bg-brand-50 font-medium text-brand-700" : "text-slate-700 hover:bg-brand-50 hover:text-brand-700"}`}
            >
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
