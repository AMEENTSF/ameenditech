"use client";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Bell, LogOut } from "lucide-react";
import { useState } from "react";
import { api, post } from "@/lib/api-client";
import { useAuth } from "@/features/authentication/AuthProvider";

interface Note { id: number; subject: string | null; body: string; read_at: string | null; created_at: string }

export function Topbar() {
  const { user, signOut } = useAuth();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const { data } = useQuery({
    queryKey: ["notifications"],
    refetchInterval: 60_000,
    queryFn: () => api<{ unread: number; data: { data: Note[] } }>("/notifications?per_page=10"),
  });

  async function readAll() {
    await post("/notifications/read-all");
    qc.invalidateQueries({ queryKey: ["notifications"] });
  }

  return (
    <header className="flex items-center justify-between border-b border-slate-200 bg-white px-6 py-3">
      <p className="text-sm text-slate-500">{user?.roles.map((r) => r.name).join(", ")}</p>
      <div className="relative flex items-center gap-3">
        <button className="btn-secondary relative" aria-label={`Notifications, ${data?.unread ?? 0} unread`} aria-expanded={open} onClick={() => setOpen(!open)}>
          <Bell size={16} aria-hidden />
          {!!data?.unread && (
            <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-red-600 px-1 text-[10px] text-white">{data.unread}</span>
          )}
        </button>
        {open && (
          <div role="dialog" aria-label="Notifications" className="absolute right-12 top-10 z-20 w-80 rounded-lg border border-slate-200 bg-white p-2 shadow-lg">
            <div className="flex items-center justify-between px-2 py-1">
              <span className="text-sm font-medium">Notifications</span>
              <button className="text-xs text-brand-700 underline" onClick={readAll}>Mark all read</button>
            </div>
            <ul className="max-h-72 divide-y divide-slate-100 overflow-auto">
              {data?.data.data.length ? data.data.data.map((n) => (
                <li key={n.id} className={`px-2 py-2 text-sm ${n.read_at ? "text-slate-500" : "font-medium"}`}>
                  {n.subject && <div>{n.subject}</div>}
                  <div className="font-normal text-slate-600">{n.body}</div>
                </li>
              )) : <li className="px-2 py-3 text-sm text-slate-500">Nothing yet.</li>}
            </ul>
          </div>
        )}
        <span className="text-sm">{user?.name ?? user?.email}</span>
        <button className="btn-secondary" onClick={signOut} aria-label="Sign out"><LogOut size={16} aria-hidden /></button>
      </div>
    </header>
  );
}
