"use client";

import { useState } from "react";
import { ApiError, post } from "@/lib/api-client";
import { nairaToKobo } from "@/lib/money";
import type { FieldDef } from "@/constants/modules";

/**
 * Config-driven create form. Client-side checks are for convenience; the API validates everything
 * again and its field errors are shown next to the inputs.
 */
export function ResourceForm({ endpoint, fields, onDone }: { endpoint: string; fields: FieldDef[]; onDone: () => void }) {
  const [values, setValues] = useState<Record<string, string>>({});
  const [errors, setErrors] = useState<Record<string, string[]>>({});
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErrors({});
    setMessage(null);

    const body: Record<string, unknown> = {};
    for (const f of fields) {
      const v = (values[f.name] ?? "").trim();
      if (v === "") continue;
      if (f.type === "naira") {
        const kobo = nairaToKobo(v);
        if (kobo === null) return setErrors({ [f.name]: ["Enter a valid amount, for example 1500.50"] });
        body[f.name] = kobo;
      } else if (f.type === "number") body[f.name] = Number(v);
      else body[f.name] = v;
    }

    setBusy(true);
    try {
      await post(endpoint, body);
      setValues({});
      onDone();
    } catch (err) {
      if (err instanceof ApiError) {
        setErrors(err.errors ?? {});
        setMessage(err.status === 403 ? "You do not have permission to do this." : err.message);
      } else setMessage("Something went wrong.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="card mb-4 grid gap-3 sm:grid-cols-2" noValidate>
      {fields.map((f) => (
        <div key={f.name} className={f.type === "textarea" ? "sm:col-span-2" : ""}>
          <label htmlFor={`f-${f.name}`} className="mb-1 block text-sm font-medium text-slate-700">
            {f.label}{f.required && <span aria-hidden className="text-red-600"> *</span>}
          </label>
          {f.type === "textarea" ? (
            <textarea id={`f-${f.name}`} className="input" rows={3} value={values[f.name] ?? ""} onChange={(e) => setValues({ ...values, [f.name]: e.target.value })} />
          ) : f.type === "select" ? (
            <select id={`f-${f.name}`} className="input" value={values[f.name] ?? ""} onChange={(e) => setValues({ ...values, [f.name]: e.target.value })}>
              <option value="">Select…</option>
              {f.options?.map((o) => <option key={o} value={o}>{o.replace(/_/g, " ")}</option>)}
            </select>
          ) : (
            <input id={`f-${f.name}`} className="input" required={f.required} type={f.type === "date" ? "date" : f.type === "number" ? "number" : "text"} inputMode={f.type === "naira" ? "decimal" : undefined}
              value={values[f.name] ?? ""} onChange={(e) => setValues({ ...values, [f.name]: e.target.value })} />
          )}
          {errors[f.name] && <p role="alert" className="mt-1 text-xs text-red-700">{errors[f.name][0]}</p>}
        </div>
      ))}
      <div className="sm:col-span-2 flex items-center gap-3">
        <button className="btn-primary" disabled={busy}>{busy ? "Saving…" : "Save"}</button>
        {message && <span role="alert" className="text-sm text-red-700">{message}</span>}
      </div>
    </form>
  );
}
