"use client";

import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { api } from "@/lib/api-client";
import { formatKobo } from "@/lib/money";
import type { ColumnDef } from "@/constants/modules";
import type { Paginated } from "@/types/api";

type Row = Record<string, unknown>;

const get = (row: Row, path: string): unknown => path.split(".").reduce<unknown>((v, k) => (v && typeof v === "object" ? (v as Row)[k] : undefined), row);

function cell(col: ColumnDef, value: unknown): React.ReactNode {
  if (value === null || value === undefined || value === "") return <span className="text-slate-400">–</span>;
  switch (col.type) {
    case "kobo": return <span className="tabular-nums">{formatKobo(Number(value))}</span>;
    case "date": return String(value).slice(0, 10);
    case "datetime": return new Date(String(value)).toLocaleString("en-NG", { timeZone: "Africa/Lagos" });
    case "badge": return <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs">{String(value).replace(/_/g, " ")}</span>;
    default: return typeof value === "boolean" ? (value ? "Yes" : "No") : String(value);
  }
}

export function ResourceTable({ endpoint, columns, refreshKey = 0 }: { endpoint: string; columns: ColumnDef[]; refreshKey?: number }) {
  const [page, setPage] = useState(1);
  const [q, setQ] = useState("");
  const [term, setTerm] = useState("");

  const { data, isLoading, error } = useQuery({
    queryKey: ["table", endpoint, page, term, refreshKey],
    queryFn: async () => {
      const sep = endpoint.includes("?") ? "&" : "?";
      const res = await api<Paginated<Row> | { data: Row[] }>(`${endpoint}${sep}page=${page}&per_page=25${term ? `&q=${encodeURIComponent(term)}` : ""}`);
      return res;
    },
  });

  const rows = data?.data ?? [];
  const paged = data && "last_page" in data ? data : null;

  return (
    <div>
      <form className="mb-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); setPage(1); setTerm(q); }} role="search">
        <label className="sr-only" htmlFor={`q-${endpoint}`}>Search</label>
        <input id={`q-${endpoint}`} className="input max-w-xs" placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} />
        <button className="btn-secondary">Search</button>
      </form>

      <div className="overflow-x-auto rounded-lg border border-slate-200 bg-white">
        <table className="min-w-full text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
            <tr>{columns.map((c) => <th key={c.key} scope="col" className="px-3 py-2 font-medium">{c.label}</th>)}</tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {isLoading && <tr><td className="px-3 py-6 text-slate-500" colSpan={columns.length}>Loading…</td></tr>}
            {error && <tr><td role="alert" className="px-3 py-6 text-red-700" colSpan={columns.length}>You do not have access to this list, or it could not be loaded.</td></tr>}
            {!isLoading && !error && rows.length === 0 && <tr><td className="px-3 py-6 text-slate-500" colSpan={columns.length}>No records yet.</td></tr>}
            {rows.map((row, i) => (
              <tr key={String(row.id ?? i)} className="hover:bg-slate-50">
                {columns.map((c) => <td key={c.key} className="px-3 py-2">{cell(c, get(row, c.key))}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {paged && paged.last_page > 1 && (
        <nav className="mt-3 flex items-center justify-between text-sm" aria-label="Pagination">
          <span className="text-slate-500">Page {paged.current_page} of {paged.last_page} · {paged.total} records</span>
          <div className="flex gap-2">
            <button className="btn-secondary" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</button>
            <button className="btn-secondary" disabled={page >= paged.last_page} onClick={() => setPage(page + 1)}>Next</button>
          </div>
        </nav>
      )}
    </div>
  );
}
