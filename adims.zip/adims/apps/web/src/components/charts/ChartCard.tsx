"use client";

import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export interface Series { key: string; label: string; color: string }

interface Props {
  title: string;
  data: Record<string, string | number>[];
  xKey: string;
  series: Series[];
  kind?: "bar" | "line";
  /** Formats tooltip and axis values (e.g. kobo to naira). */
  format?: (v: number) => string;
}

export function ChartCard({ title, data, xKey, series, kind = "bar", format = (v) => String(v) }: Props) {
  const Chart = kind === "bar" ? BarChart : LineChart;
  return (
    <section className="card" aria-label={title}>
      <h2 className="mb-3 text-sm font-medium text-slate-700">{title}</h2>
      {data.length === 0 ? (
        <p className="py-10 text-center text-sm text-slate-500">No records in this period.</p>
      ) : (
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <Chart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey={xKey} tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => format(Number(v))} width={70} />
              <Tooltip formatter={(v) => format(Number(v))} />
              {series.length > 1 && <Legend />}
              {series.map((s) =>
                kind === "bar" ? (
                  <Bar key={s.key} dataKey={s.key} name={s.label} fill={s.color} radius={[3, 3, 0, 0]} />
                ) : (
                  <Line key={s.key} dataKey={s.key} name={s.label} stroke={s.color} strokeWidth={2} dot={false} />
                ),
              )}
            </Chart>
          </ResponsiveContainer>
        </div>
      )}
    </section>
  );
}
