"use client";

import { useEffect, useState } from "react";
import { api, ApiError, post } from "@/lib/api-client";
import { formatKobo } from "@/lib/money";

interface Course { id: number; title: string; description: string | null; fee_kobo: number; duration_weeks: number }

export default function ApplyPage() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [form, setForm] = useState({ course_id: "", first_name: "", last_name: "", email: "", phone: "", statement: "", consent: false });
  const [done, setDone] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string[]>>({});

  useEffect(() => { api<{ data: Course[] }>("/public/courses").then((r) => setCourses(r.data)).catch(() => undefined); }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErrors({});
    try {
      const res = await post<{ reference: string }>("/public/applications", { ...form, course_id: Number(form.course_id) });
      setDone(res.reference);
    } catch (err) {
      if (err instanceof ApiError) setErrors(err.errors ?? { form: [err.message] });
    }
  }

  if (done) return <main className="mx-auto max-w-lg p-6"><h1 className="text-xl font-semibold">Application received</h1><p className="mt-2 text-sm">Your reference is <strong>{done}</strong>. We will contact you by email.</p></main>;

  const err = (k: string) => errors[k] && <p role="alert" className="mt-1 text-xs text-red-700">{errors[k][0]}</p>;
  return (
    <main className="mx-auto max-w-lg p-6">
      <h1 className="text-xl font-semibold">Apply for a course</h1>
      <form onSubmit={submit} className="mt-4 space-y-3" noValidate>
        <div><label htmlFor="course" className="mb-1 block text-sm font-medium">Course</label>
          <select id="course" className="input" value={form.course_id} onChange={(e) => setForm({ ...form, course_id: e.target.value })}>
            <option value="">Select a course…</option>
            {courses.map((c) => <option key={c.id} value={c.id}>{c.title} · {c.duration_weeks} weeks · {formatKobo(c.fee_kobo)}</option>)}
          </select>{err("course_id")}</div>
        {(["first_name", "last_name", "email", "phone"] as const).map((k) => (
          <div key={k}><label htmlFor={k} className="mb-1 block text-sm font-medium capitalize">{k.replace("_", " ")}</label>
            <input id={k} className="input" value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />{err(k)}</div>
        ))}
        <div><label htmlFor="statement" className="mb-1 block text-sm font-medium">Why do you want to join? (optional)</label>
          <textarea id="statement" rows={3} className="input" value={form.statement} onChange={(e) => setForm({ ...form, statement: e.target.value })} /></div>
        <label className="flex items-start gap-2 text-sm"><input type="checkbox" className="mt-1" checked={form.consent} onChange={(e) => setForm({ ...form, consent: e.target.checked })} />
          I agree that Ameen Digitech may store and use my details to process this application.</label>{err("consent")}
        <button className="btn-primary">Submit application</button>
      </form>
    </main>
  );
}
