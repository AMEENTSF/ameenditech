"use client";

import { useState } from "react";
import { ApiError, post } from "@/lib/api-client";

export default function EnquiryPage() {
  const [form, setForm] = useState({ first_name: "", last_name: "", email: "", phone: "", service_line: "research", subject: "", message: "", consent: false });
  const [done, setDone] = useState(false);
  const [errors, setErrors] = useState<Record<string, string[]>>({});

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErrors({});
    try { await post("/public/enquiries", form); setDone(true); }
    catch (err) { if (err instanceof ApiError) setErrors(err.errors ?? { form: [err.message] }); }
  }
  if (done) return <main className="mx-auto max-w-lg p-6"><h1 className="text-xl font-semibold">Thank you</h1><p className="mt-2 text-sm">We have received your enquiry and will be in touch shortly.</p></main>;

  const err = (k: string) => errors[k] && <p role="alert" className="mt-1 text-xs text-red-700">{errors[k][0]}</p>;
  return (
    <main className="mx-auto max-w-lg p-6">
      <h1 className="text-xl font-semibold">Make an enquiry</h1>
      <form onSubmit={submit} className="mt-4 space-y-3" noValidate>
        <div><label htmlFor="sl" className="mb-1 block text-sm font-medium">What do you need?</label>
          <select id="sl" className="input" value={form.service_line} onChange={(e) => setForm({ ...form, service_line: e.target.value })}>
            <option value="research">Research and data analysis</option><option value="training">Digital skills training</option>
            <option value="digital_services">Website, branding or digital marketing</option><option value="other">Something else</option>
          </select></div>
        {(["first_name", "last_name", "email", "phone", "subject"] as const).map((k) => (
          <div key={k}><label htmlFor={k} className="mb-1 block text-sm font-medium capitalize">{k.replace("_", " ")}</label>
            <input id={k} className="input" value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />{err(k)}</div>
        ))}
        <div><label htmlFor="msg" className="mb-1 block text-sm font-medium">Tell us more</label>
          <textarea id="msg" rows={4} className="input" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} /></div>
        <label className="flex items-start gap-2 text-sm"><input type="checkbox" className="mt-1" checked={form.consent} onChange={(e) => setForm({ ...form, consent: e.target.checked })} />
          I agree that Ameen Digitech may contact me about this enquiry.</label>{err("consent")}
        <button className="btn-primary">Send enquiry</button>
      </form>
    </main>
  );
}
