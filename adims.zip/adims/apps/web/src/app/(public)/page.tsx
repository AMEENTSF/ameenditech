import Link from "next/link";

export default function Home() {
  return (
    <main className="mx-auto max-w-xl p-8">
      <h1 className="text-2xl font-semibold text-brand-700">Ameen Digitech Ltd</h1>
      <p className="mt-1 text-slate-600">Your partner in digitisation.</p>
      <ul className="mt-6 space-y-2 text-sm">
        <li><Link className="underline" href="/enquiry">Make an enquiry</Link></li>
        <li><Link className="underline" href="/apply">Apply for a course</Link></li>
        <li><Link className="underline" href="/verify">Verify a certificate</Link></li>
        <li><Link className="underline" href="/login">Staff, client and learner sign in</Link></li>
      </ul>
    </main>
  );
}
