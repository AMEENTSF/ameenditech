"use client";

import { useState } from "react";
import { verifyCertificate, type CertificateVerification } from "@/services/certificates";

export default function VerifyCertificatePage() {
  const [number, setNumber] = useState("");
  const [result, setResult] = useState<CertificateVerification | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setResult(null);
    try {
      setResult(await verifyCertificate(number.trim()));
    } catch {
      setError("Certificate not found. Check the number and try again.");
    }
  }

  return (
    <main className="mx-auto max-w-md p-6">
      <h1 className="text-xl font-semibold">Verify a certificate</h1>
      <form onSubmit={onSubmit} className="mt-4 flex gap-2">
        <label htmlFor="cert" className="sr-only">Verification number</label>
        <input
          id="cert"
          value={number}
          onChange={(e) => setNumber(e.target.value)}
          className="flex-1 rounded-md border border-slate-300 px-3 py-2 text-sm"
          placeholder="ADT-XXXX-XXXX-XXXX"
        />
        <button className="rounded-md bg-brand-600 px-4 py-2 text-sm text-white hover:bg-brand-700">Verify</button>
      </form>
      {error && <p role="alert" className="mt-4 text-sm text-red-700">{error}</p>}
      {result && (
        <dl className="mt-4 rounded-lg border border-slate-200 bg-white p-4 text-sm">
          <dt className="text-slate-500">Status</dt>
          <dd className="font-medium">{result.valid ? "Valid" : "Revoked"}</dd>
          <dt className="mt-2 text-slate-500">Holder</dt>
          <dd>{result.holder}</dd>
          <dt className="mt-2 text-slate-500">Course</dt>
          <dd>{result.course}</dd>
          <dt className="mt-2 text-slate-500">Issued</dt>
          <dd>{result.issued_on}</dd>
        </dl>
      )}
    </main>
  );
}
