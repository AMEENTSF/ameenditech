import { PortalOverview } from "@/features/portal/PortalOverview";

export default function Page() {
  return <PortalOverview title="My learning" sections={["learning", "invoices"]} />;
}
