"use client";

import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { api, downloadUrl } from "@/lib/api-client";
import { useAuth } from "@/features/authentication/AuthProvider";
import { formatKobo } from "@/lib/money";
import type { Report } from "@/types/api";

const iso = (d: Date) => d.toISOString().slice(0, 10);

export default function ReportsPage() {
  const { can } = useAuth();
  const [slug, setSlug] = useState("");
  const [from, setFrom] = useState(iso(new Date(Date.now() - 365 * 86_400_000)));
  const [to, setTo] = useState(iso(new Date()));

  const catalogue = useQuery({ queryKey: ["report-catalogue"], queryFn: () => api<{ data: string[] }>("/reports") });
  const current = slug || catalogue.data?.data[0] || "";
  const qs = `from=${from}&to=${to}`;

  const report = useQuery({ enabled: !!current, queryKey: ["report", current, from, to], queryFn: () => api<Report>(`/reports/${current}?${qs}`) });

  const fmt = (type: string, v: unknown) => {
    if (v === null || v === undefined) return "–";
    if (type === "kobo") return formatKobo(Number(v));
    if (type === "percent") return `${v}%`;
    return String(v);
  };

  return (
    <div>
      <h1 className="text-xl font-semibold">Reports</h1>
      <div className="mt-4 flex flex-wrap items-end gap-3">
        <label className="text-sm">Report
          <select className="input mt-1" value={current} onChange={(e) => setSlug(e.target.value)}>
            {catalogue.data?.data.map((s) => <option key={s} value={s}>{s.replace(/-/g, " ")}</option>)}
          </select>
        </label>
        <label className="text-sm">From<input type="date" className="input mt-1" value={from} onChange={(e) => setFrom(e.target.value)} /></label>
        <label className="text-sm">To<input type="date" className="input mt-1" value={to} onChange={(e) => setTo(e.target.value)} /></label>
        {can("reports.export") && current && (
          <div className="flex gap-2" aria-label="Export">
            {(["csv", "xlsx", "pdf"] as const).map((f) => (
              <a key={f} className="btn-secondary" href={downloadUrl(`/reports/${current}?${qs}&format=${f}`)}>{f.toUpperCase()}</a>
            ))}
          </div>
        )}
      </div>

      {report.data && (
        <div className="mt-5 overflow-x-auto rounded-lg border border-slate-200 bg-white">
          <h2 className="border-b border-slate-100 px-3 py-2 text-sm font-medium">{report.data.title}</h2>
          <table className="min-w-full text-left text-sm">
            <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
              <tr>{Object.entries(report.data.columns).map(([k, [label]]) => <th key={k} className="px-3 py-2">{label}</th>)}</tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {report.data.rows.length === 0 && <tr><td className="px-3 py-6 text-slate-500" colSpan={99}>No records for this period.</td></tr>}
              {report.data.rows.map((row, i) => (
                <tr key={i}>{Object.entries(report.data!.columns).map(([k, [, type]]) => <td key={k} className="px-3 py-2 tabular-nums">{fmt(type, row[k])}</td>)}</tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {report.isError && <p role="alert" className="mt-4 text-sm text-red-700">This report could not be loaded.</p>}
    </div>
  );
}
