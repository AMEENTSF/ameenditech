"use client";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { api, ApiError, post } from "@/lib/api-client";
import { formatKobo } from "@/lib/money";

interface Pending {
  id: number;
  subject_type: string;
  subject_id: number;
  amount_kobo: number;
  required_approvals: number;
  decisions: { decision: string }[];
  created_at: string;
}

export default function ApprovalsPage() {
  const qc = useQueryClient();
  const [msg, setMsg] = useState<string | null>(null);
  const { data, isLoading } = useQuery({ queryKey: ["approvals"], queryFn: () => api<{ data: Pending[] }>("/approvals/pending") });

  async function decide(p: Pending, kind: "approve" | "reject") {
    setMsg(null);
    let comment: string | undefined;
    if (kind === "reject") {
      comment = window.prompt("Reason for rejecting (required):")?.trim();
      if (!comment) return;
    }
    try {
      const res = await post<{ status: string; approvals_recorded?: number; approvals_required?: number }>(`/approvals/${p.id}/${kind}`, { comment });
      setMsg(res.status === "pending" ? `Recorded. ${res.approvals_recorded} of ${res.approvals_required} approvals so far.` : `Request ${res.status}.`);
      qc.invalidateQueries({ queryKey: ["approvals"] });
    } catch (e) {
      setMsg(e instanceof ApiError ? (Object.values(e.errors ?? {})[0]?.[0] ?? e.message) : "Something went wrong.");
    }
  }

  return (
    <div>
      <h1 className="text-xl font-semibold">Pending approvals</h1>
      <p className="mt-1 text-sm text-slate-500">Amounts above the configured threshold (default ₦100,000) need two different approvers. You cannot approve your own requests.</p>
      {msg && <p role="status" className="mt-3 rounded-md bg-brand-50 px-3 py-2 text-sm text-brand-700">{msg}</p>}
      <div className="mt-4 overflow-x-auto rounded-lg border border-slate-200 bg-white">
        <table className="min-w-full text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
            <tr><th className="px-3 py-2">Type</th><th className="px-3 py-2">Record</th><th className="px-3 py-2">Amount</th><th className="px-3 py-2">Approvals</th><th className="px-3 py-2">Requested</th><th className="px-3 py-2"><span className="sr-only">Actions</span></th></tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {isLoading && <tr><td className="px-3 py-6 text-slate-500" colSpan={6}>Loading…</td></tr>}
            {!isLoading && !data?.data.length && <tr><td className="px-3 py-6 text-slate-500" colSpan={6}>Nothing is waiting for you.</td></tr>}
            {data?.data.map((p) => (
              <tr key={p.id}>
                <td className="px-3 py-2 capitalize">{p.subject_type.replace(/_/g, " ")}</td>
                <td className="px-3 py-2">#{p.subject_id}</td>
                <td className="px-3 py-2 tabular-nums">{formatKobo(p.amount_kobo)}</td>
                <td className="px-3 py-2">{p.decisions.filter((d) => d.decision === "approved").length} / {p.required_approvals}</td>
                <td className="px-3 py-2">{p.created_at.slice(0, 10)}</td>
                <td className="px-3 py-2 text-right">
                  <button className="btn-primary mr-2" onClick={() => decide(p, "approve")}>Approve</button>
                  <button className="btn-secondary" onClick={() => decide(p, "reject")}>Reject</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
