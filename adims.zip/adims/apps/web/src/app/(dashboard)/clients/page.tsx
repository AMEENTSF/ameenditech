"use client";

import { ModulePage } from "@/features/dashboard/ModulePage";
import { PortalOverview } from "@/features/portal/PortalOverview";
import { useAuth } from "@/features/authentication/AuthProvider";

/** Staff with CRM access see the CRM module; clients see their own portal. */
export default function Page() {
  const { can } = useAuth();
  const staff = can("crm.contacts.view") || can("crm.enquiries.view");

  return staff ? <ModulePage module="clients" /> : <PortalOverview title="My account" sections={["quotations", "research", "services", "invoices", "tickets"]} />;
}
