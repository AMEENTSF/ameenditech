"use client";

import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { ChartCard } from "@/components/charts/ChartCard";
import { StatCard } from "@/components/shared/StatCard";
import { api } from "@/lib/api-client";
import { formatKobo, formatKoboCompact } from "@/lib/money";
import type { ExecutiveDashboard } from "@/types/api";

const iso = (d: Date) => d.toISOString().slice(0, 10);
const daysAgo = (n: number) => new Date(Date.now() - n * 86_400_000);

const RANGES = [
  { label: "Last 30 days", days: 30 },
  { label: "Last 90 days", days: 90 },
  { label: "Last 12 months", days: 365 },
];

export default function DashboardPage() {
  const [days, setDays] = useState(90);
  const from = iso(daysAgo(days));
  const to = iso(new Date());

  const { data, isLoading, error } = useQuery({
    queryKey: ["dashboard", from, to],
    queryFn: () => api<ExecutiveDashboard>(`/dashboard/executive?from=${from}&to=${to}`),
  });

  if (isLoading) return <p className="text-sm text-slate-500">Loading dashboard…</p>;
  if (error || !data) return <p role="alert" className="text-sm text-red-700">The dashboard could not be loaded.</p>;

  const { finance, research, training, digital_services: ds, customers } = data;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Executive Dashboard</h1>
          <p className="text-sm text-slate-500">
            Calculated from live records for {data.period.from} to {data.period.to}. You only see sections you are authorised for.
          </p>
        </div>
        <label className="text-sm">
          <span className="sr-only">Date range</span>
          <select className="input" value={days} onChange={(e) => setDays(Number(e.target.value))}>
            {RANGES.map((r) => <option key={r.days} value={r.days}>{r.label}</option>)}
          </select>
        </label>
      </div>

      {finance && (
        <section aria-label="Finance" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard label="Revenue billed" value={formatKobo(finance.revenue_billed_kobo)} hint="Invoices issued in period" />
          <StatCard label="Cash collected" value={formatKobo(finance.revenue_collected_kobo)} hint="Verified payments only" />
          <StatCard label="Expenses paid" value={formatKobo(finance.expenses_kobo)} />
          <StatCard label="Net operating" value={formatKobo(finance.net_operating_kobo)} hint="Collected minus expenses" />
          <StatCard label="Outstanding invoices" value={formatKobo(finance.outstanding_invoices_kobo)} />
          <StatCard label="Overdue" value={formatKobo(finance.overdue_kobo)} tone={finance.overdue_kobo > 0 ? "warn" : "default"} />
          <StatCard label="Pending approvals" value={String(data.pending_approvals)} hint="Waiting for you" tone={data.pending_approvals > 0 ? "warn" : "default"} />
          {data.staff_activity && <StatCard label="Active staff" value={String(data.staff_activity.active_users)} hint={`${data.staff_activity.actions} recorded actions`} />}
        </section>
      )}

      <section aria-label="Operations" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {research && (
          <>
            <StatCard label="Active research projects" value={String(research.active)} />
            <StatCard label="Completed research projects" value={String(research.completed)} hint={research.avg_turnaround_days === null ? undefined : `Avg turnaround ${research.avg_turnaround_days} days`} />
          </>
        )}
        {training && (
          <>
            <StatCard label="Active learners" value={String(training.active_learners)} />
            <StatCard label="Enrolments in period" value={String(training.enrolments_in_period)} />
            <StatCard label="Course completion rate" value={training.completion_rate_percent === null ? null : `${training.completion_rate_percent}%`} />
            <StatCard label="Certificates issued" value={String(training.certificates_issued_in_period)} />
          </>
        )}
        {ds && (
          <>
            <StatCard label="Digital services projects" value={String(ds.active_projects)} hint={`${ds.open_tickets} open tickets`} />
            <StatCard label="Active care plans" value={String(ds.active_care_plans)} />
          </>
        )}
        <StatCard label="Customers" value={String(customers.total)} hint={`${customers.new_in_period} new in period`} />
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        {finance && (
          <ChartCard
            title="Revenue billed vs expenses paid"
            data={finance.monthly}
            xKey="month"
            series={[
              { key: "revenue_kobo", label: "Revenue", color: "#1f7a63" },
              { key: "expenses_kobo", label: "Expenses", color: "#c2410c" },
            ]}
            format={formatKoboCompact}
          />
        )}
        <ChartCard title="New customers per month" kind="line" data={customers.monthly_new} xKey="month" series={[{ key: "n", label: "New customers", color: "#0b5cab" }]} />
        {research && (
          <ChartCard
            title="Research projects by stage"
            data={Object.entries(research.by_stage).map(([stage, n]) => ({ stage: stage.replace(/_/g, " "), n }))}
            xKey="stage"
            series={[{ key: "n", label: "Projects", color: "#1f7a63" }]}
          />
        )}
      </div>

      <section className="card" aria-label="Upcoming deadlines">
        <h2 className="mb-2 text-sm font-medium text-slate-700">Upcoming deadlines (14 days)</h2>
        {data.upcoming_deadlines.length === 0 ? (
          <p className="text-sm text-slate-500">Nothing due.</p>
        ) : (
          <ul className="divide-y divide-slate-100 text-sm">
            {data.upcoming_deadlines.map((d, i) => (
              <li key={i} className="flex justify-between py-2">
                <span>{d.label} <span className="text-xs text-slate-500">({d.type.replace(/_/g, " ")})</span></span>
                <time dateTime={d.due_on}>{d.due_on}</time>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
