import { ModulePage } from "@/features/dashboard/ModulePage";

export default function Page() {
  return <ModulePage module="digital-services" />;
}
