"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import { ApiError, post } from "@/lib/api-client";

const schema = z.object({
  email: z.string().email("Enter a valid email address"),
  password: z.string().min(1, "Enter your password"),
  otp: z.string().regex(/^\d{6}$/, "Enter the 6-digit code").optional().or(z.literal("")),
});
type Form = z.infer<typeof schema>;

export default function LoginPage() {
  const qc = useQueryClient();
  const [needsOtp, setNeedsOtp] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { register, handleSubmit, formState } = useForm<Form>({ resolver: zodResolver(schema) });

  async function onSubmit(values: Form) {
    setError(null);
    try {
      await post("/auth/login", { ...values, otp: values.otp || undefined });
      await qc.invalidateQueries({ queryKey: ["me"] });
      window.location.href = "/dashboard";
    } catch (e) {
      if (e instanceof ApiError && e.body?.mfa_required) return setNeedsOtp(true);
      if (e instanceof ApiError && e.status === 429) return setError("Too many attempts. Please wait a minute and try again.");
      setError(e instanceof ApiError ? (Object.values(e.errors ?? {})[0]?.[0] ?? e.message) : "Something went wrong.");
    }
  }

  return (
    <main className="grid min-h-screen place-items-center bg-surface p-4">
      <div className="w-full max-w-sm rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="mb-6">
          <div className="text-2xl font-semibold text-brand-700">ADIMS</div>
          <p className="text-sm text-slate-500">Ameen Digitech Integrated Management System</p>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
          <Field id="email" label="Email" error={formState.errors.email?.message}>
            <input id="email" type="email" autoComplete="username" className="input" {...register("email")} />
          </Field>
          <Field id="password" label="Password" error={formState.errors.password?.message}>
            <input id="password" type="password" autoComplete="current-password" className="input" {...register("password")} />
          </Field>
          {needsOtp && (
            <Field id="otp" label="Authentication code" error={formState.errors.otp?.message}>
              <input id="otp" inputMode="numeric" autoComplete="one-time-code" maxLength={6} className="input" {...register("otp")} />
            </Field>
          )}
          {error && <p role="alert" className="text-sm text-red-700">{error}</p>}
          <button disabled={formState.isSubmitting} className="btn-primary w-full">
            {formState.isSubmitting ? "Signing in…" : needsOtp ? "Verify and sign in" : "Sign in"}
          </button>
        </form>
        <p className="mt-4 text-center text-xs text-slate-500">
          <a href="/verify" className="underline">Verify a certificate</a>
        </p>
      </div>
    </main>
  );
}

function Field({ id, label, error, children }: { id: string; label: string; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <label htmlFor={id} className="mb-1 block text-sm font-medium text-slate-700">{label}</label>
      {children}
      {error && <p className="mt-1 text-xs text-red-700">{error}</p>}
    </div>
  );
}
