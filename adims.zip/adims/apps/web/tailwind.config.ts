import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#eef6f3",
          100: "#d4eae2",
          500: "#1f7a63",
          600: "#186350",
          700: "#134e40",
          900: "#0b2d26",
        },
        surface: "#f7f8f9",
      },
      fontFamily: { sans: ["Inter", "system-ui", "sans-serif"] },
    },
  },
  plugins: [],
};

export default config;
