<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ServiceTask extends Model
{
    protected $table = 'service_tasks';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'due_on' => 'date',
        ];
    }

    public function serviceProject(): BelongsTo
    {
        return $this->belongsTo(ServiceProject::class, 'service_project_id');
    }

    public function assignee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assignee_id');
    }
}
