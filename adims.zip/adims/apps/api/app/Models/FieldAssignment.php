<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class FieldAssignment extends Model
{
    protected $table = 'field_assignments';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'target_count' => 'integer',
        ];
    }

    public function surveyVersion(): BelongsTo
    {
        return $this->belongsTo(SurveyVersion::class, 'survey_version_id');
    }

    public function enumerator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'enumerator_id');
    }

    public function supervisor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'supervisor_id');
    }

    public function surveySubmissions(): HasMany
    {
        return $this->hasMany(SurveySubmission::class, 'field_assignment_id');
    }
}
