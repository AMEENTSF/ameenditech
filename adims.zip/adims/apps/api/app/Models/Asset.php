<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Asset extends Model
{
    use SoftDeletes;

    protected $table = 'assets';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'purchased_on' => 'date',
            'cost_kobo' => 'integer',
            'disposed_at' => 'datetime',
        ];
    }

    public function assignee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assignee_id');
    }

    public function laptopAllocations(): HasMany
    {
        return $this->hasMany(LaptopAllocation::class, 'asset_id');
    }

    public function assetMovements(): HasMany
    {
        return $this->hasMany(AssetMovement::class, 'asset_id');
    }

    public function maintenanceRecords(): HasMany
    {
        return $this->hasMany(MaintenanceRecord::class, 'asset_id');
    }

    public function movements(): HasMany
    {
        return $this->hasMany(AssetMovement::class, 'asset_id');
    }
}
