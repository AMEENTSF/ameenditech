<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class BoardMeeting extends Model
{
    protected $table = 'board_meetings';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'held_at' => 'datetime',
        ];
    }

    public function minutesFile(): BelongsTo
    {
        return $this->belongsTo(File::class, 'minutes_file_id');
    }
}
