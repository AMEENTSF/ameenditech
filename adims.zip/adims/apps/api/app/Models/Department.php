<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Department extends Model
{
    protected $table = 'departments';

    protected $guarded = ['id'];

    public function head(): BelongsTo
    {
        return $this->belongsTo(User::class, 'head_id');
    }

    public function jobTitles(): HasMany
    {
        return $this->hasMany(JobTitle::class, 'department_id');
    }

    public function staffProfiles(): HasMany
    {
        return $this->hasMany(StaffProfile::class, 'department_id');
    }

    public function purchaseRequests(): HasMany
    {
        return $this->hasMany(PurchaseRequest::class, 'department_id');
    }
}
