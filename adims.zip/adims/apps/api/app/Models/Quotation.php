<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Quotation extends Model
{
    protected $table = 'quotations';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'total_kobo' => 'integer',
            'revision' => 'integer',
            'valid_until' => 'date',
            'accepted_at' => 'datetime',
            'lines' => 'array',
        ];
    }

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Contact::class, 'contact_id');
    }

    public function enquiry(): BelongsTo
    {
        return $this->belongsTo(Enquiry::class, 'enquiry_id');
    }

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function serviceProjects(): HasMany
    {
        return $this->hasMany(ServiceProject::class, 'quotation_id');
    }
}
