<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SupplierInvoice extends Model
{
    protected $table = 'supplier_invoices';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'total_kobo' => 'integer',
            'paid_kobo' => 'integer',
            'received_on' => 'date',
            'due_on' => 'date',
        ];
    }

    public function supplier(): BelongsTo
    {
        return $this->belongsTo(Supplier::class, 'supplier_id');
    }

    public function file(): BelongsTo
    {
        return $this->belongsTo(File::class, 'file_id');
    }
}
