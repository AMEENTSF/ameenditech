<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    protected $guarded = [];

    protected $hidden = ['password', 'remember_token', 'mfa_secret'];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'mfa_secret' => 'encrypted',
            'mfa_confirmed_at' => 'datetime',
            'last_login_at' => 'datetime',
        ];
    }

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Contact::class);
    }

    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class, 'user_roles')->withPivot('assigned_by');
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function hasRole(string $slug): bool
    {
        return $this->roles()->where('slug', $slug)->exists();
    }

    /** @var array<int,string>|null */
    private ?array $permissionCache = null;

    /** All permission slugs granted through the user's roles (memoised per request). */
    public function permissionSlugs(): array
    {
        return $this->permissionCache ??= Permission::query()
            ->whereHas('roles', fn ($q) => $q->whereIn('roles.id', $this->roles()->pluck('roles.id')))
            ->pluck('slug')->all();
    }

    /** Super administrators pass every permission check. */
    public function hasPermission(string $slug): bool
    {
        if (! $this->isActive()) {
            return false;
        }

        if ($this->hasRole('super-administrator')) {
            return true;
        }

        return in_array($slug, $this->permissionSlugs(), true);
    }

    public function requiresMfa(): bool
    {
        return $this->roles()->where('requires_mfa', true)->exists();
    }
}
