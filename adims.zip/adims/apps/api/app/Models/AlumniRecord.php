<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AlumniRecord extends Model
{
    protected $table = 'alumni_records';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'open_to_mentoring' => 'boolean',
            'consent_to_contact' => 'boolean',
        ];
    }

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Contact::class, 'contact_id');
    }

    public function enrolment(): BelongsTo
    {
        return $this->belongsTo(Enrolment::class, 'enrolment_id');
    }
}
