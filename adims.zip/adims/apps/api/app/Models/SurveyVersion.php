<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class SurveyVersion extends Model
{
    protected $table = 'survey_versions';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'version' => 'integer',
            'definition' => 'array',
            'published_at' => 'datetime',
        ];
    }

    public function surveyForm(): BelongsTo
    {
        return $this->belongsTo(SurveyForm::class, 'survey_form_id');
    }

    public function file(): BelongsTo
    {
        return $this->belongsTo(File::class, 'file_id');
    }

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function fieldAssignments(): HasMany
    {
        return $this->hasMany(FieldAssignment::class, 'survey_version_id');
    }
}
