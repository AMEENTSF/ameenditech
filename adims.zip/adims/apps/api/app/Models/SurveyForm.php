<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class SurveyForm extends Model
{
    protected $table = 'survey_forms';

    protected $guarded = ['id'];

    public function researchProject(): BelongsTo
    {
        return $this->belongsTo(ResearchProject::class, 'research_project_id');
    }

    public function surveyVersions(): HasMany
    {
        return $this->hasMany(SurveyVersion::class, 'survey_form_id');
    }
}
