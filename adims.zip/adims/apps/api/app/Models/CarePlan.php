<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class CarePlan extends Model
{
    protected $table = 'care_plans';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'monthly_fee_kobo' => 'integer',
            'starts_on' => 'date',
            'renews_on' => 'date',
            'auto_renew' => 'boolean',
        ];
    }

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Contact::class, 'contact_id');
    }

    public function supportTickets(): HasMany
    {
        return $this->hasMany(SupportTicket::class, 'care_plan_id');
    }

    public function carePlanRenewals(): HasMany
    {
        return $this->hasMany(CarePlanRenewal::class, 'care_plan_id');
    }
}
