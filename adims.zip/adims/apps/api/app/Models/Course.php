<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Course extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['fee_kobo' => 'integer'];
    }

    public function cohorts(): HasMany
    {
        return $this->hasMany(Cohort::class);
    }

    public function modules(): HasMany
    {
        return $this->hasMany(CourseModule::class, 'course_id');
    }

    public function applications(): HasMany
    {
        return $this->hasMany(Application::class, 'course_id');
    }
}
