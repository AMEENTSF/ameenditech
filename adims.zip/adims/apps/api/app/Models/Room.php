<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Room extends Model
{
    protected $table = 'rooms';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'capacity' => 'integer',
        ];
    }

    public function classSessions(): HasMany
    {
        return $this->hasMany(ClassSession::class, 'room_id');
    }
}
