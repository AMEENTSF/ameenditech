<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ResearchProject extends Model
{
    protected $table = 'research_projects';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'quoted_kobo' => 'integer',
            'deposit_basis_points' => 'integer',
            'deposit_kobo' => 'integer',
            'due_on' => 'date',
            'closed_at' => 'datetime',
        ];
    }

    public function clientContact(): BelongsTo
    {
        return $this->belongsTo(Contact::class, 'client_contact_id');
    }

    public function manager(): BelongsTo
    {
        return $this->belongsTo(User::class, 'manager_id');
    }

    public function datasets(): HasMany
    {
        return $this->hasMany(Dataset::class, 'research_project_id');
    }

    public function projectQuotes(): HasMany
    {
        return $this->hasMany(ProjectQuote::class, 'research_project_id');
    }

    public function projectTasks(): HasMany
    {
        return $this->hasMany(ProjectTask::class, 'research_project_id');
    }

    public function projectTeamMembers(): HasMany
    {
        return $this->hasMany(ProjectTeamMember::class, 'research_project_id');
    }

    public function surveyForms(): HasMany
    {
        return $this->hasMany(SurveyForm::class, 'research_project_id');
    }

    public function deliverables(): HasMany
    {
        return $this->hasMany(Deliverable::class, 'research_project_id');
    }

    public function projectFeedback(): HasMany
    {
        return $this->hasMany(ProjectFeedback::class, 'research_project_id');
    }

    public function tasks(): HasMany
    {
        return $this->hasMany(ProjectTask::class, 'research_project_id');
    }

    public function quotes(): HasMany
    {
        return $this->hasMany(ProjectQuote::class, 'research_project_id');
    }
}
