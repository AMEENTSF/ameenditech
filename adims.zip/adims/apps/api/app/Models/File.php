<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Support\Str;

/** Metadata for a privately stored object. The bytes live in S3-compatible private storage. */
class File extends Model
{
    protected $guarded = ['id'];

    protected static function booted(): void
    {
        static::creating(fn (self $f) => $f->uuid ??= (string) Str::uuid());
    }

    public function attachable(): MorphTo
    {
        return $this->morphTo();
    }
}
