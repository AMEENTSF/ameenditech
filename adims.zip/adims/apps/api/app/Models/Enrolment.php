<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Enrolment extends Model
{
    protected $guarded = [];

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Contact::class);
    }

    public function cohort(): BelongsTo
    {
        return $this->belongsTo(Cohort::class);
    }

    public function instalments(): HasMany
    {
        return $this->hasMany(EnrolmentInstalment::class, 'enrolment_id');
    }

    public function attendance(): HasMany
    {
        return $this->hasMany(AttendanceRecord::class, 'enrolment_id');
    }

    public function results(): HasMany
    {
        return $this->hasMany(AssessmentResult::class, 'enrolment_id');
    }
}
