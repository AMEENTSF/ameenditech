<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ServiceCatalogueItem extends Model
{
    protected $table = 'service_catalogue';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'base_price_kobo' => 'integer',
            'active' => 'boolean',
        ];
    }

    public function serviceProjects(): HasMany
    {
        return $this->hasMany(ServiceProject::class, 'service_catalogue_id');
    }
}
