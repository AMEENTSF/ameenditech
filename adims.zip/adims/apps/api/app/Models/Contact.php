<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Contact extends Model
{
    use HasFactory, SoftDeletes;

    protected $guarded = [];

    protected static function booted(): void
    {
        static::creating(fn (self $c) => $c->uuid ??= (string) Str::uuid());
    }

    public function user(): HasOne
    {
        return $this->hasOne(User::class);
    }

    public function getFullNameAttribute(): string
    {
        return trim("{$this->first_name} {$this->last_name}");
    }

    public function enquiries(): HasMany
    {
        return $this->hasMany(Enquiry::class, 'contact_id');
    }

    public function enrolments(): HasMany
    {
        return $this->hasMany(Enrolment::class, 'contact_id');
    }

    public function researchProjects(): HasMany
    {
        return $this->hasMany(ResearchProject::class, 'client_contact_id');
    }

    public function serviceProjects(): HasMany
    {
        return $this->hasMany(ServiceProject::class, 'contact_id');
    }

    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class, 'contact_id');
    }

    public function notes(): HasMany
    {
        return $this->hasMany(CustomerNote::class, 'contact_id');
    }

    public function communications(): HasMany
    {
        return $this->hasMany(Communication::class, 'contact_id');
    }

    public function organisation(): BelongsTo
    {
        return $this->belongsTo(Organisation::class);
    }

    public function consents(): HasMany
    {
        return $this->hasMany(Consent::class, 'contact_id');
    }

    public function feedback(): HasMany
    {
        return $this->hasMany(CustomerFeedback::class, 'contact_id');
    }
}
