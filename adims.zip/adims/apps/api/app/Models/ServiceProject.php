<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ServiceProject extends Model
{
    protected $table = 'service_projects';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'agreed_kobo' => 'integer',
            'starts_on' => 'date',
            'due_on' => 'date',
            'agreement_accepted_at' => 'datetime',
            'completed_at' => 'datetime',
        ];
    }

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Contact::class, 'contact_id');
    }

    public function serviceCatalogue(): BelongsTo
    {
        return $this->belongsTo(ServiceCatalogueItem::class, 'service_catalogue_id');
    }

    public function quotation(): BelongsTo
    {
        return $this->belongsTo(Quotation::class, 'quotation_id');
    }

    public function projectManager(): BelongsTo
    {
        return $this->belongsTo(User::class, 'project_manager_id');
    }

    public function serviceTasks(): HasMany
    {
        return $this->hasMany(ServiceTask::class, 'service_project_id');
    }

    public function milestones(): HasMany
    {
        return $this->hasMany(Milestone::class, 'service_project_id');
    }

    public function supportTickets(): HasMany
    {
        return $this->hasMany(SupportTicket::class, 'service_project_id');
    }
}
