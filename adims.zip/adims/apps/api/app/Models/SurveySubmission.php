<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SurveySubmission extends Model
{
    protected $table = 'survey_submissions';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'payload' => 'array',
            'collected_at' => 'datetime',
            'synced_at' => 'datetime',
            'gps_accuracy' => 'decimal:2',
        ];
    }

    public function fieldAssignment(): BelongsTo
    {
        return $this->belongsTo(FieldAssignment::class, 'field_assignment_id');
    }
}
