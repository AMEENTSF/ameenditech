<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class BankAccount extends Model
{
    protected $table = 'bank_accounts';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'opening_balance_kobo' => 'integer',
            'active' => 'boolean',
        ];
    }

    public function account(): BelongsTo
    {
        return $this->belongsTo(Account::class, 'account_id');
    }

    public function reconciliations(): HasMany
    {
        return $this->hasMany(Reconciliation::class, 'bank_account_id');
    }

    public function pettyCashEntries(): HasMany
    {
        return $this->hasMany(PettyCashEntry::class, 'bank_account_id');
    }
}
