<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class AccountCategory extends Model
{
    protected $table = 'account_categories';

    protected $guarded = ['id'];

    public function accounts(): HasMany
    {
        return $this->hasMany(Account::class, 'account_category_id');
    }
}
