<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Cohort extends Model
{
    protected $guarded = [];

    protected function casts(): array
    {
        return ['starts_on' => 'date', 'ends_on' => 'date'];
    }

    public function course(): BelongsTo
    {
        return $this->belongsTo(Course::class);
    }

    public function sessions(): HasMany
    {
        return $this->hasMany(ClassSession::class, 'cohort_id');
    }

    public function assessments(): HasMany
    {
        return $this->hasMany(Assessment::class, 'cohort_id');
    }

    public function assignments(): HasMany
    {
        return $this->hasMany(Assignment::class, 'cohort_id');
    }

    public function enrolments(): HasMany
    {
        return $this->hasMany(Enrolment::class, 'cohort_id');
    }
}
