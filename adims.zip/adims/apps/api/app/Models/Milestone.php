<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Milestone extends Model
{
    protected $table = 'milestones';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'due_on' => 'date',
            'amount_kobo' => 'integer',
            'approved_at' => 'datetime',
        ];
    }

    public function serviceProject(): BelongsTo
    {
        return $this->belongsTo(ServiceProject::class, 'service_project_id');
    }

    public function approvedByContact(): BelongsTo
    {
        return $this->belongsTo(Contact::class, 'approved_by_contact_id');
    }
}
