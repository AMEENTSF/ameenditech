<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class StaffProfile extends Model
{
    protected $table = 'staff_profiles';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'hired_on' => 'date',
            'left_on' => 'date',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Contact::class, 'contact_id');
    }

    public function department(): BelongsTo
    {
        return $this->belongsTo(Department::class, 'department_id');
    }

    public function jobTitle(): BelongsTo
    {
        return $this->belongsTo(JobTitle::class, 'job_title_id');
    }

    public function lineManager(): BelongsTo
    {
        return $this->belongsTo(User::class, 'line_manager_id');
    }

    public function employmentContracts(): HasMany
    {
        return $this->hasMany(EmploymentContract::class, 'staff_profile_id');
    }

    public function leaveRequests(): HasMany
    {
        return $this->hasMany(LeaveRequest::class, 'staff_profile_id');
    }

    public function staffAssignments(): HasMany
    {
        return $this->hasMany(StaffAssignment::class, 'staff_profile_id');
    }

    public function performanceReviews(): HasMany
    {
        return $this->hasMany(PerformanceReview::class, 'staff_profile_id');
    }

    public function staffTrainingRecords(): HasMany
    {
        return $this->hasMany(StaffTrainingRecord::class, 'staff_profile_id');
    }

    public function staffAttendance(): HasMany
    {
        return $this->hasMany(StaffAttendanceRecord::class, 'staff_profile_id');
    }

    public function payrollInputs(): HasMany
    {
        return $this->hasMany(PayrollInput::class, 'staff_profile_id');
    }

    public function assignments(): HasMany
    {
        return $this->hasMany(StaffAssignment::class, 'staff_profile_id');
    }
}
