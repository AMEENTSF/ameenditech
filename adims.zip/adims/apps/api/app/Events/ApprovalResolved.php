<?php

declare(strict_types=1);

namespace App\Events;

use App\Models\ApprovalRequest;
use Illuminate\Foundation\Events\Dispatchable;

class ApprovalResolved
{
    use Dispatchable;

    public function __construct(public readonly ApprovalRequest $request)
    {
    }
}
