<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\CarePlan;
use App\Models\CarePlanRenewal;
use App\Models\Invoice;
use Illuminate\Support\Facades\DB;

/** Monthly digital care plans: one renewal row and one invoice per billing period. */
class CarePlanService
{
    public function __construct(private ReferenceGenerator $refs, private JournalService $journal)
    {
    }

    public function generateRenewal(CarePlan $plan, ?int $userId = null): CarePlanRenewal
    {
        return DB::transaction(function () use ($plan, $userId) {
            $plan = CarePlan::whereKey($plan->id)->lockForUpdate()->firstOrFail();
            $start = $plan->renews_on->copy();

            $existing = CarePlanRenewal::where('care_plan_id', $plan->id)->whereDate('period_start', $start)->first();
            if ($existing) {
                return $existing;
            }

            $invoice = Invoice::create([
                'number' => $this->refs->next('INV'), 'contact_id' => $plan->contact_id, 'billable_type' => 'care_plan', 'billable_id' => $plan->id,
                'status' => 'issued', 'total_kobo' => $plan->monthly_fee_kobo, 'issued_on' => now('Africa/Lagos')->toDateString(),
                'due_on' => $start->toDateString(), 'created_by' => $userId,
            ]);
            $invoice->lines()->create(['description' => "{$plan->name} care plan: {$start->format('M Y')}", 'quantity' => 1, 'unit_price_kobo' => $plan->monthly_fee_kobo, 'line_total_kobo' => $plan->monthly_fee_kobo]);
            $this->journal->post("Invoice {$invoice->number} issued", [
                ['account' => $this->journal->code('receivable'), 'debit' => $plan->monthly_fee_kobo],
                ['account' => $this->journal->code('revenue'), 'credit' => $plan->monthly_fee_kobo],
            ], 'invoice', $invoice->id, null, $userId);

            $renewal = CarePlanRenewal::create([
                'care_plan_id' => $plan->id, 'invoice_id' => $invoice->id, 'period_start' => $start->toDateString(),
                'period_end' => $start->copy()->addMonth()->subDay()->toDateString(), 'status' => 'invoiced',
            ]);
            $plan->update(['renews_on' => $start->copy()->addMonth()->toDateString()]);

            return $renewal;
        });
    }
}
