<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Application;
use App\Models\AssessmentResult;
use App\Models\AlumniRecord;
use App\Models\AttendanceRecord;
use App\Models\Cohort;
use App\Models\Course;
use App\Models\Enrolment;
use App\Models\Invoice;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class EnrolmentService
{
    public function __construct(private ReferenceGenerator $refs, private JournalService $journal, private SettingsService $settings, private AuditLogger $audit)
    {
    }

    /** Admit an applicant to a cohort. Capacity is checked under a row lock so a cohort cannot be oversold. */
    public function admit(Application $application, Cohort $cohort, User $by, ?string $note = null): Application
    {
        return DB::transaction(function () use ($application, $cohort, $by, $note) {
            $application = Application::whereKey($application->id)->lockForUpdate()->firstOrFail();
            $cohort = Cohort::whereKey($cohort->id)->lockForUpdate()->firstOrFail();

            if (! in_array($application->status, ['submitted', 'under_review', 'waitlisted'], true)) {
                throw ValidationException::withMessages(['application' => 'This application can no longer be decided.']);
            }
            if ($cohort->course_id !== $application->course_id) {
                throw ValidationException::withMessages(['cohort' => 'Cohort belongs to a different course.']);
            }
            $this->assertPrerequisites($application);
            $this->assertCapacity($cohort, newSeat: true);

            $application->update(['status' => 'admitted', 'cohort_id' => $cohort->id, 'decided_by' => $by->id, 'decided_at' => now(), 'decision_note' => $note]);
            $this->audit->record('application.admitted', $application, null, ['cohort_id' => $cohort->id], $by->id);

            return $application;
        });
    }

    /**
     * Enrol an admitted applicant: creates the enrolment, an issued invoice for the course fee
     * and an instalment schedule (equal parts, remainder on the last, monthly due dates).
     */
    public function enrol(Application $application, int $instalments, User $by): Enrolment
    {
        return DB::transaction(function () use ($application, $instalments, $by) {
            $application = Application::whereKey($application->id)->lockForUpdate()->firstOrFail();
            if ($application->status !== 'admitted' || ! $application->cohort_id) {
                throw ValidationException::withMessages(['application' => 'Only admitted applicants can be enrolled.']);
            }
            $cohort = Cohort::whereKey($application->cohort_id)->lockForUpdate()->firstOrFail();
            $this->assertCapacity($cohort);
            $course = Course::findOrFail($cohort->course_id);

            $enrolment = Enrolment::firstOrCreate(
                ['cohort_id' => $cohort->id, 'contact_id' => $application->contact_id],
                ['status' => 'enrolled'],
            );

            $fee = (int) $course->fee_kobo;
            $invoice = Invoice::create([
                'number' => $this->refs->next('INV'), 'contact_id' => $application->contact_id, 'billable_type' => 'enrolment', 'billable_id' => $enrolment->id,
                'status' => 'issued', 'total_kobo' => $fee, 'issued_on' => now('Africa/Lagos')->toDateString(), 'due_on' => $cohort->starts_on, 'created_by' => $by->id,
            ]);
            $invoice->lines()->create(['description' => "{$course->title} tuition ({$cohort->name})", 'quantity' => 1, 'unit_price_kobo' => $fee, 'line_total_kobo' => $fee]);
            if ($fee > 0) {
                $this->journal->post("Invoice {$invoice->number} issued", [
                    ['account' => $this->journal->code('receivable'), 'debit' => $fee],
                    ['account' => $this->journal->code('revenue'), 'credit' => $fee],
                ], 'invoice', $invoice->id);
            }

            $base = intdiv($fee, $instalments);
            for ($i = 1; $i <= $instalments; $i++) {
                $amount = $i === $instalments ? $fee - $base * ($instalments - 1) : $base;
                $enrolment->instalments()->create([
                    'invoice_id' => $invoice->id, 'sequence' => $i, 'amount_kobo' => $amount,
                    'due_on' => $cohort->starts_on->copy()->addMonths($i - 1)->toDateString(),
                ]);
            }

            $this->audit->record('enrolment.created', $enrolment, null, ['invoice' => $invoice->number], $by->id);

            return $enrolment;
        });
    }

    /** Learner completion: minimum attendance AND weighted assessment score at or above the pass mark. */
    public function evaluateCompletion(Enrolment $enrolment, User $by): array
    {
        $minAttendance = (int) $this->settings->get('training.min_attendance_percent', 75);
        $passMark = (int) $this->settings->get('training.pass_mark_percent', 50);

        $attendance = $this->attendancePercent($enrolment);
        $score = $this->weightedScore($enrolment);
        $passed = $attendance >= $minAttendance && $score >= $passMark;

        if ($passed && $enrolment->status !== 'completed') {
            DB::transaction(function () use ($enrolment, $by) {
                $enrolment->update(['status' => 'completed']);
                AlumniRecord::firstOrCreate(['contact_id' => $enrolment->contact_id], ['enrolment_id' => $enrolment->id]);
                $this->audit->record('enrolment.completed', $enrolment, null, null, $by->id);
            });
        }

        return ['passed' => $passed, 'attendance_percent' => $attendance, 'score_percent' => $score, 'required_attendance' => $minAttendance, 'pass_mark' => $passMark];
    }

    public function attendancePercent(Enrolment $enrolment): int
    {
        $rows = AttendanceRecord::where('enrolment_id', $enrolment->id)->get(['status']);
        if ($rows->isEmpty()) {
            return 0;
        }
        $attended = $rows->whereIn('status', ['present', 'late', 'excused'])->count();

        return intdiv($attended * 100, $rows->count());
    }

    /** Sum of (score / max) × weight across weighted assessments, normalised to a percentage of total weight. */
    public function weightedScore(Enrolment $enrolment): int
    {
        $results = AssessmentResult::with('assessment')->where('enrolment_id', $enrolment->id)->get();
        $weight = 0;
        $earned = 0.0;
        foreach ($results as $r) {
            $a = $r->assessment;
            if (! $a || $a->weight_percent <= 0 || $a->max_score <= 0) {
                continue;
            }
            $weight += $a->weight_percent;
            $earned += ((float) $r->score / $a->max_score) * $a->weight_percent; // academic score, not money
        }

        return $weight === 0 ? 0 : (int) round($earned * 100 / $weight);
    }

    /**
     * Seats taken = enrolments + admitted applicants not yet enrolled. Called while the cohort row is locked.
     * When enrolling an already-admitted applicant their own seat is already counted, so the check is "over capacity", not "at capacity".
     */
    private function assertCapacity(Cohort $cohort, bool $newSeat = false): void
    {
        if ($cohort->capacity === null) {
            return;
        }

        $enrolled = Enrolment::where('cohort_id', $cohort->id)->count();
        $admittedPending = Application::where('cohort_id', $cohort->id)->where('status', 'admitted')
            ->whereNotIn('contact_id', Enrolment::where('cohort_id', $cohort->id)->select('contact_id'))->count();

        if ($enrolled + $admittedPending + ($newSeat ? 1 : 0) > $cohort->capacity) {
            throw ValidationException::withMessages(['cohort' => 'This cohort is full.']);
        }
    }

    private function assertPrerequisites(Application $application): void
    {
        $required = DB::table('course_prerequisites')->where('course_id', $application->course_id)->pluck('prerequisite_course_id');
        if ($required->isEmpty()) {
            return;
        }
        $done = Enrolment::where('contact_id', $application->contact_id)->where('status', 'completed')
            ->join('cohorts', 'cohorts.id', '=', 'enrolments.cohort_id')->pluck('cohorts.course_id');
        if ($required->diff($done)->isNotEmpty()) {
            throw ValidationException::withMessages(['application' => 'The applicant has not completed the required prerequisite courses.']);
        }
    }
}
