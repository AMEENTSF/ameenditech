<?php

declare(strict_types=1);

namespace App\Services;

use App\Enums\ResearchStage;
use App\Models\Deliverable;
use App\Models\Invoice;
use App\Models\ProjectFeedback;
use App\Models\ProjectQuote;
use App\Models\ResearchProject;
use App\Models\User;
use App\Support\Money;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Enquiry → Scope → Quotation → Client Acceptance → Deposit → Execution → Quality Review →
 * Client Delivery → Balance Payment → Feedback → Closure.
 * A project moves forward one stage at a time and only when the gate for the target stage passes.
 */
class ResearchWorkflowService
{
    public function __construct(private ProjectReferenceService $references, private SettingsService $settings, private AuditLogger $audit)
    {
    }

    public function open(array $data, User $by): ResearchProject
    {
        $basisPoints = (int) $this->settings->get('research.deposit_basis_points', config('adims.research.default_deposit_basis_points'));

        $project = ResearchProject::create($data + [
            'reference' => $this->references->next(),
            'stage' => ResearchStage::Enquiry->value,
            'deposit_basis_points' => $basisPoints,
        ]);
        $this->audit->record('research.opened', $project, null, ['reference' => $project->reference], $by->id);

        return $project;
    }

    public function advance(ResearchProject $project, User $by, bool $waiveFeedback = false): ResearchProject
    {
        return DB::transaction(function () use ($project, $by, $waiveFeedback) {
            $project = ResearchProject::whereKey($project->id)->lockForUpdate()->firstOrFail();
            $current = ResearchStage::from($project->stage);
            $target = $current->next();

            if (! $target) {
                throw ValidationException::withMessages(['stage' => 'Project is already closed.']);
            }

            if ($target === ResearchStage::Closed && ! $by->hasPermission('research.projects.close')) {
                abort(403, 'You cannot close projects.');
            }

            $this->assertGate($project, $target, $waiveFeedback);

            $project->update([
                'stage' => $target->value,
                'closed_at' => $target === ResearchStage::Closed ? now() : null,
            ]);
            $this->audit->record('research.stage_changed', $project, ['stage' => $current->value], ['stage' => $target->value], $by->id);

            return $project;
        });
    }

    /** Create a new quote revision; earlier open revisions are superseded. */
    public function quote(ResearchProject $project, int $amountKobo, ?string $summary, User $by): ProjectQuote
    {
        return DB::transaction(function () use ($project, $amountKobo, $summary, $by) {
            $revision = (int) ProjectQuote::where('research_project_id', $project->id)->max('revision') + 1;
            ProjectQuote::where('research_project_id', $project->id)->whereIn('status', ['draft', 'sent'])->update(['status' => 'superseded']);

            return ProjectQuote::create([
                'research_project_id' => $project->id,
                'revision' => $revision,
                'amount_kobo' => $amountKobo,
                'scope_summary' => $summary,
                'status' => 'sent',
                'created_by' => $by->id,
            ]);
        });
    }

    /** Client acceptance fixes the price and calculates the configurable deposit. */
    public function acceptQuote(ProjectQuote $quote, User $by): ResearchProject
    {
        return DB::transaction(function () use ($quote, $by) {
            $quote = ProjectQuote::whereKey($quote->id)->lockForUpdate()->firstOrFail();
            if ($quote->status !== 'sent') {
                throw ValidationException::withMessages(['quote' => 'Only the current sent quote can be accepted.']);
            }
            $project = ResearchProject::whereKey($quote->research_project_id)->lockForUpdate()->firstOrFail();
            $deposit = $this->references->depositFor(Money::fromKobo($quote->amount_kobo), $project->deposit_basis_points);

            $quote->update(['status' => 'accepted', 'accepted_at' => now()]);
            $project->update(['quoted_kobo' => $quote->amount_kobo, 'deposit_kobo' => $deposit->kobo]);
            $this->audit->record('research.quote_accepted', $project, null, ['quote' => $quote->revision, 'deposit_kobo' => $deposit->kobo], $by->id);

            return $project;
        });
    }

    private function assertGate(ResearchProject $project, ResearchStage $target, bool $waiveFeedback): void
    {
        $fail = fn (string $m) => throw ValidationException::withMessages(['stage' => $m]);

        match ($target) {
            ResearchStage::Scope => null,
            ResearchStage::Quotation => blank($project->scope) ? $fail('Define the project scope first.') : null,
            ResearchStage::ClientAcceptance => ProjectQuote::where('research_project_id', $project->id)->whereIn('status', ['sent', 'accepted'])->exists() ? null : $fail('Send a quotation first.'),
            ResearchStage::Deposit => $project->quoted_kobo === null ? $fail('The client has not accepted a quotation.') : null,
            ResearchStage::Execution => $this->depositPaid($project) ? null : $fail('The deposit has not been fully paid and verified.'),
            ResearchStage::QualityReview => Deliverable::where('research_project_id', $project->id)->whereIn('status', ['draft', 'in_review'])->exists() ? null : $fail('Upload at least one deliverable for review.'),
            ResearchStage::ClientDelivery => $this->secondReaderApproved($project) ? null : $fail('Every deliverable needs approval from a second reader who is not its author.'),
            ResearchStage::BalancePayment => Deliverable::where('research_project_id', $project->id)->where('status', 'approved')->exists()
                && ! Deliverable::where('research_project_id', $project->id)->whereIn('status', ['draft', 'in_review'])->exists() ? null : $fail('Deliver the approved deliverables to the client first.'),
            ResearchStage::Feedback => $this->paidKobo($project) >= (int) $project->quoted_kobo ? null : $fail('The balance has not been fully paid.'),
            ResearchStage::Closed => ($waiveFeedback || ProjectFeedback::where('research_project_id', $project->id)->exists()) ? null : $fail('Record client feedback or explicitly waive it.'),
        };
    }

    private function paidKobo(ResearchProject $project): int
    {
        return (int) Invoice::where('billable_type', 'research_project')->where('billable_id', $project->id)
            ->whereNotIn('status', ['void', 'draft'])->sum('paid_kobo');
    }

    private function depositPaid(ResearchProject $project): bool
    {
        return $this->paidKobo($project) >= (int) $project->deposit_kobo;
    }

    private function secondReaderApproved(ResearchProject $project): bool
    {
        $deliverables = Deliverable::where('research_project_id', $project->id)->whereIn('status', ['draft', 'in_review', 'approved'])->get();
        if ($deliverables->isEmpty()) {
            return false;
        }

        return $deliverables->every(fn (Deliverable $d) => $d->status === 'approved'
            && $d->qualityReviews()->where('outcome', 'approved')->where('reviewer_id', '!=', $d->created_by)->exists());
    }
}
