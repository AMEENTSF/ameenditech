<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Certificate;
use App\Models\Enrolment;
use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class CertificateService
{
    public function issue(Enrolment $enrolment, User $issuer): Certificate
    {
        if ($enrolment->status !== 'completed') {
            throw ValidationException::withMessages(['enrolment' => 'Only completed enrolments can receive a certificate.']);
        }

        return Certificate::create([
            'enrolment_id' => $enrolment->id,
            'verification_number' => $this->newVerificationNumber(),
            'issued_at' => now(),
            'issued_by' => $issuer->id,
        ]);
    }

    /**
     * Public verification returns only approved fields: holder name, course, issue date, validity.
     * No email, phone, grades or internal IDs.
     */
    public function publicVerification(string $verificationNumber): ?array
    {
        $cert = Certificate::with('enrolment.contact', 'enrolment.cohort.course')
            ->where('verification_number', $verificationNumber)
            ->first();

        if (! $cert) {
            return null;
        }

        return [
            'valid' => $cert->revoked_at === null,
            'holder' => $cert->enrolment->contact->full_name,
            'course' => $cert->enrolment->cohort->course->title,
            'issued_on' => $cert->issued_at->toDateString(),
        ];
    }

    private function newVerificationNumber(): string
    {
        do {
            $number = 'ADT-' . strtoupper(Str::random(4)) . '-' . strtoupper(Str::random(4)) . '-' . strtoupper(Str::random(4));
        } while (Certificate::where('verification_number', $number)->exists());

        return $number;
    }
}
