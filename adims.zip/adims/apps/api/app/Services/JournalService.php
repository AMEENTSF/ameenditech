<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Account;
use App\Models\JournalEntry;
use Carbon\CarbonInterface;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/** Double-entry posting. An unbalanced entry can never be stored. */
class JournalService
{
    public function __construct(private ReferenceGenerator $references)
    {
    }

    /**
     * @param array<int, array{account: string, debit?: int, credit?: int}> $lines amounts in kobo; account is the account code
     */
    public function post(string $memo, array $lines, ?string $sourceType = null, ?int $sourceId = null, ?CarbonInterface $date = null, ?int $userId = null): JournalEntry
    {
        $debit = array_sum(array_column($lines, 'debit'));
        $credit = array_sum(array_column($lines, 'credit'));

        if (count($lines) < 2 || $debit <= 0 || $debit !== $credit) {
            throw ValidationException::withMessages(['journal' => 'Journal entry must have at least two lines and balance exactly.']);
        }

        return DB::transaction(function () use ($memo, $lines, $sourceType, $sourceId, $date, $userId) {
            $accounts = Account::whereIn('code', array_column($lines, 'account'))->pluck('id', 'code');

            $entry = JournalEntry::create([
                'number' => $this->references->next('JE'),
                'entry_date' => ($date ?? now('Africa/Lagos'))->toDateString(),
                'memo' => $memo,
                'source_type' => $sourceType,
                'source_id' => $sourceId,
                'posted_by' => $userId ?? auth()->id(),
            ]);

            foreach ($lines as $line) {
                $id = $accounts[$line['account']] ?? null;
                if (! $id) {
                    throw ValidationException::withMessages(['journal' => "Account {$line['account']} is not in the chart of accounts."]);
                }
                $entry->lines()->create([
                    'account_id' => $id,
                    'debit_kobo' => $line['debit'] ?? 0,
                    'credit_kobo' => $line['credit'] ?? 0,
                ]);
            }

            return $entry;
        });
    }

    public function code(string $key): string
    {
        return (string) app(SettingsService::class)->get("accounts.{$key}", config("adims.accounts.{$key}"));
    }
}
