<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\SystemSetting;
use Illuminate\Support\Facades\Cache;

/** Runtime-configurable settings (thresholds, deposit rule) with config/adims.php as the fallback. */
class SettingsService
{
    public function get(string $key, mixed $default = null): mixed
    {
        $all = Cache::remember('system_settings', 300, fn () => SystemSetting::pluck('value', 'key')->all());

        return $all[$key] ?? $default;
    }

    public function set(string $key, mixed $value, ?int $userId = null): void
    {
        $before = SystemSetting::where('key', $key)->first()?->value;
        $row = SystemSetting::updateOrCreate(['key' => $key], ['value' => $value, 'updated_by' => $userId]);
        Cache::forget('system_settings');
        app(AuditLogger::class)->record('setting.updated', $row, ['value' => $before], ['value' => $value], $userId);
    }
}
