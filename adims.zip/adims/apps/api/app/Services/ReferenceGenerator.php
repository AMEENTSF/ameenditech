<?php

declare(strict_types=1);

namespace App\Services;

use Illuminate\Support\Facades\DB;

/** Gap-free, race-safe yearly references such as ENQ-2026-0001. */
class ReferenceGenerator
{
    public function next(string $prefix, ?int $year = null): string
    {
        $year ??= (int) now('Africa/Lagos')->year;

        return DB::transaction(function () use ($prefix, $year) {
            DB::table('reference_counters')->insertOrIgnore(['prefix' => $prefix, 'year' => $year, 'last_number' => 0]);

            $row = DB::table('reference_counters')
                ->where('prefix', $prefix)->where('year', $year)
                ->lockForUpdate()->first();

            $number = $row->last_number + 1;
            DB::table('reference_counters')->where('prefix', $prefix)->where('year', $year)->update(['last_number' => $number]);

            return sprintf('%s-%d-%04d', $prefix, $year, $number);
        });
    }
}
