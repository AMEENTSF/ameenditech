<?php

declare(strict_types=1);

namespace App\Services;

use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;

/**
 * Report catalogue. Each report returns ['title', 'columns' => [key => [label, type]], 'rows' => []].
 * Column types: text, int, kobo, date, percent, decimal. Money stays in integer kobo until formatted for display/export.
 */
class ReportService
{
    /** slug => permission needed to run it */
    public const CATALOGUE = [
        'revenue' => 'finance.reports.view',
        'expenses' => 'finance.reports.view',
        'cash-flow' => 'finance.reports.view',
        'profit-loss' => 'finance.reports.view',
        'customer-performance' => 'crm.contacts.view',
        'research-projects' => 'research.projects.view_all',
        'research-turnaround' => 'research.projects.view_all',
        'learner-enrolment' => 'training.courses.view',
        'attendance' => 'training.attendance.view',
        'course-completion' => 'training.courses.view',
        'certificate-issuance' => 'training.certificates.view',
        'instructor-performance' => 'training.courses.view',
        'digital-service-projects' => 'services.projects.view',
        'care-plan-renewals' => 'services.care_plans.view',
        'staff-performance' => 'hr.reviews.view',
        'asset-utilisation' => 'procurement.assets.view',
        'pending-approvals' => 'finance.reports.view',
    ];

    public function run(string $slug, CarbonImmutable $from, CarbonImmutable $to): array
    {
        return match ($slug) {
            'revenue' => $this->revenue($from, $to),
            'expenses' => $this->expenses($from, $to),
            'cash-flow' => $this->cashFlow($from, $to),
            'profit-loss' => $this->profitLoss($from, $to),
            'customer-performance' => $this->customers($from, $to),
            'research-projects' => $this->researchProjects(),
            'research-turnaround' => $this->researchTurnaround($from, $to),
            'learner-enrolment' => $this->enrolment(),
            'attendance' => $this->attendance(),
            'course-completion' => $this->completion(),
            'certificate-issuance' => $this->certificates($from, $to),
            'instructor-performance' => $this->instructors($from, $to),
            'digital-service-projects' => $this->serviceProjects(),
            'care-plan-renewals' => $this->carePlans(),
            'staff-performance' => $this->staffPerformance(),
            'asset-utilisation' => $this->assets(),
            'pending-approvals' => $this->pendingApprovals(),
        };
    }

    private function out(string $title, array $columns, $rows): array
    {
        return ['title' => $title, 'columns' => $columns, 'rows' => collect($rows)->map(fn ($r) => (array) $r)->values()->all()];
    }

    private function revenue($from, $to): array
    {
        return $this->out('Revenue by month', ['month' => ['Month', 'text'], 'invoices' => ['Invoices', 'int'], 'billed_kobo' => ['Billed', 'kobo'], 'paid_kobo' => ['Collected on invoices', 'kobo']],
            DB::table('invoices')->whereNotIn('status', ['draft', 'void'])->whereBetween('issued_on', [$from, $to])
                ->selectRaw("to_char(issued_on, 'YYYY-MM') as month, COUNT(*) as invoices, SUM(total_kobo) as billed_kobo, SUM(paid_kobo) as paid_kobo")->groupBy('month')->orderBy('month')->get());
    }

    private function expenses($from, $to): array
    {
        return $this->out('Expenses by category (paid)', ['category' => ['Category', 'text'], 'count' => ['Count', 'int'], 'total_kobo' => ['Total', 'kobo']],
            DB::table('expenses')->leftJoin('expense_categories', 'expense_categories.id', '=', 'expenses.expense_category_id')->where('expenses.status', 'paid')
                ->whereBetween('expenses.paid_at', [$from->startOfDay(), $to->endOfDay()])
                ->selectRaw("COALESCE(expense_categories.name, 'Uncategorised') as category, COUNT(*) as count, SUM(expenses.amount_kobo) as total_kobo")->groupBy('category')->orderByDesc('total_kobo')->get());
    }

    private function cashFlow($from, $to): array
    {
        $in = DB::table('payments')->where('status', 'verified')->whereBetween('verified_at', [$from->startOfDay(), $to->endOfDay()])
            ->selectRaw("to_char(verified_at, 'YYYY-MM') as month, SUM(amount_kobo) as kobo")->groupBy('month')->pluck('kobo', 'month');
        $outflow = DB::table('expenses')->where('status', 'paid')->whereBetween('paid_at', [$from->startOfDay(), $to->endOfDay()])
            ->selectRaw("to_char(paid_at, 'YYYY-MM') as month, SUM(amount_kobo) as kobo")->groupBy('month')->pluck('kobo', 'month');
        $rows = $in->keys()->merge($outflow->keys())->unique()->sort()->map(fn ($m) => [
            'month' => $m, 'inflow_kobo' => (int) ($in[$m] ?? 0), 'outflow_kobo' => (int) ($outflow[$m] ?? 0), 'net_kobo' => (int) ($in[$m] ?? 0) - (int) ($outflow[$m] ?? 0),
        ]);

        return $this->out('Cash flow', ['month' => ['Month', 'text'], 'inflow_kobo' => ['Cash in', 'kobo'], 'outflow_kobo' => ['Cash out', 'kobo'], 'net_kobo' => ['Net', 'kobo']], $rows);
    }

    /** Built from the double-entry ledger, so it always agrees with the books. */
    private function profitLoss($from, $to): array
    {
        $rows = DB::table('journal_entry_lines as l')->join('journal_entries as e', 'e.id', '=', 'l.journal_entry_id')->join('accounts as a', 'a.id', '=', 'l.account_id')
            ->join('account_categories as c', 'c.id', '=', 'a.account_category_id')->whereIn('c.kind', ['income', 'expense'])->whereBetween('e.entry_date', [$from, $to])
            ->selectRaw("a.code, a.name, c.kind, SUM(CASE WHEN c.kind = 'income' THEN l.credit_kobo - l.debit_kobo ELSE l.debit_kobo - l.credit_kobo END) as amount_kobo")
            ->groupBy('a.code', 'a.name', 'c.kind')->orderBy('c.kind')->orderBy('a.code')->get();
        $net = $rows->where('kind', 'income')->sum('amount_kobo') - $rows->where('kind', 'expense')->sum('amount_kobo');
        $rows->push((object) ['code' => '', 'name' => 'NET PROFIT / (LOSS)', 'kind' => 'net', 'amount_kobo' => $net]);

        return $this->out('Profit and loss', ['code' => ['Code', 'text'], 'name' => ['Account', 'text'], 'kind' => ['Type', 'text'], 'amount_kobo' => ['Amount', 'kobo']], $rows);
    }

    private function customers($from, $to): array
    {
        return $this->out('Customer performance', ['customer' => ['Customer', 'text'], 'invoices' => ['Invoices', 'int'], 'billed_kobo' => ['Billed', 'kobo'], 'paid_kobo' => ['Paid', 'kobo'], 'outstanding_kobo' => ['Outstanding', 'kobo']],
            DB::table('invoices')->join('contacts', 'contacts.id', '=', 'invoices.contact_id')->whereNotIn('invoices.status', ['draft', 'void'])->whereBetween('invoices.issued_on', [$from, $to])
                ->selectRaw("contacts.first_name || ' ' || contacts.last_name as customer, COUNT(*) as invoices, SUM(total_kobo) as billed_kobo, SUM(paid_kobo) as paid_kobo, SUM(total_kobo - paid_kobo) as outstanding_kobo")
                ->groupBy('contacts.id', 'customer')->orderByDesc('billed_kobo')->limit(200)->get());
    }

    private function researchProjects(): array
    {
        return $this->out('Research projects', ['reference' => ['Reference', 'text'], 'title' => ['Title', 'text'], 'client' => ['Client', 'text'], 'stage' => ['Stage', 'text'], 'quoted_kobo' => ['Quoted', 'kobo'], 'due_on' => ['Due', 'date']],
            DB::table('research_projects as p')->join('contacts as c', 'c.id', '=', 'p.client_contact_id')->selectRaw("p.reference, p.title, c.first_name || ' ' || c.last_name as client, p.stage, p.quoted_kobo, p.due_on")->orderByDesc('p.id')->limit(1000)->get());
    }

    private function researchTurnaround($from, $to): array
    {
        return $this->out('Research turnaround (closed projects)', ['reference' => ['Reference', 'text'], 'title' => ['Title', 'text'], 'days' => ['Days to close', 'decimal']],
            DB::table('research_projects')->whereNotNull('closed_at')->whereBetween('closed_at', [$from->startOfDay(), $to->endOfDay()])
                ->selectRaw('reference, title, ROUND(EXTRACT(EPOCH FROM (closed_at - created_at)) / 86400) as days')->orderBy('days')->get());
    }

    private function enrolment(): array
    {
        return $this->out('Learner enrolment by cohort', ['course' => ['Course', 'text'], 'cohort' => ['Cohort', 'text'], 'capacity' => ['Capacity', 'int'], 'enrolled' => ['Enrolled', 'int'], 'completed' => ['Completed', 'int']],
            DB::table('cohorts as h')->join('courses as c', 'c.id', '=', 'h.course_id')->leftJoin('enrolments as e', 'e.cohort_id', '=', 'h.id')
                ->selectRaw("c.title as course, h.name as cohort, h.capacity, COUNT(e.id) as enrolled, COUNT(e.id) FILTER (WHERE e.status = 'completed') as completed")->groupBy('h.id', 'c.title', 'h.name', 'h.capacity')->orderByDesc('h.starts_on')->get());
    }

    private function attendance(): array
    {
        return $this->out('Attendance by learner', ['cohort' => ['Cohort', 'text'], 'learner' => ['Learner', 'text'], 'sessions' => ['Sessions', 'int'], 'attended' => ['Attended', 'int'], 'percent' => ['Attendance', 'percent']],
            DB::table('attendance_records as a')->join('enrolments as e', 'e.id', '=', 'a.enrolment_id')->join('cohorts as h', 'h.id', '=', 'e.cohort_id')->join('contacts as c', 'c.id', '=', 'e.contact_id')
                ->selectRaw("h.name as cohort, c.first_name || ' ' || c.last_name as learner, COUNT(*) as sessions, COUNT(*) FILTER (WHERE a.status IN ('present','late','excused')) as attended, ROUND(100.0 * COUNT(*) FILTER (WHERE a.status IN ('present','late','excused')) / COUNT(*)) as percent")
                ->groupBy('h.name', 'e.id', 'learner')->orderBy('percent')->limit(1000)->get());
    }

    private function completion(): array
    {
        return $this->out('Course completion', ['course' => ['Course', 'text'], 'enrolled' => ['Enrolments', 'int'], 'completed' => ['Completed', 'int'], 'rate' => ['Completion rate', 'percent']],
            DB::table('courses as c')->join('cohorts as h', 'h.course_id', '=', 'c.id')->join('enrolments as e', 'e.cohort_id', '=', 'h.id')
                ->selectRaw("c.title as course, COUNT(*) as enrolled, COUNT(*) FILTER (WHERE e.status = 'completed') as completed, ROUND(100.0 * COUNT(*) FILTER (WHERE e.status = 'completed') / COUNT(*)) as rate")->groupBy('c.id', 'c.title')->orderBy('c.title')->get());
    }

    private function certificates($from, $to): array
    {
        return $this->out('Certificate issuance', ['month' => ['Month', 'text'], 'issued' => ['Issued', 'int'], 'revoked' => ['Revoked', 'int']],
            DB::table('certificates')->whereBetween('issued_at', [$from->startOfDay(), $to->endOfDay()])
                ->selectRaw("to_char(issued_at, 'YYYY-MM') as month, COUNT(*) as issued, COUNT(revoked_at) as revoked")->groupBy('month')->orderBy('month')->get());
    }

    private function instructors($from, $to): array
    {
        return $this->out('Instructor performance', ['instructor' => ['Instructor', 'text'], 'sessions' => ['Sessions held', 'int'], 'avg_attendance' => ['Avg attendance', 'percent']],
            DB::table('class_sessions as s')->join('users as u', 'u.id', '=', 's.instructor_id')->join('contacts as c', 'c.id', '=', 'u.contact_id')
                ->leftJoin('attendance_records as a', 'a.class_session_id', '=', 's.id')->where('s.status', 'held')->whereBetween('s.starts_at', [$from->startOfDay(), $to->endOfDay()])
                ->selectRaw("c.first_name || ' ' || c.last_name as instructor, COUNT(DISTINCT s.id) as sessions, ROUND(100.0 * COUNT(a.id) FILTER (WHERE a.status IN ('present','late','excused')) / NULLIF(COUNT(a.id), 0)) as avg_attendance")
                ->groupBy('u.id', 'instructor')->orderByDesc('sessions')->get());
    }

    private function serviceProjects(): array
    {
        return $this->out('Digital service projects', ['reference' => ['Reference', 'text'], 'title' => ['Title', 'text'], 'status' => ['Status', 'text'], 'agreed_kobo' => ['Agreed', 'kobo'], 'due_on' => ['Due', 'date']],
            DB::table('service_projects')->select('reference', 'title', 'status', 'agreed_kobo', 'due_on')->orderByDesc('id')->limit(1000)->get());
    }

    private function carePlans(): array
    {
        return $this->out('Care plan renewals', ['plan' => ['Plan', 'text'], 'client' => ['Client', 'text'], 'monthly_fee_kobo' => ['Monthly fee', 'kobo'], 'renews_on' => ['Renews', 'date'], 'status' => ['Status', 'text']],
            DB::table('care_plans as p')->join('contacts as c', 'c.id', '=', 'p.contact_id')->selectRaw("p.name as plan, c.first_name || ' ' || c.last_name as client, p.monthly_fee_kobo, p.renews_on, p.status")->orderBy('p.renews_on')->get());
    }

    private function staffPerformance(): array
    {
        return $this->out('Staff performance (latest review)', ['staff' => ['Staff', 'text'], 'period' => ['Period', 'text'], 'rating' => ['Rating', 'decimal'], 'status' => ['Status', 'text']],
            DB::table('performance_reviews as r')->join('staff_profiles as s', 's.id', '=', 'r.staff_profile_id')->join('contacts as c', 'c.id', '=', 's.contact_id')
                ->selectRaw("c.first_name || ' ' || c.last_name as staff, r.period, r.rating, r.status")->orderByDesc('r.id')->limit(500)->get());
    }

    private function assets(): array
    {
        return $this->out('Asset utilisation', ['category' => ['Category', 'text'], 'total' => ['Total', 'int'], 'assigned' => ['Assigned', 'int'], 'available' => ['Available', 'int'], 'maintenance' => ['In maintenance', 'int'], 'utilisation' => ['Utilisation', 'percent']],
            DB::table('assets')->where('status', '!=', 'disposed')->whereNull('deleted_at')
                ->selectRaw("category, COUNT(*) as total, COUNT(*) FILTER (WHERE status = 'assigned') as assigned, COUNT(*) FILTER (WHERE status = 'available') as available, COUNT(*) FILTER (WHERE status = 'maintenance') as maintenance, ROUND(100.0 * COUNT(*) FILTER (WHERE status = 'assigned') / COUNT(*)) as utilisation")->groupBy('category')->orderBy('category')->get());
    }

    private function pendingApprovals(): array
    {
        return $this->out('Pending approvals', ['type' => ['Type', 'text'], 'subject_id' => ['Record ID', 'int'], 'amount_kobo' => ['Amount', 'kobo'], 'recorded' => ['Approvals', 'int'], 'required_approvals' => ['Required', 'int'], 'created_at' => ['Requested', 'date']],
            DB::table('approval_requests as r')->where('r.status', 'pending')
                ->selectRaw("r.subject_type as type, r.subject_id, r.amount_kobo, (SELECT COUNT(*) FROM approval_decisions d WHERE d.approval_request_id = r.id AND d.decision = 'approved') as recorded, r.required_approvals, r.created_at")->orderBy('r.created_at')->get());
    }
}
