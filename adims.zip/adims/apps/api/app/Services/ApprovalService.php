<?php

declare(strict_types=1);

namespace App\Services;

use App\Enums\ApprovalStatus;
use App\Events\ApprovalResolved;
use App\Models\ApprovalRequest;
use App\Models\User;
use App\Support\Money;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Enforces the two-approver rule for transactions above the configured threshold.
 * All checks run server-side inside a transaction; the client cannot influence them.
 */
class ApprovalService
{
    public function thresholdKobo(): int
    {
        return (int) app(SettingsService::class)->get(
            'finance.dual_approval_threshold_kobo',
            config('adims.finance.dual_approval_threshold_kobo'),
        );
    }

    public function requiredApprovalsFor(Money $amount): int
    {
        return $amount->kobo > $this->thresholdKobo()
            ? (int) config('adims.finance.required_approvals_above_threshold')
            : 1;
    }

    public function request(Model $subject, User $requester, Money $amount): ApprovalRequest
    {
        return ApprovalRequest::create([
            'subject_type' => $subject->getMorphClass(),
            'subject_id' => $subject->getKey(),
            'requested_by' => $requester->id,
            'amount_kobo' => $amount->kobo,
            'required_approvals' => $this->requiredApprovalsFor($amount),
            'status' => ApprovalStatus::Pending,
        ]);
    }

    public function approve(ApprovalRequest $request, User $approver, ?string $comment = null): ApprovalRequest
    {
        $result = DB::transaction(function () use ($request, $approver, $comment) {
            /** @var ApprovalRequest $locked */
            $locked = ApprovalRequest::whereKey($request->id)->lockForUpdate()->firstOrFail();

            if ($locked->status !== ApprovalStatus::Pending) {
                throw ValidationException::withMessages(['approval' => 'This request is no longer pending.']);
            }

            if ($locked->requested_by === $approver->id) {
                throw ValidationException::withMessages(['approval' => 'Requesters cannot approve their own requests.']);
            }

            if ($locked->decisions()->where('approver_id', $approver->id)->exists()) {
                throw ValidationException::withMessages(['approval' => 'You have already recorded a decision on this request.']);
            }

            $locked->decisions()->create([
                'approver_id' => $approver->id,
                'decision' => 'approved',
                'comment' => $comment,
            ]);

            $approvedCount = $locked->decisions()->where('decision', 'approved')->count();

            if ($approvedCount >= $locked->required_approvals) {
                $locked->update(['status' => ApprovalStatus::Approved, 'resolved_at' => now()]);
            }

            return $locked->refresh();
        });

        $this->announce($result);

        return $result;
    }

    public function reject(ApprovalRequest $request, User $approver, string $comment): ApprovalRequest
    {
        $result = DB::transaction(function () use ($request, $approver, $comment) {
            $locked = ApprovalRequest::whereKey($request->id)->lockForUpdate()->firstOrFail();

            if ($locked->status !== ApprovalStatus::Pending) {
                throw ValidationException::withMessages(['approval' => 'This request is no longer pending.']);
            }

            $locked->decisions()->create([
                'approver_id' => $approver->id,
                'decision' => 'rejected',
                'comment' => $comment,
            ]);

            $locked->update(['status' => ApprovalStatus::Rejected, 'resolved_at' => now()]);

            return $locked->refresh();
        });

        $this->announce($result);

        return $result;
    }

    private function announce(ApprovalRequest $request): void
    {
        if ($request->status !== ApprovalStatus::Pending) {
            ApprovalResolved::dispatch($request);
        }
    }
}
