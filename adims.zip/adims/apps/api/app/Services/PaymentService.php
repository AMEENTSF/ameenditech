<?php

declare(strict_types=1);

namespace App\Services;

use App\Enums\ApprovalStatus;
use App\Models\ApprovalRequest;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\User;
use App\Support\Money;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class PaymentService
{
    public function __construct(private ApprovalService $approvals, private JournalService $journal, private AuditLogger $audit)
    {
    }

    /**
     * Record a payment claim (for example, a customer uploading a transfer receipt).
     * It does NOT count towards any invoice until verified.
     */
    public function recordClaim(array $data): Payment
    {
        return Payment::create($data + ['status' => 'pending_verification']);
    }

    /**
     * Verify a payment.
     * - Gateway confirmations (no user) are trusted and verify immediately.
     * - Manual verification at or below the threshold needs one verifier.
     * - Above the threshold two distinct authorised verifiers are required (server-enforced).
     *
     * @return array{status: string, verified: bool, approvals_recorded?: int, approvals_required?: int}
     */
    public function verify(Payment $payment, ?User $verifier): array
    {
        return DB::transaction(function () use ($payment, $verifier) {
            $payment = Payment::whereKey($payment->id)->lockForUpdate()->firstOrFail();

            if ($payment->status !== 'pending_verification') {
                throw ValidationException::withMessages(['payment' => 'Payment is not awaiting verification.']);
            }

            $amount = Money::fromKobo($payment->amount_kobo);

            if ($verifier === null || $this->approvals->requiredApprovalsFor($amount) === 1) {
                $this->markVerified($payment, $verifier);

                return ['status' => 'verified', 'verified' => true];
            }

            $request = ApprovalRequest::where('subject_type', 'payment')->where('subject_id', $payment->id)
                ->where('status', ApprovalStatus::Pending->value)->first();

            if (! $request) {
                // The first verifier opens the request and counts as the first approval.
                $request = $this->approvals->request($payment, $verifier, $amount);
                $request->decisions()->create(['approver_id' => $verifier->id, 'decision' => 'approved', 'comment' => 'First verification']);
            } else {
                $request = $this->approvals->approve($request, $verifier, 'Second verification');
            }

            $recorded = $request->decisions()->where('decision', 'approved')->count();

            return [
                'status' => $request->status === ApprovalStatus::Approved ? 'verified' : 'awaiting_second_verifier',
                'verified' => $request->status === ApprovalStatus::Approved,
                'approvals_recorded' => $recorded,
                'approvals_required' => $request->required_approvals,
            ];
        });
    }

    public function markVerified(Payment $payment, ?User $verifier): void
    {
        $payment->update(['status' => 'verified', 'verified_by' => $verifier?->id, 'verified_at' => now()]);
        app(NotificationService::class)->send('payment.confirmed', $payment->contact, ['reference' => $payment->reference]);
        $this->audit->record('payment.verified', $payment, ['status' => 'pending_verification'], ['status' => 'verified'], $verifier?->id);
    }

    /** Allocate part or all of a verified payment to an invoice. */
    public function allocate(Payment $payment, Invoice $invoice, Money $amount): void
    {
        DB::transaction(function () use ($payment, $invoice, $amount) {
            $payment = Payment::whereKey($payment->id)->lockForUpdate()->firstOrFail();
            $invoice = Invoice::whereKey($invoice->id)->lockForUpdate()->firstOrFail();

            if ($payment->status !== 'verified') {
                throw ValidationException::withMessages(['payment' => 'Only verified payments can be allocated.']);
            }

            if (! in_array($invoice->status, ['issued', 'partially_paid'], true)) {
                throw ValidationException::withMessages(['invoice' => 'Only issued invoices can receive payments.']);
            }

            if ($payment->contact_id !== $invoice->contact_id) {
                throw ValidationException::withMessages(['invoice' => 'Payment and invoice belong to different customers.']);
            }

            if ($amount->kobo <= 0) {
                throw ValidationException::withMessages(['amount' => 'Allocation must be positive.']);
            }

            $alreadyAllocated = (int) $payment->allocations()->sum('amount_kobo');
            if ($alreadyAllocated + $amount->kobo > $payment->amount_kobo) {
                throw ValidationException::withMessages(['amount' => 'Allocation exceeds the payment amount.']);
            }

            if ($invoice->paid_kobo + $amount->kobo > $invoice->total_kobo) {
                throw ValidationException::withMessages(['amount' => 'Allocation exceeds the invoice balance.']);
            }

            $existing = $payment->allocations()->where('invoice_id', $invoice->id)->first();
            if ($existing) {
                $existing->update(['amount_kobo' => $existing->amount_kobo + $amount->kobo]);
            } else {
                $payment->allocations()->create(['invoice_id' => $invoice->id, 'amount_kobo' => $amount->kobo]);
            }

            $paid = $invoice->paid_kobo + $amount->kobo;
            $invoice->update([
                'paid_kobo' => $paid,
                'status' => $paid === $invoice->total_kobo ? 'paid' : 'partially_paid',
            ]);

            $this->journal->post(
                "Payment {$payment->reference} applied to {$invoice->number}",
                [
                    ['account' => $this->journal->code('bank'), 'debit' => $amount->kobo],
                    ['account' => $this->journal->code('receivable'), 'credit' => $amount->kobo],
                ],
                'payment', $payment->id,
            );
        });
    }
}
