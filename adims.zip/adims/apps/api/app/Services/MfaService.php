<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\User;
use PragmaRX\Google2FA\Google2FA;

/** TOTP multi-factor authentication for privileged users. */
class MfaService
{
    public function __construct(private Google2FA $google2fa)
    {
    }

    /** Create a pending secret; MFA is only active once confirm() succeeds. */
    public function begin(User $user): array
    {
        $secret = $this->google2fa->generateSecretKey();
        $user->forceFill(['mfa_secret' => $secret, 'mfa_confirmed_at' => null])->save();

        return [
            'secret' => $secret,
            'otpauth_url' => $this->google2fa->getQRCodeUrl(config('app.name', 'ADIMS'), $user->email, $secret),
        ];
    }

    public function confirm(User $user, string $code): bool
    {
        if (! $user->mfa_secret || ! $this->google2fa->verifyKey($user->mfa_secret, $code)) {
            return false;
        }

        $user->forceFill(['mfa_confirmed_at' => now()])->save();

        return true;
    }

    public function verify(User $user, string $code): bool
    {
        return $user->mfa_confirmed_at !== null
            && $user->mfa_secret
            && $this->google2fa->verifyKey($user->mfa_secret, $code);
    }
}
