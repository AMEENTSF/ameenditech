<?php

declare(strict_types=1);

namespace App\Services;

use App\Jobs\DeliverNotification;
use App\Models\Contact;
use App\Models\Notification;
use App\Models\NotificationTemplate;
use App\Models\User;

/**
 * Renders a template per channel, stores one notification row per channel and queues delivery.
 * In-app notifications are delivered immediately; email/SMS/WhatsApp/push go through queued drivers
 * so a provider outage never blocks a business transaction. Status is tracked on the row.
 */
class NotificationService
{
    /** @param array<string,scalar> $data placeholder values for {{ name }} tokens */
    public function send(string $code, Contact|User $recipient, array $data = [], ?array $channels = null): int
    {
        $contact = $recipient instanceof User ? $recipient->contact : $recipient;
        $user = $recipient instanceof User ? $recipient : $contact?->user;

        $templates = NotificationTemplate::where('code', $code)->where('active', true)
            ->when($channels, fn ($q) => $q->whereIn('channel', $channels))->get();

        foreach ($templates as $template) {
            $notification = Notification::create([
                'user_id' => $user?->id,
                'contact_id' => $contact?->id,
                'notification_template_id' => $template->id,
                'channel' => $template->channel,
                'subject' => $template->subject ? $this->render($template->subject, $data) : null,
                'body' => $this->render($template->body, $data),
                'status' => $template->channel === 'in_app' ? 'delivered' : 'queued',
                'sent_at' => $template->channel === 'in_app' ? now() : null,
            ]);

            if ($template->channel !== 'in_app') {
                DeliverNotification::dispatch($notification->id);
            }
        }

        return $templates->count();
    }

    /** Replaces {{ token }} with escaped values; unknown tokens are removed rather than leaked. */
    public function render(string $text, array $data): string
    {
        return trim(preg_replace_callback('/\{\{\s*([a-z0-9_.]+)\s*\}\}/i', fn ($m) => isset($data[$m[1]]) ? strip_tags((string) $data[$m[1]]) : '', $text));
    }
}
