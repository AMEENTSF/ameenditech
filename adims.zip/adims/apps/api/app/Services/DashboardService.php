<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\User;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;

/**
 * Executive dashboard. Every figure is calculated from live records; nothing is hardcoded.
 * Sections are only computed for users holding the matching permission, so a manager without
 * finance rights never receives revenue numbers even if they call the API directly.
 * Money is returned as integer kobo.
 */
class DashboardService
{
    public function build(User $user, CarbonImmutable $from, CarbonImmutable $to): array
    {
        $out = ['period' => ['from' => $from->toDateString(), 'to' => $to->toDateString()], 'generated_at' => now()->toIso8601String()];

        if ($user->hasPermission('finance.reports.view')) {
            $out['finance'] = $this->finance($from, $to);
        }
        if ($user->hasPermission('research.projects.view_all')) {
            $out['research'] = $this->research($from, $to);
        }
        if ($user->hasPermission('training.courses.view')) {
            $out['training'] = $this->training($from, $to);
        }
        if ($user->hasPermission('services.projects.view')) {
            $out['digital_services'] = $this->services();
        }
        $out['customers'] = $this->customers($from, $to);
        if ($user->hasPermission('admin.audit.view')) {
            $out['staff_activity'] = $this->staffActivity($from, $to);
        }
        $out['pending_approvals'] = $this->pendingApprovals($user);
        $out['upcoming_deadlines'] = $this->deadlines($user);

        return $out;
    }

    private function finance(CarbonImmutable $from, CarbonImmutable $to): array
    {
        $billed = (int) DB::table('invoices')->whereNotIn('status', ['draft', 'void'])->whereBetween('issued_on', [$from, $to])->sum('total_kobo');
        $collected = (int) DB::table('payments')->where('status', 'verified')->whereBetween('verified_at', [$from->startOfDay(), $to->endOfDay()])->sum('amount_kobo');
        $expenses = (int) DB::table('expenses')->where('status', 'paid')->whereBetween('paid_at', [$from->startOfDay(), $to->endOfDay()])->sum('amount_kobo');
        $outstanding = (int) DB::table('invoices')->whereIn('status', ['issued', 'partially_paid'])->selectRaw('COALESCE(SUM(total_kobo - paid_kobo), 0) as v')->value('v');
        $overdue = (int) DB::table('invoices')->whereIn('status', ['issued', 'partially_paid'])->whereDate('due_on', '<', now('Africa/Lagos'))->selectRaw('COALESCE(SUM(total_kobo - paid_kobo), 0) as v')->value('v');

        $monthlyBilled = DB::table('invoices')->whereNotIn('status', ['draft', 'void'])->whereBetween('issued_on', [$from, $to])
            ->selectRaw("to_char(issued_on, 'YYYY-MM') as month, SUM(total_kobo) as kobo")->groupBy('month')->pluck('kobo', 'month');
        $monthlyExpenses = DB::table('expenses')->where('status', 'paid')->whereBetween('paid_at', [$from->startOfDay(), $to->endOfDay()])
            ->selectRaw("to_char(paid_at, 'YYYY-MM') as month, SUM(amount_kobo) as kobo")->groupBy('month')->pluck('kobo', 'month');

        $months = collect($monthlyBilled->keys())->merge($monthlyExpenses->keys())->unique()->sort()->values();

        return [
            'revenue_billed_kobo' => $billed,
            'revenue_collected_kobo' => $collected,
            'expenses_kobo' => $expenses,
            'net_operating_kobo' => $collected - $expenses,
            'outstanding_invoices_kobo' => $outstanding,
            'overdue_kobo' => $overdue,
            'monthly' => $months->map(fn ($m) => ['month' => $m, 'revenue_kobo' => (int) ($monthlyBilled[$m] ?? 0), 'expenses_kobo' => (int) ($monthlyExpenses[$m] ?? 0)])->all(),
        ];
    }

    private function research(CarbonImmutable $from, CarbonImmutable $to): array
    {
        $byStage = DB::table('research_projects')->selectRaw('stage, COUNT(*) as n')->groupBy('stage')->pluck('n', 'stage');
        $avgDays = DB::table('research_projects')->whereNotNull('closed_at')->whereBetween('closed_at', [$from->startOfDay(), $to->endOfDay()])
            ->selectRaw('AVG(EXTRACT(EPOCH FROM (closed_at - created_at)) / 86400) as d')->value('d');

        return [
            'active' => (int) $byStage->except(['closed', 'enquiry'])->sum(),
            'completed' => (int) ($byStage['closed'] ?? 0),
            'by_stage' => $byStage,
            'avg_turnaround_days' => $avgDays === null ? null : round((float) $avgDays, 1),
        ];
    }

    private function training(CarbonImmutable $from, CarbonImmutable $to): array
    {
        $enrolled = DB::table('enrolments')->where('status', 'enrolled')->count();
        $completed = DB::table('enrolments')->where('status', 'completed')->count();
        $finished = $completed + DB::table('enrolments')->whereIn('status', ['dropped', 'withdrawn', 'failed'])->count();

        return [
            'active_learners' => $enrolled,
            'enrolments_in_period' => DB::table('enrolments')->whereBetween('created_at', [$from->startOfDay(), $to->endOfDay()])->count(),
            'completion_rate_percent' => $finished === 0 ? null : (int) round($completed * 100 / $finished),
            'certificates_issued_in_period' => DB::table('certificates')->whereBetween('issued_at', [$from->startOfDay(), $to->endOfDay()])->count(),
        ];
    }

    private function services(): array
    {
        $byStatus = DB::table('service_projects')->selectRaw('status, COUNT(*) as n')->groupBy('status')->pluck('n', 'status');

        return [
            'active_projects' => (int) $byStatus->only(['agreed', 'in_progress', 'client_review'])->sum(),
            'by_status' => $byStatus,
            'open_tickets' => DB::table('support_tickets')->whereIn('status', ['open', 'in_progress', 'waiting_client'])->count(),
            'active_care_plans' => DB::table('care_plans')->where('status', 'active')->count(),
        ];
    }

    private function customers(CarbonImmutable $from, CarbonImmutable $to): array
    {
        $new = DB::table('contacts')->whereNull('deleted_at')->whereBetween('created_at', [$from->startOfDay(), $to->endOfDay()])
            ->selectRaw("to_char(created_at, 'YYYY-MM') as month, COUNT(*) as n")->groupBy('month')->orderBy('month')->get();

        return ['total' => DB::table('contacts')->whereNull('deleted_at')->count(), 'new_in_period' => (int) $new->sum('n'), 'monthly_new' => $new];
    }

    private function staffActivity(CarbonImmutable $from, CarbonImmutable $to): array
    {
        return [
            'active_users' => DB::table('audit_logs')->whereBetween('created_at', [$from->startOfDay(), $to->endOfDay()])->distinct('user_id')->count('user_id'),
            'actions' => DB::table('audit_logs')->whereBetween('created_at', [$from->startOfDay(), $to->endOfDay()])->count(),
        ];
    }

    private function pendingApprovals(User $user): int
    {
        $types = collect(['expense' => 'finance.expenses.approve', 'supplier_invoice' => 'finance.invoices.approve', 'purchase_order' => 'procurement.requests.approve',
            'purchase_request' => 'procurement.requests.approve', 'payment' => 'finance.payments.verify'])->filter(fn ($p) => $user->hasPermission($p))->keys();

        return DB::table('approval_requests')->where('status', 'pending')->whereIn('subject_type', $types)->where('requested_by', '!=', $user->id)->count();
    }

    private function deadlines(User $user): array
    {
        $until = now('Africa/Lagos')->addDays(14)->toDateString();
        $today = now('Africa/Lagos')->toDateString();
        $items = collect();

        if ($user->hasPermission('research.projects.view_all')) {
            $items = $items->merge(DB::table('research_projects')->whereNotIn('stage', ['closed'])->whereBetween('due_on', [$today, $until])
                ->get(['reference as label', 'due_on'])->map(fn ($r) => ['type' => 'research_project', 'label' => $r->label, 'due_on' => $r->due_on]));
        }
        if ($user->hasPermission('services.projects.view')) {
            $items = $items->merge(DB::table('service_projects')->whereNotIn('status', ['completed', 'cancelled'])->whereBetween('due_on', [$today, $until])
                ->get(['reference as label', 'due_on'])->map(fn ($r) => ['type' => 'service_project', 'label' => $r->label, 'due_on' => $r->due_on]));
        }
        if ($user->hasPermission('governance.risks.view')) {
            $items = $items->merge(DB::table('compliance_items')->where('status', 'upcoming')->whereBetween('due_on', [$today, $until])
                ->get(['title as label', 'due_on'])->map(fn ($r) => ['type' => 'compliance', 'label' => $r->label, 'due_on' => $r->due_on]));
        }

        return $items->sortBy('due_on')->take(15)->values()->all();
    }
}
