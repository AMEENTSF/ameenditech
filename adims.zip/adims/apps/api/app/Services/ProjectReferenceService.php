<?php

declare(strict_types=1);

namespace App\Services;

use App\Support\Money;
use Illuminate\Support\Facades\DB;

class ProjectReferenceService
{
    /**
     * Generate a unique reference such as ADM-RES-2026-0007.
     * The per-year counter row is locked so concurrent requests cannot collide.
     */
    public function next(?int $year = null): string
    {
        $year ??= (int) now()->format('Y');

        return DB::transaction(function () use ($year) {
            DB::table('project_reference_counters')->insertOrIgnore(['year' => $year, 'last_number' => 0]);

            $row = DB::table('project_reference_counters')->where('year', $year)->lockForUpdate()->first();
            $number = $row->last_number + 1;

            DB::table('project_reference_counters')->where('year', $year)->update(['last_number' => $number]);

            return sprintf('%s-%d-%04d', config('adims.research.reference_prefix'), $year, $number);
        });
    }

    /** Deposit due before execution starts, using the configurable basis points. */
    public function depositFor(Money $quote, ?int $basisPoints = null): Money
    {
        return $quote->percentOfBasisPoints($basisPoints ?? config('adims.research.default_deposit_basis_points'));
    }
}
