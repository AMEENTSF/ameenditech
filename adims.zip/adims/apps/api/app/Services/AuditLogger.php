<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\AuditLog;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Request;

class AuditLogger
{
    private const HIDDEN = ['password', 'mfa_secret', 'remember_token'];

    public function record(string $action, ?Model $subject = null, ?array $old = null, ?array $new = null, ?int $userId = null): AuditLog
    {
        return AuditLog::create([
            'user_id' => $userId ?? auth()->id(),
            'action' => $action,
            'subject_type' => $subject?->getMorphClass(),
            'subject_id' => $subject?->getKey(),
            'old_values' => $old ? $this->scrub($old) : null,
            'new_values' => $new ? $this->scrub($new) : null,
            'ip_address' => Request::ip(),
        ]);
    }

    private function scrub(array $values): array
    {
        return array_diff_key($values, array_flip(self::HIDDEN));
    }
}
