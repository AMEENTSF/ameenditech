<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Enums\ApprovalStatus;
use App\Events\ApprovalResolved;
use App\Services\AuditLogger;

/** Moves the approved/rejected subject (expense, PO, PR, supplier invoice) to its next state. */
class ApplyApprovalOutcome
{
    private const OUTCOMES = [
        'expense' => ['approved' => 'approved', 'rejected' => 'rejected'],
        'purchase_order' => ['approved' => 'approved', 'rejected' => 'draft'],
        'purchase_request' => ['approved' => 'approved', 'rejected' => 'rejected'],
        'supplier_invoice' => ['approved' => 'approved', 'rejected' => 'rejected'],
        'payment' => ['approved' => 'verified', 'rejected' => 'rejected'],
    ];

    public function __construct(private AuditLogger $audit)
    {
    }

    public function handle(ApprovalResolved $event): void
    {
        $request = $event->request;
        $map = self::OUTCOMES[$request->subject_type] ?? null;
        $subject = $request->subject;

        if (! $map || ! $subject || $request->status === ApprovalStatus::Pending) {
            return;
        }

        $new = $map[$request->status->value] ?? null;
        if ($new) {
            $old = $subject->status;
            $extra = ($request->subject_type === 'payment' && $new === 'verified') ? ['verified_at' => now(), 'verified_by' => $request->decisions()->latest('id')->value('approver_id')] : [];
            $subject->update(['status' => $new] + $extra);
            $this->audit->record("approval.{$request->status->value}", $subject, ['status' => $old], ['status' => $new]);
        }
    }
}
