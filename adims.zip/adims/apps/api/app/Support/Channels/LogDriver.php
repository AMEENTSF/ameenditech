<?php

declare(strict_types=1);

namespace App\Support\Channels;

use App\Models\Notification;
use Illuminate\Support\Facades\Log;

/** Default for SMS / WhatsApp / push until a provider is contracted. Logs without message content. */
class LogDriver implements ChannelDriver
{
    public function send(Notification $notification): ?string
    {
        Log::info('Notification dispatched (log driver)', ['id' => $notification->id, 'channel' => $notification->channel]);

        return 'log-' . $notification->id;
    }
}
