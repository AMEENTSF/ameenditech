<?php

declare(strict_types=1);

namespace App\Support\Channels;

use App\Models\Notification;

interface ChannelDriver
{
    /** Send the notification and return the provider message id (used to match delivery receipts). */
    public function send(Notification $notification): ?string;
}
