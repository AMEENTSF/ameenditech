<?php

declare(strict_types=1);

namespace App\Support\Channels;

use App\Models\Contact;
use App\Models\Notification;
use Illuminate\Support\Facades\Mail;

class MailDriver implements ChannelDriver
{
    public function send(Notification $notification): ?string
    {
        $email = Contact::whereKey($notification->contact_id)->value('email');
        if (! $email) {
            throw new \RuntimeException('Recipient has no email address.');
        }

        Mail::raw($notification->body, fn ($m) => $m->to($email)->subject($notification->subject ?? config('app.name')));

        return null; // SMTP gives no delivery receipt; status stays "sent".
    }
}
