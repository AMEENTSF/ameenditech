<?php

declare(strict_types=1);

namespace App\Support\Channels;

use InvalidArgumentException;

/** Resolves a driver per channel from config/adims.php; swap providers (Termii, Twilio, WhatsApp Cloud API, FCM) without touching callers. */
class ChannelManager
{
    public function driver(string $channel): ChannelDriver
    {
        $class = config("adims.notifications.drivers.{$channel}");

        return $class ? app($class) : throw new InvalidArgumentException("No driver configured for channel [{$channel}].");
    }
}
