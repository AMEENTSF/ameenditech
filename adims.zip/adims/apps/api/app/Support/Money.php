<?php

declare(strict_types=1);

namespace App\Support;

use InvalidArgumentException;

/**
 * Immutable money value in integer kobo. Never uses floats.
 */
final class Money
{
    private function __construct(public readonly int $kobo)
    {
    }

    public static function fromKobo(int $kobo): self
    {
        return new self($kobo);
    }

    /**
     * Parse a decimal naira string such as "1500.50" without float conversion.
     */
    public static function fromNairaString(string $naira): self
    {
        if (! preg_match('/^(-?)(\d+)(?:\.(\d{1,2}))?$/', trim($naira), $m)) {
            throw new InvalidArgumentException("Invalid naira amount: {$naira}");
        }

        $fraction = str_pad($m[3] ?? '0', 2, '0');
        $kobo = ((int) $m[2]) * 100 + (int) $fraction;

        return new self($m[1] === '-' ? -$kobo : $kobo);
    }

    public function add(self $other): self
    {
        return new self($this->kobo + $other->kobo);
    }

    public function subtract(self $other): self
    {
        return new self($this->kobo - $other->kobo);
    }

    /**
     * Apply a percentage expressed in basis points (5000 = 50%), rounding half up.
     */
    public function percentOfBasisPoints(int $basisPoints): self
    {
        $product = $this->kobo * $basisPoints;

        return new self(intdiv($product + 5000, 10000));
    }

    public function isGreaterThan(self $other): bool
    {
        return $this->kobo > $other->kobo;
    }

    public function isNegative(): bool
    {
        return $this->kobo < 0;
    }

    public function format(): string
    {
        $abs = abs($this->kobo);
        $naira = intdiv($abs, 100);
        $kobo = str_pad((string) ($abs % 100), 2, '0', STR_PAD_LEFT);

        return ($this->kobo < 0 ? '-' : '') . '₦' . number_format($naira) . '.' . $kobo;
    }
}
