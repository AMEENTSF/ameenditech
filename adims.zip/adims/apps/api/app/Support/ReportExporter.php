<?php

declare(strict_types=1);

namespace App\Support;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;

/** Renders a report array to CSV, XLSX or PDF. Cell values are neutralised against spreadsheet formula injection. */
class ReportExporter
{
    public function export(array $report, string $format, string $filename): Response
    {
        return match ($format) {
            'csv' => $this->csv($report, $filename),
            'xlsx' => $this->xlsx($report, $filename),
            'pdf' => $this->pdf($report, $filename),
        };
    }

    public function cell(string $type, mixed $value): string
    {
        if ($value === null) {
            return '';
        }

        return match ($type) {
            'kobo' => ((int) $value < 0 ? '-' : '') . number_format(intdiv(abs((int) $value), 100)) . '.' . str_pad((string) (abs((int) $value) % 100), 2, '0', STR_PAD_LEFT),
            'percent' => $value . '%',
            default => $this->safe((string) $value),
        };
    }

    /** Prefix a quote when a text cell could be interpreted as a formula by Excel/Sheets. */
    public function safe(string $text): string
    {
        return $text !== '' && in_array($text[0], ['=', '+', '-', '@', "\t", "\r"], true) ? "'" . $text : $text;
    }

    private function table(array $report): array
    {
        $headers = array_map(fn ($c) => $c[0], $report['columns']);
        $rows = array_map(fn ($row) => array_map(fn ($key, $col) => $this->cell($col[1], $row[$key] ?? null), array_keys($report['columns']), $report['columns']), $report['rows']);

        return [$headers, $rows];
    }

    private function csv(array $report, string $filename): StreamedResponse
    {
        [$headers, $rows] = $this->table($report);

        return response()->streamDownload(function () use ($headers, $rows) {
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF"); // UTF-8 BOM so Excel shows ₦ and accents correctly
            fputcsv($out, $headers);
            foreach ($rows as $row) {
                fputcsv($out, $row);
            }
            fclose($out);
        }, "{$filename}.csv", ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    private function xlsx(array $report, string $filename): StreamedResponse
    {
        [$headers, $rows] = $this->table($report);

        return response()->streamDownload(function () use ($headers, $rows, $report) {
            $book = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
            $sheet = $book->getActiveSheet()->setTitle(substr(preg_replace('/[^A-Za-z0-9 ]/', '', $report['title']), 0, 31) ?: 'Report');
            $sheet->fromArray($headers, null, 'A1');
            $sheet->fromArray($rows, null, 'A2');
            $sheet->getStyle('A1:' . \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex(max(1, count($headers))) . '1')->getFont()->setBold(true);
            foreach (range(1, count($headers)) as $i) {
                $sheet->getColumnDimensionByColumn($i)->setAutoSize(true);
            }
            (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($book))->save('php://output');
        }, "{$filename}.xlsx", ['Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']);
    }

    private function pdf(array $report, string $filename): Response
    {
        [$headers, $rows] = $this->table($report);

        return \Barryvdh\DomPDF\Facade\Pdf::loadView('reports.pdf', ['title' => $report['title'], 'headers' => $headers, 'rows' => $rows, 'generated' => now('Africa/Lagos')->format('j M Y, H:i')])
            ->setPaper('a4', count($headers) > 5 ? 'landscape' : 'portrait')->download("{$filename}.pdf");
    }
}
