<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\ComplianceItem;
use App\Models\EnrolmentInstalment;
use App\Models\Invoice;
use App\Services\NotificationService;
use Illuminate\Console\Command;

class FlagOverdue extends Command
{
    protected $signature = 'adims:flag-overdue';

    protected $description = 'Mark overdue instalments and compliance items and notify customers with overdue invoices.';

    public function handle(NotificationService $notifications): int
    {
        $today = now('Africa/Lagos')->toDateString();

        $instalments = EnrolmentInstalment::where('status', 'pending')->whereDate('due_on', '<', $today)->update(['status' => 'overdue']);
        $compliance = ComplianceItem::where('status', 'upcoming')->whereDate('due_on', '<', $today)->update(['status' => 'overdue']);

        $reminded = 0;
        Invoice::with('contact')->whereIn('status', ['issued', 'partially_paid'])->whereDate('due_on', '<', $today)
            ->whereDate('due_on', '>=', now('Africa/Lagos')->subDays(1)->toDateString())->each(function (Invoice $invoice) use ($notifications, &$reminded) {
                $notifications->send('payment.outstanding', $invoice->contact, ['invoice' => $invoice->number, 'balance' => number_format($invoice->balance_kobo / 100, 2)]);
                $reminded++;
            });

        $this->info("Overdue instalments: {$instalments}; compliance items: {$compliance}; reminders: {$reminded}");

        return self::SUCCESS;
    }
}
