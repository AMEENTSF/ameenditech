<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\CarePlan;
use App\Models\CarePlanRenewal;
use App\Services\CarePlanService;
use App\Services\NotificationService;
use Illuminate\Console\Command;

class CarePlanReminders extends Command
{
    protected $signature = 'adims:care-plan-reminders';

    protected $description = 'Invoice care plans due within 7 days, remind clients and lapse renewals unpaid for 30 days.';

    public function handle(CarePlanService $service, NotificationService $notifications): int
    {
        $created = 0;
        CarePlan::with('contact')->where('status', 'active')->where('auto_renew', true)
            ->whereDate('renews_on', '<=', now('Africa/Lagos')->addDays(7)->toDateString())->each(function (CarePlan $plan) use ($service, $notifications, &$created) {
                $renewal = $service->generateRenewal($plan);
                if ($renewal->wasRecentlyCreated) {
                    $notifications->send('care_plan.renewal_due', $plan->contact, ['plan' => $plan->name, 'date' => $renewal->period_start->toFormattedDateString()]);
                    $created++;
                }
            });

        $lapsed = CarePlanRenewal::where('status', 'invoiced')->whereDate('period_start', '<', now('Africa/Lagos')->subDays(30)->toDateString())->update(['status' => 'lapsed']);
        $this->info("Renewals created: {$created}; lapsed: {$lapsed}");

        return self::SUCCESS;
    }
}
