<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\ClassSession;
use App\Services\NotificationService;
use Illuminate\Console\Command;

class ClassReminders extends Command
{
    protected $signature = 'adims:class-reminders';

    protected $description = 'Remind enrolled learners of tomorrow\'s classes.';

    public function handle(NotificationService $notifications): int
    {
        $tomorrow = now('Africa/Lagos')->addDay();
        $sent = 0;

        ClassSession::with('cohort.enrolments.contact', 'cohort.course')->where('status', 'scheduled')
            ->whereBetween('starts_at', [$tomorrow->copy()->startOfDay(), $tomorrow->copy()->endOfDay()])->each(function (ClassSession $session) use ($notifications, &$sent) {
                foreach ($session->cohort->enrolments->where('status', 'enrolled') as $enrolment) {
                    $notifications->send('class.reminder', $enrolment->contact, ['course' => $session->cohort->course->title, 'time' => $session->starts_at->format('D j M, g:ia')]);
                    $sent++;
                }
            });

        $this->info("Reminders queued: {$sent}");

        return self::SUCCESS;
    }
}
