<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Usage: ->middleware('permission:finance.invoices.view')
 * Authorisation is enforced here on the server; hiding menu items in the UI is cosmetic.
 */
class RequirePermission
{
    public function handle(Request $request, Closure $next, string ...$permissions): Response
    {
        $user = $request->user();

        if (! $user || ! $user->isActive()) {
            abort(401, 'Unauthenticated.');
        }

        // Privileged roles must have completed MFA enrolment before using protected features.
        if ($user->requiresMfa() && $user->mfa_confirmed_at === null) {
            abort(403, 'Multi-factor authentication must be set up before using this feature.');
        }

        foreach ($permissions as $permission) {
            if ($user->hasPermission($permission)) {
                return $next($request);
            }
        }

        abort(403, 'You do not have permission to perform this action.');
    }
}
