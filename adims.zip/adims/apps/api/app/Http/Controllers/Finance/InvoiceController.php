<?php

declare(strict_types=1);

namespace App\Http\Controllers\Finance;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Services\AuditLogger;
use App\Services\JournalService;
use App\Services\ReferenceGenerator;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class InvoiceController extends Controller
{
    public function __construct(private ReferenceGenerator $refs, private JournalService $journal, private AuditLogger $audit)
    {
    }

    public function index(Request $request): JsonResponse
    {
        $query = Invoice::with('contact:id,first_name,last_name,organisation_id')->latest('id');
        foreach (['status', 'contact_id'] as $f) {
            if ($request->filled($f)) {
                $query->where($f, $request->query($f));
            }
        }
        if ($request->boolean('overdue')) {
            $query->whereIn('status', ['issued', 'partially_paid'])->whereDate('due_on', '<', now('Africa/Lagos'));
        }

        return response()->json($query->paginate(min((int) $request->query('per_page', 25), 100)));
    }

    public function show(Invoice $invoice): JsonResponse
    {
        return response()->json(['data' => $invoice->load('lines', 'contact')]);
    }

    /** Totals are always computed on the server from the lines; a client-supplied total is ignored. */
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'contact_id' => ['required', 'integer', 'exists:contacts,id'],
            'billable_type' => ['nullable', Rule::in(['research_project', 'service_project', 'enrolment'])],
            'billable_id' => ['nullable', 'integer', 'required_with:billable_type'],
            'due_on' => ['nullable', 'date', 'after_or_equal:today'],
            'lines' => ['required', 'array', 'min:1', 'max:100'],
            'lines.*.description' => ['required', 'string', 'max:255'],
            'lines.*.quantity' => ['required', 'integer', 'min:1', 'max:100000'],
            'lines.*.unit_price_kobo' => ['required', 'integer', 'min:1', 'max:100000000000'],
        ]);

        $invoice = DB::transaction(function () use ($data, $request) {
            $total = 0;
            $lines = [];
            foreach ($data['lines'] as $l) {
                $lineTotal = $l['quantity'] * $l['unit_price_kobo'];
                $total += $lineTotal;
                $lines[] = $l + ['line_total_kobo' => $lineTotal];
            }

            $invoice = Invoice::create([
                'number' => $this->refs->next('INV'),
                'contact_id' => $data['contact_id'],
                'billable_type' => $data['billable_type'] ?? null,
                'billable_id' => $data['billable_id'] ?? null,
                'status' => 'draft',
                'total_kobo' => $total,
                'due_on' => $data['due_on'] ?? null,
                'created_by' => $request->user()->id,
            ]);
            $invoice->lines()->createMany($lines);
            $this->audit->record('invoice.created', $invoice, null, ['number' => $invoice->number, 'total_kobo' => $total]);

            return $invoice;
        });

        return response()->json(['data' => $invoice->load('lines')], 201);
    }

    /** Issuing locks the invoice and books receivable against revenue. */
    public function issue(Invoice $invoice): JsonResponse
    {
        DB::transaction(function () use ($invoice) {
            $invoice = Invoice::whereKey($invoice->id)->lockForUpdate()->firstOrFail();
            if ($invoice->status !== 'draft') {
                throw ValidationException::withMessages(['invoice' => 'Only draft invoices can be issued.']);
            }
            $invoice->update(['status' => 'issued', 'issued_on' => now('Africa/Lagos')->toDateString()]);
            $this->journal->post(
                "Invoice {$invoice->number} issued",
                [
                    ['account' => $this->journal->code('receivable'), 'debit' => $invoice->total_kobo],
                    ['account' => $this->journal->code('revenue'), 'credit' => $invoice->total_kobo],
                ],
                'invoice', $invoice->id,
            );
            $this->audit->record('invoice.issued', $invoice);
        });

        return response()->json(['data' => $invoice->refresh()]);
    }

    public function void(Invoice $invoice): JsonResponse
    {
        DB::transaction(function () use ($invoice) {
            $invoice = Invoice::whereKey($invoice->id)->lockForUpdate()->firstOrFail();
            if ($invoice->paid_kobo > 0 || $invoice->status === 'void') {
                throw ValidationException::withMessages(['invoice' => 'Paid or already void invoices cannot be voided.']);
            }
            if ($invoice->status !== 'draft') {
                // Reverse the original posting rather than deleting history.
                $this->journal->post(
                    "Invoice {$invoice->number} voided",
                    [
                        ['account' => $this->journal->code('revenue'), 'debit' => $invoice->total_kobo],
                        ['account' => $this->journal->code('receivable'), 'credit' => $invoice->total_kobo],
                    ],
                    'invoice', $invoice->id,
                );
            }
            $invoice->update(['status' => 'void']);
            $this->audit->record('invoice.voided', $invoice);
        });

        return response()->json(['data' => $invoice->refresh()]);
    }
}
