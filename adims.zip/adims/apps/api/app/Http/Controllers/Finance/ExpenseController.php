<?php

declare(strict_types=1);

namespace App\Http\Controllers\Finance;

use App\Http\Controllers\Controller;
use App\Models\BankAccount;
use App\Models\Expense;
use App\Models\ExpenseCategory;
use App\Services\ApprovalService;
use App\Services\AuditLogger;
use App\Services\JournalService;
use App\Services\ReferenceGenerator;
use App\Support\Money;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class ExpenseController extends Controller
{
    public function __construct(
        private ApprovalService $approvals,
        private ReferenceGenerator $refs,
        private JournalService $journal,
        private AuditLogger $audit,
    ) {
    }

    public function index(Request $request): JsonResponse
    {
        $query = Expense::latest('id');
        if (! $request->user()->hasPermission('finance.expenses.approve')) {
            // Record-level rule: requesters without approval rights see only their own requests.
            $query->where('requested_by', $request->user()->id);
        }
        if ($request->filled('status')) {
            $query->where('status', $request->query('status'));
        }

        return response()->json($query->paginate(min((int) $request->query('per_page', 25), 100)));
    }

    /** Every expense needs approval; above the threshold it needs two distinct approvers. */
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'description' => ['required', 'string', 'max:255'],
            'amount_kobo' => ['required', 'integer', 'min:1', 'max:100000000000'],
            'expense_category_id' => ['nullable', 'integer', 'exists:expense_categories,id'],
            'incurred_on' => ['nullable', 'date', 'before_or_equal:today'],
            'receipt_file_id' => ['nullable', 'integer', 'exists:files,id'],
        ]);

        $expense = DB::transaction(function () use ($data, $request) {
            $expense = Expense::create($data + [
                'reference' => $this->refs->next('EXP'),
                'requested_by' => $request->user()->id,
                'status' => 'pending_approval',
            ]);
            $approval = $this->approvals->request($expense, $request->user(), Money::fromKobo($expense->amount_kobo));
            $this->audit->record('expense.requested', $expense, null, ['amount_kobo' => $expense->amount_kobo, 'approvals_required' => $approval->required_approvals]);

            return $expense;
        });

        return response()->json(['data' => $expense], 201);
    }

    /** Payment is only possible once the approval request is fully approved. */
    public function pay(Request $request, Expense $expense): JsonResponse
    {
        $data = $request->validate(['bank_account_id' => ['required', 'integer', 'exists:bank_accounts,id']]);

        DB::transaction(function () use ($expense, $data, $request) {
            $expense = Expense::whereKey($expense->id)->lockForUpdate()->firstOrFail();
            $approval = \App\Models\ApprovalRequest::where('subject_type', 'expense')->where('subject_id', $expense->id)->latest('id')->first();

            if ($expense->status !== 'approved' || ! $approval || $approval->status->value !== 'approved'
                || $approval->decisions()->where('decision', 'approved')->count() < $approval->required_approvals) {
                throw ValidationException::withMessages(['expense' => 'Expense is not fully approved.']);
            }

            $bank = BankAccount::with('account')->findOrFail($data['bank_account_id']);
            $category = $expense->expense_category_id ? ExpenseCategory::with('account')->find($expense->expense_category_id) : null;

            $this->journal->post(
                "Expense {$expense->reference}: {$expense->description}",
                [
                    ['account' => $category?->account?->code ?? $this->journal->code('general_expense'), 'debit' => $expense->amount_kobo],
                    ['account' => $bank->account?->code ?? $this->journal->code('bank'), 'credit' => $expense->amount_kobo],
                ],
                'expense', $expense->id,
            );

            $expense->update(['status' => 'paid', 'bank_account_id' => $bank->id, 'paid_by' => $request->user()->id, 'paid_at' => now()]);
            $this->audit->record('expense.paid', $expense);
        });

        return response()->json(['data' => $expense->refresh()]);
    }
}
