<?php

declare(strict_types=1);

namespace App\Http\Controllers\Finance;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\Payment;
use App\Services\PaymentService;
use App\Services\ReferenceGenerator;
use App\Support\Money;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class PaymentController extends Controller
{
    public function __construct(private PaymentService $payments, private ReferenceGenerator $refs)
    {
    }

    public function index(Request $request): JsonResponse
    {
        $query = Payment::with('allocations')->latest('id');
        foreach (['status', 'contact_id'] as $f) {
            if ($request->filled($f)) {
                $query->where($f, $request->query($f));
            }
        }

        return response()->json($query->paginate(min((int) $request->query('per_page', 25), 100)));
    }

    /** A staff member records a payment claim. It stays pending_verification until verified. */
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'contact_id' => ['required', 'integer', 'exists:contacts,id'],
            'amount_kobo' => ['required', 'integer', 'min:1'],
            'method' => ['required', Rule::in(['bank_transfer', 'cash', 'pos'])],
            'receipt_file_id' => ['nullable', 'integer', 'exists:files,id'],
        ]);

        $payment = $this->payments->recordClaim($data + ['reference' => $this->refs->next('PAY')]);

        return response()->json(['data' => $payment], 201);
    }

    public function verify(Request $request, Payment $payment): JsonResponse
    {
        return response()->json($this->payments->verify($payment, $request->user()));
    }

    public function reject(Request $request, Payment $payment): JsonResponse
    {
        $request->validate(['reason' => ['required', 'string', 'max:500']]);
        abort_unless($payment->status === 'pending_verification', 422, 'Payment is not awaiting verification.');
        $payment->update(['status' => 'rejected']);
        app(\App\Services\AuditLogger::class)->record('payment.rejected', $payment, null, ['reason' => $request->input('reason')]);

        return response()->json(['data' => $payment->refresh()]);
    }

    public function allocate(Request $request, Payment $payment): JsonResponse
    {
        $data = $request->validate([
            'invoice_id' => ['required', 'integer', 'exists:invoices,id'],
            'amount_kobo' => ['required', 'integer', 'min:1'],
        ]);

        $this->payments->allocate($payment, Invoice::findOrFail($data['invoice_id']), Money::fromKobo($data['amount_kobo']));

        return response()->json(['data' => $payment->load('allocations')->refresh()]);
    }
}
