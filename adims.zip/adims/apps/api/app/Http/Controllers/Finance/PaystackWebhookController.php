<?php

declare(strict_types=1);

namespace App\Http\Controllers\Finance;

use App\Http\Controllers\Controller;
use App\Models\IntegrationEvent;
use App\Models\Payment;
use App\Services\PaymentService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Trusted gateway confirmation. The HMAC signature is verified before anything is read,
 * events are stored idempotently, and the amount must match the pending payment exactly.
 */
class PaystackWebhookController extends Controller
{
    public function __invoke(Request $request, PaymentService $payments): JsonResponse
    {
        $secret = (string) config('services.paystack.secret');
        $signature = (string) $request->header('x-paystack-signature');

        if ($secret === '' || ! hash_equals(hash_hmac('sha512', $request->getContent(), $secret), $signature)) {
            return response()->json(['message' => 'Invalid signature.'], 401);
        }

        $event = $request->input('event');
        $data = (array) $request->input('data', []);
        $externalId = (string) ($data['id'] ?? $data['reference'] ?? '');

        $record = IntegrationEvent::firstOrCreate(
            ['provider' => 'paystack', 'external_id' => $externalId],
            ['event_type' => (string) $event, 'payload' => $request->all(), 'status' => 'received'],
        );

        if (! $record->wasRecentlyCreated) {
            return response()->json(['message' => 'Already processed.']);
        }

        if ($event === 'charge.success') {
            $payment = Payment::where('gateway_reference', $data['reference'] ?? '')->where('status', 'pending_verification')->first();
            if ($payment && (int) ($data['amount'] ?? 0) === $payment->amount_kobo && ($data['currency'] ?? 'NGN') === 'NGN') {
                $payments->verify($payment, null);
                $record->update(['status' => 'processed', 'processed_at' => now()]);
            } else {
                $record->update(['status' => 'failed']);
            }
        }

        return response()->json(['message' => 'OK']);
    }
}
