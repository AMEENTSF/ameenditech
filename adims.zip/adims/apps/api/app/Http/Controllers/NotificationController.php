<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Notification;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/** The signed-in user's own in-app notifications. */
class NotificationController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Notification::where('user_id', $request->user()->id)->where('channel', 'in_app')->latest('id');

        return response()->json([
            'unread' => (clone $query)->whereNull('read_at')->count(),
            'data' => $query->paginate(min((int) $request->query('per_page', 20), 50)),
        ]);
    }

    public function markRead(Request $request, int $id): JsonResponse
    {
        Notification::where('user_id', $request->user()->id)->whereKey($id)->whereNull('read_at')->update(['read_at' => now()]);

        return response()->json(['message' => 'OK']);
    }

    public function markAllRead(Request $request): JsonResponse
    {
        Notification::where('user_id', $request->user()->id)->whereNull('read_at')->update(['read_at' => now()]);

        return response()->json(['message' => 'OK']);
    }
}
