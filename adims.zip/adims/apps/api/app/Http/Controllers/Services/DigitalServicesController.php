<?php

declare(strict_types=1);

namespace App\Http\Controllers\Services;

use App\Http\Controllers\Controller;
use App\Models\CarePlan;
use App\Models\Milestone;
use App\Models\ServiceProject;
use App\Models\SupportTicket;
use App\Services\AuditLogger;
use App\Services\CarePlanService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class DigitalServicesController extends Controller
{
    /** Allowed project status moves; anything else is rejected. */
    private const PROJECT_FLOW = [
        'draft' => ['agreed', 'cancelled'],
        'agreed' => ['in_progress', 'cancelled'],
        'in_progress' => ['client_review', 'on_hold', 'cancelled'],
        'on_hold' => ['in_progress', 'cancelled'],
        'client_review' => ['in_progress', 'completed'],
    ];

    public function __construct(private AuditLogger $audit, private CarePlanService $carePlans)
    {
    }

    public function transition(Request $request, ServiceProject $project): JsonResponse
    {
        $to = $request->validate(['status' => ['required', 'string']])['status'];
        $allowed = self::PROJECT_FLOW[$project->status] ?? [];

        if (! in_array($to, $allowed, true)) {
            throw ValidationException::withMessages(['status' => "A {$project->status} project cannot move to {$to}."]);
        }
        if ($to === 'agreed' && ! $project->agreed_kobo) {
            throw ValidationException::withMessages(['status' => 'Set the agreed price before the agreement.']);
        }
        if ($to === 'completed') {
            if (Milestone::where('service_project_id', $project->id)->where('status', '!=', 'approved')->exists()) {
                throw ValidationException::withMessages(['status' => 'All milestones must be approved by the client first.']);
            }
        }

        $before = $project->status;
        $project->update(['status' => $to] + ($to === 'completed' ? ['completed_at' => now()] : []));
        $this->audit->record('service_project.status_changed', $project, ['status' => $before], ['status' => $to]);

        return response()->json(['data' => $project->refresh()]);
    }

    public function submitMilestone(Milestone $milestone): JsonResponse
    {
        if (! in_array($milestone->status, ['pending', 'in_progress', 'rejected'], true)) {
            throw ValidationException::withMessages(['milestone' => 'This milestone cannot be submitted for approval.']);
        }
        $milestone->update(['status' => 'submitted']);

        return response()->json(['data' => $milestone->refresh()]);
    }

    public function replyToTicket(Request $request, SupportTicket $ticket): JsonResponse
    {
        $data = $request->validate(['body' => ['required', 'string', 'max:5000'], 'internal' => ['sometimes', 'boolean']]);
        $reply = $ticket->replies()->create(['author_id' => $request->user()->id, 'body' => $data['body'], 'internal' => $data['internal'] ?? false]);
        if ($ticket->status === 'open') {
            $ticket->update(['status' => 'in_progress']);
        }

        return response()->json(['data' => $reply], 201);
    }

    public function transitionTicket(Request $request, SupportTicket $ticket): JsonResponse
    {
        $data = $request->validate(['status' => ['required', 'in:in_progress,waiting_client,resolved,closed']]);
        $ticket->update(['status' => $data['status']] + (in_array($data['status'], ['resolved', 'closed'], true) ? ['resolved_at' => now()] : []));

        app(\App\Services\NotificationService::class)->send('ticket.updated', $ticket->contact, ['reference' => $ticket->reference, 'status' => str_replace('_', ' ', $ticket->status)]);

        return response()->json(['data' => $ticket->refresh()]);
    }

    public function renewCarePlan(Request $request, CarePlan $plan): JsonResponse
    {
        abort_unless($plan->status === 'active', 422, 'Only active care plans can be renewed.');

        return response()->json(['data' => $this->carePlans->generateRenewal($plan, $request->user()->id)], 201);
    }
}
