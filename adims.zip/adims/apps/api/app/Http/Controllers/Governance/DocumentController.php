<?php

declare(strict_types=1);

namespace App\Http\Controllers\Governance;

use App\Http\Controllers\Controller;
use App\Models\Document;
use App\Models\File;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/** Versioned repository. `restricted` documents additionally need governance.documents.manage to be read. */
class DocumentController extends Controller
{
    public function __construct(private AuditLogger $audit)
    {
    }

    public function index(Request $request): JsonResponse
    {
        $query = Document::latest('id');
        if (! $request->user()->hasPermission('governance.documents.manage')) {
            $query->whereIn('confidentiality', ['public', 'internal'])->where('status', 'active');
        }
        foreach (['category', 'status'] as $f) {
            if ($request->filled($f)) {
                $query->where($f, $request->query($f));
            }
        }

        return response()->json($query->paginate(min((int) $request->query('per_page', 25), 100)));
    }

    /** Creates a document (version 1) or, when document_id is given, its next version. */
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'document_id' => ['nullable', 'integer', 'exists:documents,id'],
            'title' => ['required_without:document_id', 'string', 'max:255'],
            'category' => ['required_without:document_id', 'in:policy,procedure,contract,minutes,report,other'],
            'confidentiality' => ['sometimes', 'in:public,internal,confidential,restricted'],
            'review_on' => ['nullable', 'date'],
            'retain_until' => ['nullable', 'date'],
            'change_note' => ['nullable', 'string', 'max:500'],
            'file' => ['required', 'file', 'max:51200', 'extensions:pdf,docx,xlsx,pptx,png,jpg'],
        ]);

        $document = DB::transaction(function () use ($data, $request) {
            $document = isset($data['document_id'])
                ? Document::whereKey($data['document_id'])->lockForUpdate()->firstOrFail()
                : Document::create(['title' => $data['title'], 'category' => $data['category'], 'confidentiality' => $data['confidentiality'] ?? 'internal',
                    'owner_id' => $request->user()->id, 'review_on' => $data['review_on'] ?? null, 'retain_until' => $data['retain_until'] ?? null, 'current_version' => 0]);

            $upload = $request->file('file');
            $disk = config('filesystems.private_disk', 's3');
            $key = 'documents/' . $document->id . '/' . Str::uuid() . '.' . $upload->getClientOriginalExtension();
            Storage::disk($disk)->putFileAs(dirname($key), $upload, basename($key), ['visibility' => 'private']);
            $file = File::create(['disk' => $disk, 'path' => $key, 'original_name' => $upload->getClientOriginalName(), 'mime_type' => $upload->getMimeType() ?? 'application/octet-stream',
                'size_bytes' => $upload->getSize(), 'sha256' => hash_file('sha256', $upload->getRealPath()), 'uploaded_by' => $request->user()->id]);

            $version = $document->current_version + 1;
            $document->versions()->create(['version' => $version, 'file_id' => $file->id, 'change_note' => $data['change_note'] ?? null, 'uploaded_by' => $request->user()->id]);
            $document->forceFill(['current_version' => $version])->save();
            $this->audit->record('document.version_added', $document, null, ['version' => $version]);

            return $document;
        });

        return response()->json(['data' => $document->load('versions')], 201);
    }

    public function download(Request $request, Document $document, int $version = 0): JsonResponse
    {
        if (in_array($document->confidentiality, ['confidential', 'restricted'], true) && ! $request->user()->hasPermission('governance.documents.manage')) {
            abort(403, 'This document is restricted.');
        }
        $v = $document->versions()->where('version', $version ?: $document->current_version)->firstOrFail();
        $file = File::findOrFail($v->file_id);
        $this->audit->record('document.downloaded', $document, null, ['version' => $v->version]);

        return response()->json(['url' => Storage::disk($file->disk)->temporaryUrl($file->path, now()->addMinutes(5)), 'expires_in' => 300]);
    }
}
