<?php

declare(strict_types=1);

namespace App\Http\Controllers\Procurement;

use App\Http\Controllers\Controller;
use App\Models\Asset;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/** Asset custody changes always write a movement row, under a row lock, so history is complete. */
class AssetController extends Controller
{
    public function __construct(private AuditLogger $audit)
    {
    }

    public function assign(Request $request, Asset $asset): JsonResponse
    {
        $data = $request->validate(['user_id' => ['required', 'integer', 'exists:users,id'], 'location' => ['nullable', 'string', 'max:255']]);

        return $this->move($asset, 'assign', ['available'], ['status' => 'assigned', 'assignee_id' => $data['user_id'], 'location' => $data['location'] ?? null], null, $data['user_id'], $request);
    }

    public function return(Request $request, Asset $asset): JsonResponse
    {
        $from = $asset->assignee_id;

        return $this->move($asset, 'return', ['assigned'], ['status' => 'available', 'assignee_id' => null], $from, null, $request);
    }

    public function transfer(Request $request, Asset $asset): JsonResponse
    {
        $data = $request->validate(['user_id' => ['required', 'integer', 'exists:users,id']]);
        $from = $asset->assignee_id;

        return $this->move($asset, 'transfer', ['assigned'], ['assignee_id' => $data['user_id']], $from, $data['user_id'], $request);
    }

    public function dispose(Request $request, Asset $asset): JsonResponse
    {
        $data = $request->validate(['reason' => ['required', 'string', 'max:500']]);

        return $this->move($asset, 'disposal', ['available', 'maintenance'], ['status' => 'disposed', 'assignee_id' => null, 'disposed_at' => now(), 'disposal_reason' => $data['reason']], $asset->assignee_id, null, $request);
    }

    private function move(Asset $asset, string $kind, array $allowedFrom, array $changes, ?int $from, ?int $to, Request $request): JsonResponse
    {
        DB::transaction(function () use ($asset, $kind, $allowedFrom, $changes, $from, $to, $request) {
            $locked = Asset::whereKey($asset->id)->lockForUpdate()->firstOrFail();
            if (! in_array($locked->status, $allowedFrom, true)) {
                throw ValidationException::withMessages(['asset' => "An asset that is {$locked->status} cannot be {$kind}ed."]);
            }
            $locked->update($changes);
            $locked->movements()->create(['kind' => $kind, 'from_user_id' => $from, 'to_user_id' => $to, 'location' => $changes['location'] ?? null, 'recorded_by' => $request->user()->id]);
            $this->audit->record("asset.{$kind}", $locked, null, $changes);
        });

        return response()->json(['data' => $asset->refresh()]);
    }
}
