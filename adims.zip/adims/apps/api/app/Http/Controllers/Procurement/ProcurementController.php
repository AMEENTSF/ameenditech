<?php

declare(strict_types=1);

namespace App\Http\Controllers\Procurement;

use App\Http\Controllers\Controller;
use App\Models\GoodsReceipt;
use App\Models\InventoryItem;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderLine;
use App\Models\PurchaseRequest;
use App\Models\StockMovement;
use App\Models\SupplierInvoice;
use App\Services\ApprovalService;
use App\Services\AuditLogger;
use App\Services\ReferenceGenerator;
use App\Support\Money;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Purchase request → approval → purchase order → approval → goods received → supplier invoice → approval.
 * Every approval goes through ApprovalService, so the two-approver rule above the threshold is enforced
 * the same way as for expenses. Status columns cannot be written through the generic CRUD endpoints.
 */
class ProcurementController extends Controller
{
    public function __construct(private ApprovalService $approvals, private ReferenceGenerator $refs, private AuditLogger $audit)
    {
    }

    public function submitRequest(Request $request, PurchaseRequest $purchaseRequest): JsonResponse
    {
        abort_unless($purchaseRequest->requested_by === $request->user()->id || $request->user()->hasPermission('procurement.requests.approve'), 403);
        $this->requireStatus($purchaseRequest->status, ['draft'], 'Only draft requests can be submitted.');

        DB::transaction(function () use ($purchaseRequest, $request) {
            $purchaseRequest->update(['status' => 'pending_approval']);
            $this->approvals->request($purchaseRequest, $request->user(), Money::fromKobo($purchaseRequest->estimated_kobo));
        });

        return response()->json(['data' => $purchaseRequest->refresh()]);
    }

    /** Create a purchase order from an approved request. The PO total is calculated from its lines. */
    public function createOrder(Request $request, PurchaseRequest $purchaseRequest): JsonResponse
    {
        $this->requireStatus($purchaseRequest->status, ['approved'], 'The purchase request is not approved.');
        $data = $request->validate([
            'supplier_id' => ['required', 'integer', 'exists:suppliers,id'],
            'expected_on' => ['nullable', 'date'],
            'lines' => ['required', 'array', 'min:1', 'max:100'],
            'lines.*.description' => ['required', 'string', 'max:255'],
            'lines.*.inventory_item_id' => ['nullable', 'integer', 'exists:inventory_items,id'],
            'lines.*.quantity' => ['required', 'integer', 'min:1'],
            'lines.*.unit_price_kobo' => ['required', 'integer', 'min:1'],
        ]);

        $order = DB::transaction(function () use ($data, $purchaseRequest, $request) {
            $total = array_sum(array_map(fn ($l) => $l['quantity'] * $l['unit_price_kobo'], $data['lines']));
            $order = PurchaseOrder::create([
                'number' => $this->refs->next('PO'), 'supplier_id' => $data['supplier_id'], 'purchase_request_id' => $purchaseRequest->id,
                'total_kobo' => $total, 'status' => 'draft', 'expected_on' => $data['expected_on'] ?? null, 'created_by' => $request->user()->id,
            ]);
            $order->lines()->createMany($data['lines']);
            $purchaseRequest->update(['status' => 'ordered']);

            return $order;
        });

        return response()->json(['data' => $order->load('lines')], 201);
    }

    public function submitOrder(Request $request, PurchaseOrder $order): JsonResponse
    {
        $this->requireStatus($order->status, ['draft'], 'Only draft orders can be submitted.');
        DB::transaction(function () use ($order, $request) {
            $order->update(['status' => 'pending_approval']);
            $this->approvals->request($order, $request->user(), Money::fromKobo($order->total_kobo));
        });

        return response()->json(['data' => $order->refresh()]);
    }

    public function sendOrder(PurchaseOrder $order): JsonResponse
    {
        $this->requireStatus($order->status, ['approved'], 'Only approved orders can be sent to the supplier.');
        $order->update(['status' => 'sent']);
        $this->audit->record('purchase_order.sent', $order);

        return response()->json(['data' => $order->refresh()]);
    }

    /** Goods can only be received against sent orders, never beyond the ordered quantity. */
    public function receiveGoods(Request $request, PurchaseOrder $order): JsonResponse
    {
        $data = $request->validate([
            'received_on' => ['required', 'date', 'before_or_equal:today'],
            'notes' => ['nullable', 'string'],
            'lines' => ['required', 'array', 'min:1'],
            'lines.*.purchase_order_line_id' => ['required', 'integer', 'distinct'],
            'lines.*.quantity' => ['required', 'integer', 'min:1'],
        ]);

        $receipt = DB::transaction(function () use ($order, $data, $request) {
            $order = PurchaseOrder::whereKey($order->id)->lockForUpdate()->firstOrFail();
            $this->requireStatus($order->status, ['sent', 'partially_received'], 'Goods can only be received against a sent order.');

            $receipt = GoodsReceipt::create([
                'purchase_order_id' => $order->id, 'number' => $this->refs->next('GRN'),
                'received_on' => $data['received_on'], 'received_by' => $request->user()->id, 'notes' => $data['notes'] ?? null,
            ]);

            foreach ($data['lines'] as $l) {
                $line = PurchaseOrderLine::where('purchase_order_id', $order->id)->lockForUpdate()->find($l['purchase_order_line_id']);
                if (! $line || $line->received_quantity + $l['quantity'] > $line->quantity) {
                    throw ValidationException::withMessages(['lines' => 'Received quantity exceeds the quantity ordered.']);
                }
                $line->increment('received_quantity', $l['quantity']);
                $receipt->lines()->create(['purchase_order_line_id' => $line->id, 'quantity' => $l['quantity']]);

                if ($line->inventory_item_id) {
                    $this->moveStock(InventoryItem::whereKey($line->inventory_item_id)->lockForUpdate()->firstOrFail(), 'receipt', $l['quantity'], "GRN {$receipt->number}", $request->user()->id);
                }
            }

            $outstanding = PurchaseOrderLine::where('purchase_order_id', $order->id)->whereColumn('received_quantity', '<', 'quantity')->exists();
            $order->update(['status' => $outstanding ? 'partially_received' : 'received']);
            $this->audit->record('goods.received', $order, null, ['grn' => $receipt->number]);

            return $receipt;
        });

        return response()->json(['data' => $receipt->load('lines')], 201);
    }

    public function submitSupplierInvoice(Request $request, SupplierInvoice $invoice): JsonResponse
    {
        $this->requireStatus($invoice->status, ['received'], 'Only newly received supplier invoices can be submitted.');
        DB::transaction(function () use ($invoice, $request) {
            $invoice->update(['status' => 'pending_approval']);
            $this->approvals->request($invoice, $request->user(), Money::fromKobo($invoice->total_kobo));
        });

        return response()->json(['data' => $invoice->refresh()]);
    }

    /** Manual stock issue/adjustment; stock can never go negative. */
    public function stockMovement(Request $request, InventoryItem $item): JsonResponse
    {
        $data = $request->validate([
            'kind' => ['required', 'in:issue,adjustment,return'],
            'quantity' => ['required', 'integer', 'not_in:0'],
            'reason' => ['required', 'string', 'max:255'],
        ]);

        DB::transaction(function () use ($item, $data, $request) {
            $locked = InventoryItem::whereKey($item->id)->lockForUpdate()->firstOrFail();
            $this->moveStock($locked, $data['kind'], (int) $data['quantity'], $data['reason'], $request->user()->id);
        });

        return response()->json(['data' => $item->refresh()]);
    }

    private function moveStock(InventoryItem $item, string $kind, int $quantity, string $reason, int $userId): void
    {
        $delta = match ($kind) {
            'receipt', 'return' => abs($quantity),
            'issue' => -abs($quantity),
            default => $quantity,
        };

        if ($item->quantity_on_hand + $delta < 0) {
            throw ValidationException::withMessages(['quantity' => 'Insufficient stock.']);
        }

        $item->update(['quantity_on_hand' => $item->quantity_on_hand + $delta]);
        StockMovement::create(['inventory_item_id' => $item->id, 'kind' => $kind, 'quantity' => $delta, 'reason' => $reason, 'recorded_by' => $userId]);
    }

    private function requireStatus(string $status, array $allowed, string $message): void
    {
        if (! in_array($status, $allowed, true)) {
            throw ValidationException::withMessages(['status' => $message]);
        }
    }
}
