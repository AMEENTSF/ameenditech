<?php

declare(strict_types=1);

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserSession;
use App\Services\AuditLogger;
use App\Services\MfaService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Password as PasswordRule;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function __construct(private MfaService $mfa, private AuditLogger $audit)
    {
    }

    /**
     * Web clients (same-site SPA) get a session cookie. Mobile clients send `device_name`
     * and receive an expiring bearer token. Rate limited by the `login` limiter.
     */
    public function login(Request $request): JsonResponse
    {
        $data = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
            'otp' => ['nullable', 'string', 'size:6'],
            'device_name' => ['nullable', 'string', 'max:100'],
        ]);

        $user = User::where('email', $data['email'])->first();

        // Same message for unknown user, bad password and suspended account: no account enumeration.
        if (! $user || ! Hash::check($data['password'], $user->password) || ! $user->isActive()) {
            if ($user) {
                $this->log($user, 'failed_login', $request);
            }
            throw ValidationException::withMessages(['email' => 'The provided credentials are incorrect.']);
        }

        if ($user->requiresMfa() && $user->mfa_confirmed_at !== null) {
            if (empty($data['otp'])) {
                return response()->json(['mfa_required' => true, 'message' => 'Enter your authentication code.'], 422);
            }
            if (! $this->mfa->verify($user, $data['otp'])) {
                $this->log($user, 'failed_login', $request);
                throw ValidationException::withMessages(['otp' => 'Invalid authentication code.']);
            }
        }

        $user->forceFill(['last_login_at' => now()])->save();
        $this->log($user, 'login', $request);

        $payload = ['user' => $this->profile($user), 'mfa_setup_required' => $user->requiresMfa() && $user->mfa_confirmed_at === null];

        if (! empty($data['device_name'])) {
            $payload['token'] = $user->createToken($data['device_name'], ['*'], now()->addDays(14))->plainTextToken;
        } else {
            Auth::guard('web')->login($user);
            $request->session()->regenerate();
        }

        return response()->json($payload);
    }

    public function logout(Request $request): JsonResponse
    {
        $user = $request->user();
        $this->log($user, 'logout', $request);

        $token = $user->currentAccessToken();
        if ($token && method_exists($token, 'delete')) {
            $token->delete();
        } else {
            Auth::guard('web')->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
        }

        return response()->json(['message' => 'Signed out.']);
    }

    public function me(Request $request): JsonResponse
    {
        return response()->json(['user' => $this->profile($request->user())]);
    }

    public function changePassword(Request $request): JsonResponse
    {
        $data = $request->validate([
            'current_password' => ['required', 'current_password'],
            'password' => ['required', 'confirmed', 'different:current_password', $this->passwordRule()],
        ]);

        $user = $request->user();
        $user->forceFill(['password' => $data['password'], 'password_changed_at' => now()])->save();
        $user->tokens()->where('id', '!=', $user->currentAccessToken()?->id)->delete();
        $this->audit->record('auth.password_changed', $user);

        return response()->json(['message' => 'Password updated.']);
    }

    public function forgotPassword(Request $request): JsonResponse
    {
        $request->validate(['email' => ['required', 'email']]);
        Password::sendResetLink($request->only('email'));

        // Always the same answer so the endpoint cannot be used to discover accounts.
        return response()->json(['message' => 'If that account exists, a reset link has been sent.']);
    }

    public function resetPassword(Request $request): JsonResponse
    {
        $data = $request->validate([
            'token' => ['required'],
            'email' => ['required', 'email'],
            'password' => ['required', 'confirmed', $this->passwordRule()],
        ]);

        $status = Password::reset($data, function (User $user, string $password) {
            $user->forceFill(['password' => $password, 'password_changed_at' => now()])->save();
            $user->tokens()->delete();
            $this->audit->record('auth.password_reset', $user, null, null, $user->id);
        });

        if ($status !== Password::PASSWORD_RESET) {
            throw ValidationException::withMessages(['email' => __($status)]);
        }

        return response()->json(['message' => 'Password has been reset.']);
    }

    public function mfaSetup(Request $request): JsonResponse
    {
        return response()->json($this->mfa->begin($request->user()));
    }

    public function mfaConfirm(Request $request): JsonResponse
    {
        $data = $request->validate(['code' => ['required', 'string', 'size:6']]);

        if (! $this->mfa->confirm($request->user(), $data['code'])) {
            throw ValidationException::withMessages(['code' => 'Invalid authentication code.']);
        }
        $this->audit->record('auth.mfa_enabled', $request->user());

        return response()->json(['message' => 'Multi-factor authentication enabled.']);
    }

    /** Active tokens plus the latest login history for the signed-in user. */
    public function sessions(Request $request): JsonResponse
    {
        $user = $request->user();

        return response()->json([
            'tokens' => $user->tokens()->get(['id', 'name', 'last_used_at', 'expires_at', 'created_at']),
            'history' => UserSession::where('user_id', $user->id)->latest('occurred_at')->limit(30)->get(),
        ]);
    }

    public function revokeToken(Request $request, int $tokenId): JsonResponse
    {
        $request->user()->tokens()->whereKey($tokenId)->delete();

        return response()->json(['message' => 'Session revoked.']);
    }

    private function profile(User $user): array
    {
        $user->loadMissing('contact', 'roles:id,slug,name');

        return [
            'id' => $user->id,
            'email' => $user->email,
            'name' => $user->contact?->full_name,
            'status' => $user->status,
            'roles' => $user->roles->map(fn ($r) => ['slug' => $r->slug, 'name' => $r->name])->values(),
            'permissions' => $user->hasRole('super-administrator') ? ['*'] : $user->permissionSlugs(),
            'mfa_enabled' => $user->mfa_confirmed_at !== null,
        ];
    }

    private function passwordRule(): PasswordRule
    {
        return PasswordRule::min(12)->mixedCase()->numbers()->symbols()->uncompromised();
    }

    private function log(User $user, string $event, Request $request): void
    {
        UserSession::create([
            'user_id' => $user->id,
            'event' => $event,
            'ip_address' => $request->ip(),
            'user_agent' => Str::limit((string) $request->userAgent(), 250, ''),
        ]);
    }
}
