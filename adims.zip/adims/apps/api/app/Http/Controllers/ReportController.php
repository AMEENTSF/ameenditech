<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Services\AuditLogger;
use App\Services\ReportService;
use App\Support\ReportExporter;
use Carbon\CarbonImmutable;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ReportController extends Controller
{
    public function catalogue(Request $request): JsonResponse
    {
        $user = $request->user();

        return response()->json(['data' => collect(ReportService::CATALOGUE)->filter(fn ($perm) => $user->hasPermission($perm))->keys()->values()]);
    }

    /** JSON for on-screen use; csv/xlsx/pdf additionally need reports.export and are audited. */
    public function show(Request $request, string $slug, ReportService $reports, ReportExporter $exporter, AuditLogger $audit): Response|JsonResponse
    {
        $permission = ReportService::CATALOGUE[$slug] ?? null;
        abort_unless($permission, 404);
        abort_unless($request->user()->hasPermission($permission), 403, 'You do not have access to this report.');

        $data = $request->validate([
            'from' => ['nullable', 'date'], 'to' => ['nullable', 'date', 'after_or_equal:from'], 'format' => ['nullable', 'in:json,csv,xlsx,pdf'],
        ]);
        $to = CarbonImmutable::parse($data['to'] ?? now('Africa/Lagos'))->endOfDay();
        $from = CarbonImmutable::parse($data['from'] ?? $to->subMonths(12))->startOfDay();
        $format = $data['format'] ?? 'json';

        $report = $reports->run($slug, $from, $to);

        if ($format === 'json') {
            return response()->json($report + ['period' => ['from' => $from->toDateString(), 'to' => $to->toDateString()]]);
        }

        abort_unless($request->user()->hasPermission('reports.export'), 403, 'You do not have permission to export reports.');
        $audit->record('report.exported', null, null, ['report' => $slug, 'format' => $format, 'rows' => count($report['rows'])]);

        return $exporter->export($report, $format, "adims-{$slug}-" . now('Africa/Lagos')->format('Ymd'));
    }
}
