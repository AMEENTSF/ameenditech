<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Services\DashboardService;
use Carbon\CarbonImmutable;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function executive(Request $request, DashboardService $dashboard): JsonResponse
    {
        $data = $request->validate(['from' => ['nullable', 'date'], 'to' => ['nullable', 'date', 'after_or_equal:from']]);

        $to = CarbonImmutable::parse($data['to'] ?? now('Africa/Lagos'))->endOfDay();
        $from = CarbonImmutable::parse($data['from'] ?? $to->subDays(89))->startOfDay();
        abort_if($from->diffInDays($to) > 800, 422, 'Date range too large.');

        return response()->json($dashboard->build($request->user(), $from, $to));
    }
}
