<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Services\AuditLogger;
use App\Services\ReferenceGenerator;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

/**
 * Generic, registry-driven CRUD for the many plain reference/operational tables.
 * Everything is declared in config/resources.php (generated from the schema definition):
 * permissions, validation rules, searchable columns and columns that clients may never set
 * (status transitions, approvals, reference numbers, actor columns).
 * Workflows with business rules have dedicated controllers and are marked readonly here.
 */
class ResourceController extends Controller
{
    private const ACTIONS = ['index' => 'view', 'show' => 'view', 'store' => 'create', 'update' => 'update', 'destroy' => 'delete'];

    public function __construct(private AuditLogger $audit, private ReferenceGenerator $references)
    {
    }

    public function index(Request $request, string $resource): JsonResponse
    {
        $cfg = $this->config($resource, 'index');
        $query = $this->model($cfg)->newQuery();

        if ($cfg['with']) {
            $query->with($cfg['with']);
        }

        foreach ((array) $request->query('filter', []) as $column => $value) {
            if (isset($cfg['rules'][$column]) && is_scalar($value)) {
                $query->where($column, $value);
            }
        }

        if (($term = trim((string) $request->query('q', ''))) !== '' && $cfg['search']) {
            $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $term) . '%';
            $query->where(fn ($q) => collect($cfg['search'])->each(fn ($col) => $q->orWhere($col, 'ilike', $like)));
        }

        $sort = (string) $request->query('sort', '-id');
        $column = ltrim($sort, '-');
        if ($column === 'id' || isset($cfg['rules'][$column])) {
            $query->orderBy($column, str_starts_with($sort, '-') ? 'desc' : 'asc');
        }

        return response()->json($query->paginate(min((int) $request->query('per_page', 25), 100)));
    }

    public function show(Request $request, string $resource, int $id): JsonResponse
    {
        $cfg = $this->config($resource, 'show');
        $query = $this->model($cfg)->newQuery();
        if ($cfg['with']) {
            $query->with($cfg['with']);
        }

        return response()->json(['data' => $query->findOrFail($id)]);
    }

    public function store(Request $request, string $resource): JsonResponse
    {
        $cfg = $this->config($resource, 'store');
        $data = $request->validate($this->rules($cfg, null));

        $record = DB::transaction(function () use ($cfg, $data, $request) {
            if ($cfg['actor']) {
                $data[$cfg['actor']] = $request->user()->id;
            }
            if ($cfg['auto_ref']) {
                [$column, $prefix] = $cfg['auto_ref'];
                $data[$column] = $this->references->next($prefix);
            }
            $record = $this->model($cfg)->create($data);
            $this->audit->record($cfg['table'] . '.created', $record, null, $record->getAttributes());

            return $record;
        });

        return response()->json(['data' => $record->refresh()], 201);
    }

    public function update(Request $request, string $resource, int $id): JsonResponse
    {
        $cfg = $this->config($resource, 'update');
        $record = $this->model($cfg)->newQuery()->findOrFail($id);
        $data = $request->validate($this->rules($cfg, $id, update: true));

        DB::transaction(function () use ($record, $data, $cfg) {
            $before = $record->getOriginal();
            $record->update($data);
            $changed = array_intersect_key($before, $record->getChanges());
            $this->audit->record($cfg['table'] . '.updated', $record, $changed, $record->getChanges());
        });

        return response()->json(['data' => $record->refresh()]);
    }

    public function destroy(Request $request, string $resource, int $id): JsonResponse
    {
        $cfg = $this->config($resource, 'destroy');
        $record = $this->model($cfg)->newQuery()->findOrFail($id);

        try {
            DB::transaction(function () use ($record, $cfg) {
                $this->audit->record($cfg['table'] . '.deleted', $record, $record->getAttributes());
                $record->delete();
            });
        } catch (QueryException) {
            // Foreign keys protect business records: report instead of leaking SQL.
            return response()->json(['message' => 'This record is in use and cannot be deleted.'], 409);
        }

        return response()->json(null, 204);
    }

    /** Resolve registry config and enforce the permission for this action. */
    private function config(string $resource, string $action): array
    {
        $cfg = config("resources.{$resource}");
        abort_unless($cfg, 404);

        $verb = self::ACTIONS[$action];
        if ($cfg['readonly'] && $verb !== 'view') {
            abort(405, 'This resource is changed through its dedicated workflow.');
        }

        abort_unless(
            request()->user()?->hasPermission("{$cfg['module']}.{$cfg['resource']}.{$verb}"),
            403,
            'You do not have permission to perform this action.'
        );

        return $cfg;
    }

    private function model(array $cfg): Model
    {
        $class = 'App\\Models\\' . $cfg['model'];

        return new $class();
    }

    private function rules(array $cfg, ?int $ignoreId, bool $update = false): array
    {
        $rules = [];
        foreach ($cfg['rules'] as $column => $rule) {
            if ($update) {
                $rule = array_map(fn ($r) => $r === 'required' ? 'sometimes' : $r, $rule);
            }
            if (in_array($column, $cfg['unique'], true)) {
                $rule[] = Rule::unique($cfg['table'], $column)->ignore($ignoreId);
            }
            $rules[$column] = $rule;
        }

        return $rules;
    }
}
