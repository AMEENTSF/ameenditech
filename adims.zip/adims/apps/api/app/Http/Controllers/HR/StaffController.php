<?php

declare(strict_types=1);

namespace App\Http\Controllers\HR;

use App\Http\Controllers\Controller;
use App\Models\LeaveRequest;
use App\Models\LeaveType;
use App\Models\StaffProfile;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class StaffController extends Controller
{
    public function __construct(private AuditLogger $audit)
    {
    }

    /** Offboarding: closes the profile, ends open assignments and immediately removes system access. */
    public function deactivate(Request $request, StaffProfile $staff): JsonResponse
    {
        $data = $request->validate(['left_on' => ['required', 'date']]);
        abort_if($staff->user_id === $request->user()->id, 422, 'You cannot deactivate yourself.');

        DB::transaction(function () use ($staff, $data) {
            $staff->update(['status' => 'terminated', 'left_on' => $data['left_on']]);
            $staff->assignments()->whereNull('ends_on')->update(['ends_on' => $data['left_on']]);
            $user = $staff->user;
            $user->update(['status' => 'suspended']);
            $user->tokens()->delete();
            $this->audit->record('staff.deactivated', $staff, null, ['left_on' => $data['left_on']]);
        });

        return response()->json(['data' => $staff->refresh()]);
    }

    /** Staff submit leave for themselves; balance is checked against the leave type allowance for the year. */
    public function requestLeave(Request $request): JsonResponse
    {
        $profile = StaffProfile::where('user_id', $request->user()->id)->firstOrFail();
        $data = $request->validate([
            'leave_type_id' => ['required', 'integer', 'exists:leave_types,id'],
            'starts_on' => ['required', 'date', 'after_or_equal:today'],
            'ends_on' => ['required', 'date', 'after_or_equal:starts_on'],
            'reason' => ['nullable', 'string', 'max:1000'],
        ]);

        $days = $this->days($data['starts_on'], $data['ends_on']);
        $type = LeaveType::findOrFail($data['leave_type_id']);
        $used = $this->usedDays($profile->id, $type->id, substr($data['starts_on'], 0, 4));
        if ($used + $days > $type->default_days) {
            throw ValidationException::withMessages(['ends_on' => "Only " . max(0, $type->default_days - $used) . " {$type->name} days remain this year."]);
        }

        return response()->json(['data' => LeaveRequest::create($data + ['staff_profile_id' => $profile->id, 'status' => 'pending'])], 201);
    }

    /** Approver must be someone other than the requester; overlapping approved leave is rejected. */
    public function decideLeave(Request $request, LeaveRequest $leave): JsonResponse
    {
        $data = $request->validate(['decision' => ['required', 'in:approved,rejected']]);

        DB::transaction(function () use ($leave, $data, $request) {
            $leave = LeaveRequest::whereKey($leave->id)->lockForUpdate()->firstOrFail();
            if ($leave->status !== 'pending') {
                throw ValidationException::withMessages(['leave' => 'This request has already been decided.']);
            }
            if ($leave->staffProfile->user_id === $request->user()->id) {
                throw ValidationException::withMessages(['leave' => 'You cannot decide your own leave request.']);
            }
            if ($data['decision'] === 'approved' && LeaveRequest::where('staff_profile_id', $leave->staff_profile_id)->where('status', 'approved')
                ->whereDate('starts_on', '<=', $leave->ends_on)->whereDate('ends_on', '>=', $leave->starts_on)->exists()) {
                throw ValidationException::withMessages(['leave' => 'Overlaps with already approved leave.']);
            }
            $leave->update(['status' => $data['decision'], 'decided_by' => $request->user()->id, 'decided_at' => now()]);
            $this->audit->record("leave.{$data['decision']}", $leave);
        });

        return response()->json(['data' => $leave->refresh()]);
    }

    private function days(string $from, string $to): int
    {
        return (int) (new \DateTimeImmutable($from))->diff(new \DateTimeImmutable($to))->days + 1;
    }

    private function usedDays(int $profileId, int $typeId, string $year): int
    {
        return LeaveRequest::where('staff_profile_id', $profileId)->where('leave_type_id', $typeId)->whereIn('status', ['pending', 'approved'])
            ->whereYear('starts_on', $year)->get(['starts_on', 'ends_on'])
            ->sum(fn ($l) => $this->days($l->starts_on->toDateString(), $l->ends_on->toDateString()));
    }
}
