<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Contact;
use App\Models\Enrolment;
use App\Models\Invoice;
use App\Models\Milestone;
use App\Models\Payment;
use App\Models\Quotation;
use App\Models\ResearchProject;
use App\Models\ServiceProject;
use App\Models\SupportTicket;
use App\Services\PaymentService;
use App\Services\ReferenceGenerator;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Self-service for clients and learners. Every query is scoped to the signed-in user's own contact;
 * there is no way to pass another contact id. Only requires authentication, never staff permissions.
 */
class PortalController extends Controller
{
    private function contactId(Request $request): int
    {
        return (int) $request->user()->contact_id;
    }

    public function overview(Request $request): JsonResponse
    {
        $c = $this->contactId($request);

        return response()->json([
            'invoices' => Invoice::where('contact_id', $c)->whereNotIn('status', ['draft'])->latest('id')->limit(50)->get(['id', 'number', 'status', 'total_kobo', 'paid_kobo', 'due_on']),
            'research_projects' => ResearchProject::where('client_contact_id', $c)->latest('id')->get(['id', 'reference', 'title', 'stage', 'due_on']),
            'service_projects' => ServiceProject::where('contact_id', $c)->latest('id')->get(['id', 'reference', 'title', 'status', 'due_on']),
            'enrolments' => Enrolment::with('cohort.course:id,title')->where('contact_id', $c)->latest('id')->get(),
            'tickets' => SupportTicket::where('contact_id', $c)->latest('id')->limit(30)->get(['id', 'reference', 'subject', 'status']),
            'quotations' => Quotation::where('contact_id', $c)->whereIn('status', ['sent', 'accepted'])->latest('id')->get(['id', 'number', 'title', 'total_kobo', 'status', 'valid_until']),
        ]);
    }

    /**
     * A customer reports a transfer. This only records a CLAIM in pending_verification; the invoice
     * is not marked paid until staff (or a trusted gateway webhook) verify it.
     */
    public function claimPayment(Request $request, PaymentService $payments, ReferenceGenerator $refs): JsonResponse
    {
        $data = $request->validate([
            'invoice_id' => ['required', 'integer'], 'amount_kobo' => ['required', 'integer', 'min:1'],
            'receipt' => ['required', 'file', 'max:5120', 'extensions:pdf,png,jpg,jpeg'],
        ]);
        $invoice = Invoice::where('contact_id', $this->contactId($request))->whereIn('status', ['issued', 'partially_paid'])->findOrFail($data['invoice_id']);
        if ($data['amount_kobo'] > $invoice->balance_kobo) {
            throw ValidationException::withMessages(['amount_kobo' => 'Amount exceeds the outstanding balance.']);
        }

        $upload = $request->file('receipt');
        $disk = config('filesystems.private_disk', 's3');
        $key = 'receipts/' . date('Y') . '/' . \Illuminate\Support\Str::uuid() . '.' . $upload->getClientOriginalExtension();
        \Illuminate\Support\Facades\Storage::disk($disk)->putFileAs(dirname($key), $upload, basename($key), ['visibility' => 'private']);

        $payment = DB::transaction(function () use ($request, $data, $payments, $refs, $upload, $disk, $key) {
            $file = \App\Models\File::create(['disk' => $disk, 'path' => $key, 'original_name' => $upload->getClientOriginalName(), 'mime_type' => $upload->getMimeType() ?? 'application/octet-stream',
                'size_bytes' => $upload->getSize(), 'sha256' => hash_file('sha256', $upload->getRealPath()), 'uploaded_by' => $request->user()->id]);

            return $payments->recordClaim(['reference' => $refs->next('PAY'), 'contact_id' => $this->contactId($request), 'amount_kobo' => $data['amount_kobo'], 'method' => 'bank_transfer', 'receipt_file_id' => $file->id]);
        });

        return response()->json(['reference' => $payment->reference, 'status' => $payment->status, 'message' => 'Received. Your payment will be confirmed once verified.'], 201);
    }

    public function acceptQuotation(Request $request, Quotation $quotation): JsonResponse
    {
        abort_unless($quotation->contact_id === $this->contactId($request), 404);
        abort_unless($quotation->status === 'sent' && (! $quotation->valid_until || $quotation->valid_until->isFuture()), 422, 'This quotation cannot be accepted.');
        $quotation->update(['status' => 'accepted', 'accepted_at' => now()]);
        app(\App\Services\AuditLogger::class)->record('quotation.accepted_by_client', $quotation);

        return response()->json(['data' => $quotation->refresh()]);
    }

    public function approveMilestone(Request $request, Milestone $milestone): JsonResponse
    {
        $data = $request->validate(['decision' => ['required', 'in:approved,rejected']]);
        abort_unless(ServiceProject::whereKey($milestone->service_project_id)->where('contact_id', $this->contactId($request))->exists(), 404);
        abort_unless($milestone->status === 'submitted', 422, 'This milestone is not awaiting approval.');
        $milestone->update(['status' => $data['decision'], 'approved_by_contact_id' => $this->contactId($request), 'approved_at' => now()]);

        return response()->json(['data' => $milestone->refresh()]);
    }

    public function openTicket(Request $request, ReferenceGenerator $refs): JsonResponse
    {
        $data = $request->validate(['subject' => ['required', 'string', 'max:255'], 'description' => ['nullable', 'string', 'max:5000'], 'service_project_id' => ['nullable', 'integer']]);
        if (! empty($data['service_project_id'])) {
            abort_unless(ServiceProject::whereKey($data['service_project_id'])->where('contact_id', $this->contactId($request))->exists(), 404);
        }
        $ticket = SupportTicket::create($data + ['reference' => $refs->next('TKT'), 'contact_id' => $this->contactId($request), 'status' => 'open', 'priority' => 'normal']);

        return response()->json(['data' => $ticket], 201);
    }

    public function feedback(Request $request): JsonResponse
    {
        $data = $request->validate(['rating' => ['required', 'integer', 'between:1,5'], 'comment' => ['nullable', 'string', 'max:2000'], 'subject_type' => ['nullable', 'in:research_project,service_project,enrolment'], 'subject_id' => ['nullable', 'integer']]);
        Contact::findOrFail($this->contactId($request))->feedback()->create($data);

        return response()->json(['message' => 'Thank you for your feedback.'], 201);
    }
}
