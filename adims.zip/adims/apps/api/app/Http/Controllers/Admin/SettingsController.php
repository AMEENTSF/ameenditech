<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SystemSetting;
use App\Services\SettingsService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class SettingsController extends Controller
{
    /** Only these keys are editable at runtime, each with its own validation. */
    private const EDITABLE = [
        'finance.dual_approval_threshold_kobo' => ['integer', 'min:0'],
        'research.deposit_basis_points' => ['integer', 'between:0,10000'],
        'training.min_attendance_percent' => ['integer', 'between:0,100'],
        'training.pass_mark_percent' => ['integer', 'between:0,100'],
        'accounts.bank' => ['string', 'max:20'],
        'accounts.receivable' => ['string', 'max:20'],
        'accounts.payable' => ['string', 'max:20'],
        'accounts.revenue' => ['string', 'max:20'],
        'accounts.general_expense' => ['string', 'max:20'],
    ];

    public function index(): JsonResponse
    {
        $stored = SystemSetting::pluck('value', 'key');

        return response()->json(['data' => collect(array_keys(self::EDITABLE))->mapWithKeys(fn ($k) => [$k => $stored[$k] ?? null])]);
    }

    public function update(Request $request, SettingsService $settings): JsonResponse
    {
        $data = $request->validate([
            'key' => ['required', Rule::in(array_keys(self::EDITABLE))],
            'value' => ['required'],
        ]);
        validator(['value' => $data['value']], ['value' => self::EDITABLE[$data['key']]])->validate();

        $settings->set($data['key'], $data['value'], $request->user()->id);

        return response()->json(['message' => 'Setting saved.']);
    }
}
