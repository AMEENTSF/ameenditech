<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Contact;
use App\Models\Role;
use App\Models\User;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class UserController extends Controller
{
    public function __construct(private AuditLogger $audit)
    {
    }

    public function index(Request $request): JsonResponse
    {
        $query = User::with('contact:id,first_name,last_name', 'roles:id,slug,name')->latest('id');
        if ($term = trim((string) $request->query('q', ''))) {
            $query->where('email', 'ilike', '%' . str_replace(['%', '_'], ['\%', '\_'], $term) . '%');
        }
        if ($request->filled('status')) {
            $query->where('status', $request->query('status'));
        }

        return response()->json($query->paginate(min((int) $request->query('per_page', 25), 100)));
    }

    /** Creates the person (or reuses a contact) and a login with a random password; the user sets their own via the reset link. */
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'first_name' => ['required', 'string', 'max:100'],
            'last_name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', 'unique:users,email'],
            'phone' => ['nullable', 'string', 'max:30'],
            'contact_id' => ['nullable', 'integer', 'exists:contacts,id', 'unique:users,contact_id'],
            'roles' => ['required', 'array', 'min:1'],
            'roles.*' => ['string', 'exists:roles,slug'],
        ]);
        $this->guardSuperAdminGrant($request, $data['roles']);

        $user = DB::transaction(function () use ($data, $request) {
            $contact = isset($data['contact_id']) ? Contact::findOrFail($data['contact_id'])
                : Contact::create(['first_name' => $data['first_name'], 'last_name' => $data['last_name'], 'email' => $data['email'], 'phone' => $data['phone'] ?? null, 'category' => 'staff']);
            $user = User::create(['contact_id' => $contact->id, 'email' => $data['email'], 'password' => Str::random(40), 'status' => 'active']);
            $this->sync($user, $data['roles'], $request->user());
            $this->audit->record('user.created', $user, null, ['email' => $user->email, 'roles' => $data['roles']]);

            return $user;
        });

        Password::sendResetLink(['email' => $user->email]);

        return response()->json(['data' => $user->load('roles')], 201);
    }

    public function updateRoles(Request $request, User $user): JsonResponse
    {
        $data = $request->validate(['roles' => ['required', 'array', 'min:1'], 'roles.*' => ['string', 'exists:roles,slug']]);
        $this->guardSuperAdminGrant($request, $data['roles']);
        $before = $user->roles()->pluck('slug')->all();

        // Never let the last super administrator lose the role.
        if (in_array('super-administrator', $before, true) && ! in_array('super-administrator', $data['roles'], true)) {
            $this->assertAnotherSuperAdminExists($user);
        }

        DB::transaction(function () use ($user, $data, $request, $before) {
            $this->sync($user, $data['roles'], $request->user());
            $this->audit->record('user.roles_changed', $user, ['roles' => $before], ['roles' => $data['roles']]);
        });

        return response()->json(['data' => $user->load('roles')]);
    }

    public function setStatus(Request $request, User $user): JsonResponse
    {
        $data = $request->validate(['status' => ['required', 'in:active,suspended']]);

        if ($user->id === $request->user()->id) {
            throw ValidationException::withMessages(['status' => 'You cannot change your own status.']);
        }
        if ($data['status'] === 'suspended' && $user->hasRole('super-administrator')) {
            $this->assertAnotherSuperAdminExists($user);
        }

        $user->update(['status' => $data['status']]);
        if ($data['status'] === 'suspended') {
            $user->tokens()->delete(); // immediate lock-out of mobile sessions; web sessions fail the isActive() check
        }
        $this->audit->record("user.{$data['status']}", $user);

        return response()->json(['data' => $user->refresh()]);
    }

    private function sync(User $user, array $slugs, User $by): void
    {
        $ids = Role::whereIn('slug', $slugs)->pluck('id')->mapWithKeys(fn ($id) => [$id => ['assigned_by' => $by->id]])->all();
        $user->roles()->sync($ids);
    }

    private function guardSuperAdminGrant(Request $request, array $slugs): void
    {
        if (in_array('super-administrator', $slugs, true) && ! $request->user()->hasRole('super-administrator')) {
            abort(403, 'Only a super administrator can grant that role.');
        }
    }

    private function assertAnotherSuperAdminExists(User $except): void
    {
        $others = User::where('id', '!=', $except->id)->where('status', 'active')
            ->whereHas('roles', fn ($q) => $q->where('slug', 'super-administrator'))->exists();
        if (! $others) {
            throw ValidationException::withMessages(['roles' => 'At least one active super administrator must remain.']);
        }
    }
}
