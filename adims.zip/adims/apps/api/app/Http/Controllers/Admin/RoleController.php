<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class RoleController extends Controller
{
    public function __construct(private AuditLogger $audit)
    {
    }

    public function index(): JsonResponse
    {
        return response()->json(['data' => Role::with('permissions:id,slug')->withCount('users')->orderBy('name')->get()]);
    }

    public function permissions(): JsonResponse
    {
        return response()->json(['data' => Permission::orderBy('module')->orderBy('slug')->get(['id', 'slug', 'module'])->groupBy('module')]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:100', 'unique:roles,name'],
            'description' => ['nullable', 'string', 'max:500'],
            'requires_mfa' => ['sometimes', 'boolean'],
            'permissions' => ['array'],
            'permissions.*' => ['string', 'exists:permissions,slug'],
        ]);

        $role = Role::create(['slug' => Str::slug($data['name']), 'name' => $data['name'], 'description' => $data['description'] ?? null, 'requires_mfa' => $data['requires_mfa'] ?? false, 'is_system' => false]);
        $role->permissions()->sync(Permission::whereIn('slug', $data['permissions'] ?? [])->pluck('id'));
        $this->audit->record('role.created', $role, null, ['permissions' => $data['permissions'] ?? []]);

        return response()->json(['data' => $role->load('permissions:id,slug')], 201);
    }

    public function update(Request $request, Role $role): JsonResponse
    {
        abort_if($role->slug === 'super-administrator', 422, 'The super administrator role cannot be edited.');
        $data = $request->validate([
            'description' => ['sometimes', 'nullable', 'string', 'max:500'],
            'requires_mfa' => ['sometimes', 'boolean'],
            'permissions' => ['sometimes', 'array'],
            'permissions.*' => ['string', 'exists:permissions,slug'],
        ]);

        $before = $role->permissions()->pluck('slug')->all();
        $role->update(collect($data)->only(['description', 'requires_mfa'])->all());
        if (isset($data['permissions'])) {
            $role->permissions()->sync(Permission::whereIn('slug', $data['permissions'])->pluck('id'));
        }
        $this->audit->record('role.updated', $role, ['permissions' => $before], ['permissions' => $data['permissions'] ?? $before]);

        return response()->json(['data' => $role->load('permissions:id,slug')]);
    }

    public function destroy(Role $role): JsonResponse
    {
        abort_if($role->is_system, 422, 'System roles cannot be deleted.');
        abort_if($role->users()->exists(), 409, 'Reassign users before deleting this role.');
        $this->audit->record('role.deleted', $role);
        $role->delete();

        return response()->json(null, 204);
    }
}
