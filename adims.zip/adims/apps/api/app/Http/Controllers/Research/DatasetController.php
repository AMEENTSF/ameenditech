<?php

declare(strict_types=1);

namespace App\Http\Controllers\Research;

use App\Http\Controllers\Controller;
use App\Models\Dataset;
use App\Models\File;
use App\Models\ResearchProject;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * Client datasets are confidential: stored on the private disk under a random key and only ever
 * handed out as a short-lived signed URL after a permission and project-membership check. Every
 * download is audited.
 */
class DatasetController extends Controller
{
    private const ALLOWED = ['csv', 'xlsx', 'xls', 'sav', 'dta', 'rds', 'json', 'txt', 'zip', 'parquet'];

    public function __construct(private AuditLogger $audit)
    {
    }

    public function store(Request $request, int $project): JsonResponse
    {
        $project = $this->project($request, $project);
        $request->validate([
            'file' => ['required', 'file', 'max:204800', 'extensions:' . implode(',', self::ALLOWED)],
            'label' => ['required', 'string', 'max:255'],
            'classification' => ['nullable', 'in:confidential,restricted,internal'],
        ]);

        $upload = $request->file('file');
        $disk = config('filesystems.private_disk', 's3');
        $key = "research/{$project->reference}/datasets/" . Str::uuid() . '.' . $upload->getClientOriginalExtension();

        $dataset = DB::transaction(function () use ($upload, $disk, $key, $project, $request) {
            Storage::disk($disk)->putFileAs(dirname($key), $upload, basename($key), ['visibility' => 'private']);
            $file = File::create([
                'disk' => $disk, 'path' => $key, 'original_name' => $upload->getClientOriginalName(),
                'mime_type' => $upload->getMimeType() ?? 'application/octet-stream', 'size_bytes' => $upload->getSize(),
                'sha256' => hash_file('sha256', $upload->getRealPath()), 'visibility' => 'private', 'uploaded_by' => $request->user()->id,
            ]);
            $dataset = Dataset::create([
                'research_project_id' => $project->id, 'file_id' => $file->id, 'label' => $request->input('label'),
                'classification' => $request->input('classification', 'confidential'),
            ]);
            $this->audit->record('dataset.uploaded', $dataset, null, ['file' => $file->original_name, 'sha256' => $file->sha256]);

            return $dataset;
        });

        return response()->json(['data' => $dataset], 201);
    }

    public function download(Request $request, int $project, Dataset $dataset): JsonResponse
    {
        $project = $this->project($request, $project);
        abort_unless($dataset->research_project_id === $project->id, 404);

        $file = $dataset->file;
        $this->audit->record('dataset.downloaded', $dataset, null, ['file_id' => $file->id]);

        return response()->json([
            'url' => Storage::disk($file->disk)->temporaryUrl($file->path, now()->addMinutes(5), ['ResponseContentDisposition' => 'attachment; filename="' . addslashes($file->original_name) . '"']),
            'expires_in' => 300,
        ]);
    }

    private function project(Request $request, int $id): ResearchProject
    {
        $user = $request->user();
        $query = ResearchProject::query();
        if (! $user->hasPermission('research.projects.view_all')) {
            $query->where(fn ($q) => $q->where('manager_id', $user->id)
                ->orWhereIn('id', fn ($s) => $s->select('research_project_id')->from('project_team_members')->where('user_id', $user->id)));
        }

        return $query->findOrFail($id);
    }
}
