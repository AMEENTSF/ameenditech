<?php

declare(strict_types=1);

namespace App\Http\Controllers\Research;

use App\Http\Controllers\Controller;
use App\Models\Deliverable;
use App\Models\File;
use App\Models\ResearchProject;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/** Versioned deliverables with a mandatory second-reader review. */
class DeliverableController extends Controller
{
    public function __construct(private AuditLogger $audit)
    {
    }

    /** Uploading a file under an existing title creates the next version and supersedes the previous one. */
    public function store(Request $request, ResearchProject $project): JsonResponse
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'file' => ['required', 'file', 'max:102400', 'extensions:pdf,docx,xlsx,pptx,zip,html,csv'],
        ]);

        $deliverable = DB::transaction(function () use ($project, $data, $request) {
            $version = (int) Deliverable::where('research_project_id', $project->id)->where('title', $data['title'])->max('version') + 1;
            Deliverable::where('research_project_id', $project->id)->where('title', $data['title'])->whereIn('status', ['draft', 'in_review', 'approved'])->update(['status' => 'superseded']);

            $upload = $request->file('file');
            $disk = config('filesystems.private_disk', 's3');
            $key = "research/{$project->reference}/deliverables/" . Str::uuid() . '.' . $upload->getClientOriginalExtension();
            Storage::disk($disk)->putFileAs(dirname($key), $upload, basename($key), ['visibility' => 'private']);
            $file = File::create([
                'disk' => $disk, 'path' => $key, 'original_name' => $upload->getClientOriginalName(),
                'mime_type' => $upload->getMimeType() ?? 'application/octet-stream', 'size_bytes' => $upload->getSize(),
                'sha256' => hash_file('sha256', $upload->getRealPath()), 'uploaded_by' => $request->user()->id,
            ]);

            return Deliverable::create([
                'research_project_id' => $project->id, 'title' => $data['title'], 'version' => $version,
                'file_id' => $file->id, 'status' => 'in_review', 'created_by' => $request->user()->id,
            ]);
        });

        return response()->json(['data' => $deliverable], 201);
    }

    /** The reviewer must be someone other than the author (second reader). */
    public function review(Request $request, Deliverable $deliverable): JsonResponse
    {
        $data = $request->validate(['outcome' => ['required', 'in:approved,changes_requested'], 'comments' => ['nullable', 'string']]);

        if ($deliverable->created_by === $request->user()->id) {
            throw ValidationException::withMessages(['reviewer' => 'A second reader must review this deliverable, not its author.']);
        }
        if ($deliverable->status !== 'in_review') {
            throw ValidationException::withMessages(['deliverable' => 'This version is not awaiting review.']);
        }

        DB::transaction(function () use ($deliverable, $data, $request) {
            $deliverable->qualityReviews()->create([
                'reviewer_id' => $request->user()->id, 'outcome' => $data['outcome'],
                'comments' => $data['comments'] ?? null, 'reviewed_at' => now(),
            ]);
            $deliverable->update(['status' => $data['outcome'] === 'approved' ? 'approved' : 'draft']);
            $this->audit->record('deliverable.reviewed', $deliverable, null, ['outcome' => $data['outcome']]);
        });

        return response()->json(['data' => $deliverable->refresh()]);
    }

    /** Releasing to the client is only possible after approval and once the project reached client delivery. */
    public function deliver(Request $request, Deliverable $deliverable): JsonResponse
    {
        $project = ResearchProject::findOrFail($deliverable->research_project_id);
        if ($deliverable->status !== 'approved' || ! in_array($project->stage, ['client_delivery', 'balance_payment'], true)) {
            throw ValidationException::withMessages(['deliverable' => 'Only approved deliverables can be delivered during client delivery.']);
        }

        $deliverable->update(['status' => 'delivered', 'delivered_at' => now()]);
        $this->audit->record('deliverable.delivered', $deliverable);

        return response()->json(['data' => $deliverable->refresh()]);
    }

    public function download(Request $request, Deliverable $deliverable): JsonResponse
    {
        $file = File::findOrFail($deliverable->file_id);
        $this->audit->record('deliverable.downloaded', $deliverable);

        return response()->json(['url' => Storage::disk($file->disk)->temporaryUrl($file->path, now()->addMinutes(5)), 'expires_in' => 300]);
    }
}
