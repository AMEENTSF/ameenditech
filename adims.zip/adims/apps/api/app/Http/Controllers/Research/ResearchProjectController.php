<?php

declare(strict_types=1);

namespace App\Http\Controllers\Research;

use App\Http\Controllers\Controller;
use App\Models\ProjectQuote;
use App\Models\ResearchProject;
use App\Services\ResearchWorkflowService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ResearchProjectController extends Controller
{
    public function __construct(private ResearchWorkflowService $workflow)
    {
    }

    /**
     * Record-level access: users with research.projects.view_all see everything; others only see
     * projects they manage or are allocated to. Applied to list and detail alike.
     */
    private function visible(Request $request): Builder
    {
        $user = $request->user();
        $query = ResearchProject::query();

        if (! $user->hasPermission('research.projects.view_all')) {
            $query->where(fn ($q) => $q->where('manager_id', $user->id)
                ->orWhereIn('id', fn ($s) => $s->select('research_project_id')->from('project_team_members')->where('user_id', $user->id)));
        }

        return $query;
    }

    public function index(Request $request): JsonResponse
    {
        $query = $this->visible($request)->with('clientContact:id,first_name,last_name', 'manager.contact:id,first_name,last_name')->latest('id');
        if ($request->filled('stage')) {
            $query->where('stage', $request->query('stage'));
        }
        if ($term = trim((string) $request->query('q', ''))) {
            $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $term) . '%';
            $query->where(fn ($q) => $q->where('reference', 'ilike', $like)->orWhere('title', 'ilike', $like));
        }

        return response()->json($query->paginate(min((int) $request->query('per_page', 25), 100)));
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $project = $this->visible($request)->with('clientContact', 'manager.contact', 'datasets:id,research_project_id,label,classification,created_at')->findOrFail($id);
        $project->load('tasks', 'deliverables', 'quotes');

        return response()->json(['data' => $project]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'client_contact_id' => ['required', 'integer', 'exists:contacts,id'],
            'title' => ['required', 'string', 'max:255'],
            'scope' => ['nullable', 'string'],
            'due_on' => ['nullable', 'date', 'after_or_equal:today'],
            'manager_id' => ['nullable', 'integer', 'exists:users,id'],
        ]);

        return response()->json(['data' => $this->workflow->open($data, $request->user())], 201);
    }

    /** Stage, deposit and quote values are deliberately not editable here. */
    public function update(Request $request, int $id): JsonResponse
    {
        $project = $this->visible($request)->findOrFail($id);
        $project->update($request->validate([
            'title' => ['sometimes', 'string', 'max:255'],
            'scope' => ['sometimes', 'nullable', 'string'],
            'due_on' => ['sometimes', 'nullable', 'date'],
            'manager_id' => ['sometimes', 'nullable', 'integer', 'exists:users,id'],
        ]));

        return response()->json(['data' => $project->refresh()]);
    }

    public function advance(Request $request, int $id): JsonResponse
    {
        $project = $this->visible($request)->findOrFail($id);
        $request->validate(['waive_feedback' => ['sometimes', 'boolean']]);

        return response()->json(['data' => $this->workflow->advance($project, $request->user(), $request->boolean('waive_feedback'))]);
    }

    public function quote(Request $request, int $id): JsonResponse
    {
        $project = $this->visible($request)->findOrFail($id);
        $data = $request->validate(['amount_kobo' => ['required', 'integer', 'min:1'], 'scope_summary' => ['nullable', 'string']]);

        return response()->json(['data' => $this->workflow->quote($project, $data['amount_kobo'], $data['scope_summary'] ?? null, $request->user())], 201);
    }

    public function acceptQuote(Request $request, ProjectQuote $quote): JsonResponse
    {
        $this->visible($request)->findOrFail($quote->research_project_id);

        return response()->json(['data' => $this->workflow->acceptQuote($quote, $request->user())]);
    }
}
