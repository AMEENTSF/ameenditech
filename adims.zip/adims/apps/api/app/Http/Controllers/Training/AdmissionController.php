<?php

declare(strict_types=1);

namespace App\Http\Controllers\Training;

use App\Http\Controllers\Controller;
use App\Models\Application;
use App\Models\Cohort;
use App\Models\Contact;
use App\Models\Course;
use App\Services\EnrolmentService;
use App\Services\ReferenceGenerator;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdmissionController extends Controller
{
    public function __construct(private EnrolmentService $enrolments, private ReferenceGenerator $refs)
    {
    }

    /** Public catalogue: only published courses, only public fields. */
    public function catalogue(): JsonResponse
    {
        return response()->json(['data' => Course::where('status', 'published')->orderBy('title')
            ->get(['id', 'slug', 'title', 'description', 'fee_kobo', 'duration_weeks'])]);
    }

    /** Public application form. Throttled; reuses an existing contact matched on email. */
    public function apply(Request $request): JsonResponse
    {
        $data = $request->validate([
            'course_id' => ['required', 'integer', 'exists:courses,id'],
            'first_name' => ['required', 'string', 'max:100'],
            'last_name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', 'max:255'],
            'phone' => ['required', 'string', 'max:30'],
            'statement' => ['nullable', 'string', 'max:3000'],
            'consent' => ['accepted'],
        ]);
        abort_unless(Course::whereKey($data['course_id'])->where('status', 'published')->exists(), 422, 'This course is not open for applications.');

        $application = DB::transaction(function () use ($data, $request) {
            $contact = Contact::firstOrCreate(['email' => strtolower($data['email'])], [
                'first_name' => $data['first_name'], 'last_name' => $data['last_name'], 'phone' => $data['phone'], 'category' => 'learner',
            ]);
            $contact->consents()->create(['purpose' => 'training_admission', 'status' => 'granted', 'source' => 'public_form', 'recorded_at' => now()]);

            return Application::create([
                'reference' => $this->refs->next('APP'), 'contact_id' => $contact->id, 'course_id' => $data['course_id'],
                'status' => 'submitted', 'statement' => $data['statement'] ?? null,
            ]);
        });

        return response()->json(['reference' => $application->reference, 'message' => 'Application received.'], 201);
    }

    public function decide(Request $request, Application $application): JsonResponse
    {
        $data = $request->validate([
            'decision' => ['required', 'in:admitted,waitlisted,declined,under_review'],
            'cohort_id' => ['required_if:decision,admitted', 'nullable', 'integer', 'exists:cohorts,id'],
            'note' => ['nullable', 'string', 'max:1000'],
        ]);

        if ($data['decision'] === 'admitted') {
            $application = $this->enrolments->admit($application, Cohort::findOrFail($data['cohort_id']), $request->user(), $data['note'] ?? null);
        } else {
            abort_if(in_array($application->status, ['admitted', 'withdrawn'], true), 422, 'This application can no longer be changed.');
            $application->update(['status' => $data['decision'], 'decided_by' => $request->user()->id, 'decided_at' => now(), 'decision_note' => $data['note'] ?? null]);
        }

        app(\App\Services\NotificationService::class)->send('admission.decision', $application->contact, ['reference' => $application->reference, 'decision' => str_replace('_', ' ', $application->status), 'note' => $data['note'] ?? '']);

        return response()->json(['data' => $application->refresh()]);
    }

    public function enrol(Request $request, Application $application): JsonResponse
    {
        $data = $request->validate(['instalments' => ['required', 'integer', 'between:1,6']]);

        return response()->json(['data' => $this->enrolments->enrol($application, $data['instalments'], $request->user())->load('instalments')], 201);
    }
}
