<?php

declare(strict_types=1);

namespace App\Http\Controllers\Training;

use App\Http\Controllers\Controller;
use App\Models\AttendanceRecord;
use App\Models\Certificate;
use App\Models\ClassSession;
use App\Models\Enrolment;
use App\Services\AuditLogger;
use App\Services\CertificateService;
use App\Services\EnrolmentService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class LearningController extends Controller
{
    public function __construct(private EnrolmentService $enrolments, private CertificateService $certificates, private AuditLogger $audit)
    {
    }

    /** Bulk register for one class session. Only enrolments of that session's cohort are accepted. */
    public function recordAttendance(Request $request, ClassSession $session): JsonResponse
    {
        $data = $request->validate([
            'records' => ['required', 'array', 'min:1', 'max:200'],
            'records.*.enrolment_id' => ['required', 'integer', 'distinct'],
            'records.*.status' => ['required', 'in:present,absent,late,excused'],
        ]);

        $valid = Enrolment::where('cohort_id', $session->cohort_id)->whereIn('id', array_column($data['records'], 'enrolment_id'))->pluck('id')->all();
        if (count($valid) !== count($data['records'])) {
            throw ValidationException::withMessages(['records' => 'Some learners do not belong to this cohort.']);
        }

        DB::transaction(function () use ($data, $session, $request) {
            foreach ($data['records'] as $r) {
                AttendanceRecord::updateOrCreate(
                    ['class_session_id' => $session->id, 'enrolment_id' => $r['enrolment_id']],
                    ['status' => $r['status'], 'recorded_by' => $request->user()->id, 'recorded_at' => now()],
                );
            }
            $session->update(['status' => 'held']);
        });

        return response()->json(['message' => 'Attendance recorded.']);
    }

    public function completion(Request $request, Enrolment $enrolment): JsonResponse
    {
        return response()->json($this->enrolments->evaluateCompletion($enrolment, $request->user()));
    }

    /** Certificates need a completed enrolment, which in turn needs attendance and pass mark. */
    public function issueCertificate(Request $request, Enrolment $enrolment): JsonResponse
    {
        $result = $this->enrolments->evaluateCompletion($enrolment, $request->user());
        if (! $result['passed']) {
            throw ValidationException::withMessages(['enrolment' => 'The learner has not met the completion requirements.'] );
        }

        $certificate = $this->certificates->issue($enrolment->refresh(), $request->user());
        $this->audit->record('certificate.issued', $certificate, null, ['verification_number' => $certificate->verification_number]);

        app(\App\Services\NotificationService::class)->send('certificate.issued', $enrolment->contact, ['number' => $certificate->verification_number, 'course' => $enrolment->cohort->course->title]);

        return response()->json(['data' => $certificate], 201);
    }

    public function revokeCertificate(Request $request, Certificate $certificate): JsonResponse
    {
        $request->validate(['reason' => ['required', 'string', 'max:500']]);
        abort_if($certificate->revoked_at, 422, 'Already revoked.');
        $certificate->update(['revoked_at' => now()]);
        $this->audit->record('certificate.revoked', $certificate, null, ['reason' => $request->input('reason')]);

        return response()->json(['data' => $certificate->refresh()]);
    }
}
