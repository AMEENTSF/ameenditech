<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Contact;
use App\Models\Enquiry;
use App\Models\Quotation;
use App\Services\AuditLogger;
use App\Services\NotificationService;
use App\Services\ReferenceGenerator;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class CrmController extends Controller
{
    public function __construct(private ReferenceGenerator $refs, private AuditLogger $audit, private NotificationService $notifications)
    {
    }

    /** Public enquiry form (website). Throttled; reuses an existing contact matched on email. */
    public function publicEnquiry(Request $request): JsonResponse
    {
        $data = $request->validate([
            'first_name' => ['required', 'string', 'max:100'], 'last_name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', 'max:255'], 'phone' => ['nullable', 'string', 'max:30'],
            'service_line' => ['required', 'in:research,training,digital_services,other'],
            'subject' => ['required', 'string', 'max:255'], 'message' => ['nullable', 'string', 'max:5000'],
            'consent' => ['accepted'],
        ]);

        $enquiry = DB::transaction(function () use ($data) {
            $contact = Contact::firstOrCreate(['email' => strtolower($data['email'])], [
                'first_name' => $data['first_name'], 'last_name' => $data['last_name'], 'phone' => $data['phone'] ?? null, 'category' => 'lead',
            ]);
            $contact->consents()->create(['purpose' => 'enquiry_follow_up', 'status' => 'granted', 'source' => 'public_form', 'recorded_at' => now()]);

            return Enquiry::create([
                'reference' => $this->refs->next('ENQ'), 'contact_id' => $contact->id, 'service_line' => $data['service_line'],
                'subject' => $data['subject'], 'message' => $data['message'] ?? null, 'source' => 'web', 'status' => 'new',
            ]);
        });

        return response()->json(['reference' => $enquiry->reference, 'message' => 'Thank you. We will be in touch shortly.'], 201);
    }

    public function updateEnquiryStatus(Request $request, Enquiry $enquiry): JsonResponse
    {
        $data = $request->validate(['status' => ['required', 'in:contacted,qualified,quoted,won,lost'], 'assigned_to' => ['nullable', 'integer', 'exists:users,id']]);
        abort_if($enquiry->status === 'won' || $enquiry->status === 'lost', 422, 'This enquiry is closed.');
        $enquiry->update(['status' => $data['status'], 'assigned_to' => $data['assigned_to'] ?? $enquiry->assigned_to]);

        return response()->json(['data' => $enquiry->refresh()]);
    }

    /** Lead → customer: marks the contact as a customer and closes the enquiry as won. */
    public function convert(Enquiry $enquiry): JsonResponse
    {
        DB::transaction(function () use ($enquiry) {
            $enquiry->contact()->update(['category' => 'customer']);
            $enquiry->update(['status' => 'won', 'converted_at' => now()]);
            $this->audit->record('enquiry.converted', $enquiry);
        });

        return response()->json(['data' => $enquiry->refresh()]);
    }

    public function sendQuotation(Quotation $quotation): JsonResponse
    {
        if ($quotation->status !== 'draft') {
            throw ValidationException::withMessages(['quotation' => 'Only draft quotations can be sent.']);
        }
        $quotation->update(['status' => 'sent']);
        $this->notifications->send('quotation.sent', $quotation->contact, ['number' => $quotation->number, 'title' => $quotation->title]);

        return response()->json(['data' => $quotation->refresh()]);
    }

    /** Staff-approved quotation revision: a new revision supersedes the old one by number + revision. */
    public function reviseQuotation(Request $request, Quotation $quotation): JsonResponse
    {
        $data = $request->validate(['total_kobo' => ['required', 'integer', 'min:1'], 'lines' => ['nullable', 'array']]);
        $new = DB::transaction(function () use ($quotation, $data) {
            $quotation->update(['status' => 'expired']);

            return Quotation::create([
                'number' => $this->refs->next('QUO'), 'contact_id' => $quotation->contact_id, 'enquiry_id' => $quotation->enquiry_id, 'service_line' => $quotation->service_line,
                'title' => $quotation->title, 'total_kobo' => $data['total_kobo'], 'lines' => $data['lines'] ?? $quotation->lines, 'status' => 'draft',
                'revision' => $quotation->revision + 1, 'valid_until' => $quotation->valid_until, 'created_by' => auth()->id(),
            ]);
        });

        return response()->json(['data' => $new], 201);
    }
}
