<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\ApprovalRequest;
use App\Services\ApprovalService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ApprovalController extends Controller
{
    /** Permission an approver needs for each kind of subject. Checked server-side per request. */
    private const SUBJECT_PERMISSION = [
        'expense' => 'finance.expenses.approve',
        'supplier_invoice' => 'finance.invoices.approve',
        'purchase_order' => 'procurement.requests.approve',
        'purchase_request' => 'procurement.requests.approve',
        'payment' => 'finance.payments.verify',
    ];

    public function __construct(private ApprovalService $approvals)
    {
    }

    /** Pending items the current user is allowed to decide and has not already decided. */
    public function pending(Request $request): JsonResponse
    {
        $user = $request->user();
        $allowed = collect(self::SUBJECT_PERMISSION)->filter(fn ($perm) => $user->hasPermission($perm))->keys();

        $items = ApprovalRequest::with('decisions')
            ->where('status', 'pending')
            ->whereIn('subject_type', $allowed)
            ->where('requested_by', '!=', $user->id)
            ->whereDoesntHave('decisions', fn ($q) => $q->where('approver_id', $user->id))
            ->latest()->limit(100)->get();

        return response()->json(['data' => $items]);
    }

    public function approve(Request $request, ApprovalRequest $approvalRequest): JsonResponse
    {
        $this->authoriseDecision($request, $approvalRequest);
        $data = $request->validate(['comment' => ['nullable', 'string', 'max:1000']]);

        $result = $this->approvals->approve($approvalRequest, $request->user(), $data['comment'] ?? null);

        return response()->json([
            'status' => $result->status->value,
            'approvals_recorded' => $result->decisions()->where('decision', 'approved')->count(),
            'approvals_required' => $result->required_approvals,
        ]);
    }

    public function reject(Request $request, ApprovalRequest $approvalRequest): JsonResponse
    {
        $this->authoriseDecision($request, $approvalRequest);
        $data = $request->validate(['comment' => ['required', 'string', 'max:1000']]);

        $result = $this->approvals->reject($approvalRequest, $request->user(), $data['comment']);

        return response()->json(['status' => $result->status->value]);
    }

    private function authoriseDecision(Request $request, ApprovalRequest $approvalRequest): void
    {
        $permission = self::SUBJECT_PERMISSION[$approvalRequest->subject_type] ?? null;

        abort_unless($permission && $request->user()->hasPermission($permission), 403, 'You cannot decide this kind of approval.');
    }
}
