<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Services\CertificateService;
use Illuminate\Http\JsonResponse;

class CertificateVerificationController extends Controller
{
    public function __invoke(string $number, CertificateService $certificates): JsonResponse
    {
        $result = $certificates->publicVerification($number);

        if ($result === null) {
            return response()->json(['valid' => false, 'message' => 'Certificate not found.'], 404);
        }

        return response()->json($result);
    }
}
