<?php

declare(strict_types=1);

namespace App\Providers;

use App\Events\ApprovalResolved;
use App\Listeners\ApplyApprovalOutcome;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Database\Eloquent\Relations\Relation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        Relation::morphMap([
            'expense' => \App\Models\Expense::class,
            'purchase_order' => \App\Models\PurchaseOrder::class,
            'purchase_request' => \App\Models\PurchaseRequest::class,
            'supplier_invoice' => \App\Models\SupplierInvoice::class,
            'payment' => \App\Models\Payment::class,
            'research_project' => \App\Models\ResearchProject::class,
            'service_project' => \App\Models\ServiceProject::class,
            'enrolment' => \App\Models\Enrolment::class,
            'user' => \App\Models\User::class,
        ]);

        Event::listen(ApprovalResolved::class, ApplyApprovalOutcome::class);

        RateLimiter::for('login', fn (Request $r) => [
            Limit::perMinute(5)->by(strtolower((string) $r->input('email')) . '|' . $r->ip()),
            Limit::perMinute(30)->by($r->ip()),
        ]);
        RateLimiter::for('api', fn (Request $r) => Limit::perMinute(120)->by($r->user()?->id ?: $r->ip()));
    }
}
