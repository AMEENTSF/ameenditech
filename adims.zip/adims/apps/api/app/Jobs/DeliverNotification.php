<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Models\Notification;
use App\Support\Channels\ChannelManager;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Throwable;

class DeliverNotification implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;

    public function __construct(public int $notificationId)
    {
    }

    public function backoff(): array
    {
        return [30, 120];
    }

    public function handle(ChannelManager $channels): void
    {
        $notification = Notification::find($this->notificationId);
        if (! $notification || $notification->status === 'delivered') {
            return;
        }

        $messageId = $channels->driver($notification->channel)->send($notification);
        $notification->update(['status' => 'sent', 'provider_message_id' => $messageId, 'sent_at' => now()]);
    }

    public function failed(Throwable $e): void
    {
        Notification::whereKey($this->notificationId)->update(['status' => 'failed', 'failure_reason' => substr($e->getMessage(), 0, 500)]);
    }
}
