<?php

declare(strict_types=1);

namespace App\Enums;

enum ResearchStage: string
{
    case Enquiry = 'enquiry';
    case Scope = 'scope';
    case Quotation = 'quotation';
    case ClientAcceptance = 'client_acceptance';
    case Deposit = 'deposit';
    case Execution = 'execution';
    case QualityReview = 'quality_review';
    case ClientDelivery = 'client_delivery';
    case BalancePayment = 'balance_payment';
    case Feedback = 'feedback';
    case Closed = 'closed';

    /** Stages in the order the business process requires. */
    public static function order(): array
    {
        return array_map(fn (self $s) => $s->value, self::cases());
    }

    public function next(): ?self
    {
        $cases = self::cases();
        $i = array_search($this, $cases, true);

        return $cases[$i + 1] ?? null;
    }
}
