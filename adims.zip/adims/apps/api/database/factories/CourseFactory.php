<?php

namespace Database\Factories;

use App\Models\Course;
use Illuminate\Database\Eloquent\Factories\Factory;

/** @extends Factory<Course> */
class CourseFactory extends Factory
{
    protected $model = Course::class;

    public function definition(): array
    {
        $title = fake()->unique()->words(3, true);

        return ['slug' => str($title)->slug()->toString(), 'title' => ucfirst($title), 'description' => fake()->sentence(), 'fee_kobo' => 5_000_000, 'duration_weeks' => 8, 'status' => 'published'];
    }
}
