<?php

namespace Database\Seeders;

use App\Models\NotificationTemplate;
use Illuminate\Database\Seeder;

class NotificationTemplateSeeder extends Seeder
{
    /** code => [subject, body]. Placeholders use {{ name }}; each template is created for in_app and email. */
    private const TEMPLATES = [
        'enquiry.new' => ['New enquiry received', 'A new enquiry {{ reference }} has been received: {{ subject }}.'],
        'quotation.sent' => ['Your quotation {{ number }}', 'Quotation {{ number }} for "{{ title }}" is ready for your review.'],
        'admission.decision' => ['Your application {{ reference }}', 'Your application has been updated: {{ decision }}. {{ note }}'],
        'payment.confirmed' => ['Payment confirmed', 'We have verified your payment {{ reference }}. Thank you.'],
        'payment.outstanding' => ['Outstanding payment', 'Invoice {{ invoice }} has an outstanding balance of NGN {{ balance }}.'],
        'class.reminder' => ['Class reminder', 'Reminder: {{ course }} holds {{ time }}.'],
        'attendance.alert' => ['Attendance alert', 'Your attendance on {{ course }} is {{ percent }}%, below the required level.'],
        'assessment.result' => ['Assessment result', 'Your result for {{ assessment }} is available.'],
        'certificate.issued' => ['Your certificate', 'Your certificate {{ number }} for {{ course }} has been issued. Verify it at the public verification page.'],
        'project.milestone' => ['Project milestone', 'Milestone "{{ milestone }}" on {{ project }} needs your attention.'],
        'approval.requested' => ['Approval requested', '{{ subject }} of NGN {{ amount }} is waiting for your approval.'],
        'ticket.updated' => ['Support ticket {{ reference }}', 'Your ticket status is now {{ status }}.'],
        'care_plan.renewal_due' => ['Care plan renewal', 'Your {{ plan }} care plan renews on {{ date }}. An invoice has been issued.'],
    ];

    public function run(): void
    {
        foreach (self::TEMPLATES as $code => [$subject, $body]) {
            foreach (['in_app', 'email'] as $channel) {
                NotificationTemplate::updateOrCreate(['code' => $code, 'channel' => $channel], ['subject' => $subject, 'body' => $body, 'active' => true]);
            }
        }
    }
}
