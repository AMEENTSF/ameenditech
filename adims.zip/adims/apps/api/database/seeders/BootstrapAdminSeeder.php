<?php

namespace Database\Seeders;

use App\Models\Contact;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;

/**
 * Creates the first super administrator ONLY when no users exist, from ADMIN_EMAIL / ADMIN_PASSWORD.
 * No default credentials are shipped. MFA enrolment is forced at first login (privileged role).
 */
class BootstrapAdminSeeder extends Seeder
{
    public function run(): void
    {
        if (User::exists()) {
            return;
        }

        $email = env('ADMIN_EMAIL');
        $password = env('ADMIN_PASSWORD');

        if (! $email || ! $password || strlen($password) < 12) {
            $this->command?->warn('Skipped: set ADMIN_EMAIL and a 12+ character ADMIN_PASSWORD to create the first administrator.');

            return;
        }

        $contact = Contact::create(['first_name' => 'System', 'last_name' => 'Administrator', 'email' => $email, 'category' => 'staff']);
        $user = User::create(['contact_id' => $contact->id, 'email' => $email, 'password' => $password, 'email_verified_at' => now(), 'password_changed_at' => now()]);
        $user->roles()->attach(Role::where('slug', 'super-administrator')->firstOrFail()->id);
    }
}
