<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            PermissionSeeder::class,
            RoleSeeder::class,
            CourseSeeder::class,
            ChartOfAccountsSeeder::class,
            NotificationTemplateSeeder::class,
            LeaveTypeSeeder::class,
            BootstrapAdminSeeder::class,
        ]);
    }
}
