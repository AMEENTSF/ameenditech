<?php

namespace Database\Seeders;

use App\Models\Account;
use App\Models\AccountCategory;
use Illuminate\Database\Seeder;

/** Minimal chart used by automatic postings. Finance can extend it from the UI. */
class ChartOfAccountsSeeder extends Seeder
{
    private const CHART = [
        'asset' => ['Assets', [['1010', 'Bank and cash'], ['1200', 'Accounts receivable']]],
        'liability' => ['Liabilities', [['2100', 'Accounts payable']]],
        'equity' => ['Equity', [['3000', 'Owners equity']]],
        'income' => ['Income', [['4000', 'Service revenue'], ['4100', 'Training revenue'], ['4200', 'Research revenue']]],
        'expense' => ['Expenses', [['5000', 'General expenses'], ['5100', 'Salaries and wages'], ['5200', 'Rent and utilities'], ['5300', 'Software and internet'], ['5400', 'Marketing']]],
    ];

    public function run(): void
    {
        foreach (self::CHART as $kind => [$name, $accounts]) {
            $category = AccountCategory::updateOrCreate(['name' => $name], ['kind' => $kind]);
            foreach ($accounts as [$code, $label]) {
                Account::updateOrCreate(['code' => $code], ['name' => $label, 'account_category_id' => $category->id, 'active' => true]);
            }
        }
    }
}
