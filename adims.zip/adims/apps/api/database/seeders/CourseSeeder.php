<?php

namespace Database\Seeders;

use App\Models\Course;
use Illuminate\Database\Seeder;

/**
 * Catalogue entries only. Fees are placeholders (0) in draft status until the
 * Training Manager sets real fees in the admin interface; no invented prices.
 */
class CourseSeeder extends Seeder
{
    public function run(): void
    {
        $courses = [
            ['computer-basics-office-tools', 'Computer Basics and Office Tools'],
            ['data-analysis-excel-spss', 'Data Analysis with Excel and SPSS'],
            ['web-design-digital-marketing', 'Web Design and Digital Marketing'],
            ['data-science-basics-python', 'Data Science Basics with Python'],
        ];

        foreach ($courses as [$slug, $title]) {
            Course::firstOrCreate(
                ['slug' => $slug],
                ['title' => $title, 'fee_kobo' => 0, 'duration_weeks' => 0, 'status' => 'draft'],
            );
        }
    }
}
