<?php

namespace Database\Seeders;

use App\Models\Permission;
use Illuminate\Database\Seeder;

class PermissionSeeder extends Seeder
{
    /** module => [resource => [actions]] */
    public const MAP = [
        'admin' => ['users' => ['view', 'manage'], 'roles' => ['manage'], 'audit' => ['view'], 'settings' => ['manage']],
        'dashboard' => ['executive' => ['view']],
        'crm' => ['contacts' => ['view', 'create', 'update', 'delete'], 'enquiries' => ['view', 'create', 'update'], 'quotations' => ['view', 'create', 'approve']],
        'research' => ['projects' => ['view', 'create', 'update', 'assign', 'close'], 'datasets' => ['view', 'upload', 'download'], 'deliverables' => ['view', 'create', 'review', 'deliver']],
        'training' => ['courses' => ['view', 'manage'], 'applications' => ['view', 'decide'], 'enrolments' => ['view', 'manage'], 'attendance' => ['view', 'record'], 'assessments' => ['view', 'grade'], 'certificates' => ['view', 'issue', 'revoke']],
        'services' => ['projects' => ['view', 'create', 'update'], 'tickets' => ['view', 'create', 'update'], 'care_plans' => ['view', 'manage']],
        'finance' => ['invoices' => ['view', 'create', 'update', 'approve', 'export'], 'payments' => ['view', 'record', 'verify'], 'expenses' => ['view', 'create', 'approve'], 'reports' => ['view', 'export'], 'bank' => ['view', 'reconcile']],
        'hr' => ['staff' => ['view', 'manage'], 'leave' => ['view', 'create', 'approve'], 'reviews' => ['view', 'manage']],
        'procurement' => ['requests' => ['view', 'create', 'approve'], 'orders' => ['view', 'create'], 'assets' => ['view', 'manage']],
        'governance' => ['documents' => ['view', 'manage'], 'risks' => ['view', 'manage'], 'incidents' => ['view', 'create']],
    ];

    /** Permissions that are not plain view/create/update/delete on a registry resource. */
    public const EXTRA = [
        'research' => ['projects' => ['view_all']],
        'finance' => ['invoices' => ['void']],
    ];

    /** Merge the hand-written map, the extras and the CRUD permissions of every generic resource. */
    public static function fullMap(): array
    {
        $map = array_merge_recursive(self::MAP, self::EXTRA);

        foreach (config('resources', []) as $cfg) {
            $actions = $cfg['readonly'] ? ['view'] : ['view', 'create', 'update', 'delete'];
            $map[$cfg['module']][$cfg['resource']] = array_values(array_unique(array_merge($map[$cfg['module']][$cfg['resource']] ?? [], $actions)));
        }

        return $map;
    }

    public function run(): void
    {
        // Two-segment permissions for the reporting module.
        foreach (['reports.view', 'reports.export'] as $slug) {
            Permission::updateOrCreate(['slug' => $slug], ['module' => 'reports']);
        }

        foreach (self::fullMap() as $module => $resources) {
            foreach ($resources as $resource => $actions) {
                foreach (array_unique($actions) as $action) {
                    Permission::updateOrCreate(
                        ['slug' => "{$module}.{$resource}.{$action}"],
                        ['module' => $module],
                    );
                }
            }
        }
    }
}
