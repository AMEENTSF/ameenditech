<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\Role;
use Illuminate\Database\Seeder;

class RoleSeeder extends Seeder
{
    /**
     * slug => [name, requires_mfa, permission patterns]
     * A pattern ending in ".*" grants every permission under that prefix.
     * These are starting defaults; administrators can edit them at runtime.
     */
    private const ROLES = [
        'super-administrator' => ['Super Administrator', true, ['*']],
        'managing-director' => ['Managing Director', true, ['dashboard.*', 'finance.*', 'reports.*', 'research.projects.view', 'research.projects.view_all', 'training.courses.view', 'training.certificates.view', 'services.projects.view', 'crm.contacts.view', 'hr.staff.view', 'governance.*']],
        'director' => ['Director / Board-level User', false, ['dashboard.executive.view', 'finance.reports.view', 'reports.view', 'governance.documents.view', 'governance.risks.view']],
        'operations-manager' => ['Operations Manager', false, ['dashboard.executive.view', 'reports.view', 'research.projects.*', 'services.*', 'procurement.*', 'training.courses.view', 'crm.contacts.view', 'hr.leave.approve', 'hr.leave.create']],
        'research-manager' => ['Research Manager', false, ['research.*', 'reports.view', 'crm.contacts.view', 'crm.enquiries.*', 'crm.quotations.*']],
        'research-analyst' => ['Research Analyst', false, ['research.projects.view', 'research.datasets.view', 'research.datasets.upload', 'research.deliverables.view', 'research.deliverables.create']],
        'field-supervisor' => ['Field Supervisor', false, ['research.projects.view', 'research.datasets.view']],
        'enumerator' => ['Enumerator', false, []],
        'training-manager' => ['Training Manager', false, ['training.*', 'reports.view', 'crm.contacts.view']],
        'instructor' => ['Instructor', false, ['training.courses.view', 'training.attendance.*', 'training.assessments.*']],
        'learner' => ['Learner', false, []],
        'digital-services-manager' => ['Digital Services Manager', false, ['services.*', 'reports.view', 'crm.contacts.view', 'crm.enquiries.*', 'crm.quotations.*']],
        'designer-developer' => ['Designer / Developer', false, ['services.projects.view', 'services.projects.update', 'services.tickets.*']],
        'finance-manager' => ['Finance Manager', true, ['finance.*', 'reports.*', 'dashboard.executive.view', 'procurement.requests.approve']],
        'accountant' => ['Accountant', true, ['finance.invoices.*', 'finance.payments.*', 'finance.expenses.view', 'finance.expenses.create', 'finance.reports.*', 'finance.bank.*', 'reports.view', 'reports.export']],
        'hr-officer' => ['Human Resources Officer', false, ['hr.*', 'reports.view']],
        'procurement-officer' => ['Procurement Officer', false, ['procurement.*']],
        'administrative-officer' => ['Administrative Officer', false, ['crm.*', 'governance.documents.view', 'hr.leave.create']],
        'client' => ['Client', false, []],
        'external-partner' => ['External Partner', false, []],
    ];

    public function run(): void
    {
        $all = Permission::pluck('id', 'slug');

        foreach (self::ROLES as $slug => [$name, $mfa, $patterns]) {
            $role = Role::updateOrCreate(
                ['slug' => $slug],
                ['name' => $name, 'requires_mfa' => $mfa, 'is_system' => true],
            );

            $ids = [];
            foreach ($patterns as $pattern) {
                foreach ($all as $permSlug => $id) {
                    if ($pattern === '*' || fnmatch($pattern, $permSlug)) {
                        $ids[$id] = $id;
                    }
                }
            }

            $role->permissions()->sync(array_values($ids));
        }
    }
}
