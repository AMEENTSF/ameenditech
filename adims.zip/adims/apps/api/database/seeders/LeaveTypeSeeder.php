<?php

namespace Database\Seeders;

use App\Models\LeaveType;
use Illuminate\Database\Seeder;

class LeaveTypeSeeder extends Seeder
{
    public function run(): void
    {
        foreach ([['Annual leave', 20, true], ['Sick leave', 10, true], ['Maternity leave', 90, true], ['Paternity leave', 10, true], ['Unpaid leave', 30, false]] as [$name, $days, $paid]) {
            LeaveType::updateOrCreate(['name' => $name], ['default_days' => $days, 'paid' => $paid]);
        }
    }
}
