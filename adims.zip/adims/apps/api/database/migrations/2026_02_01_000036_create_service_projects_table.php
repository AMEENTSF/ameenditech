<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('service_projects', function (Blueprint $table) {
            $table->id();
            $table->string('reference')->unique();
            $table->foreignId('contact_id')->constrained('contacts')->restrictOnDelete();
            $table->foreignId('service_catalogue_id')->nullable()->constrained('service_catalogue')->nullOnDelete();
            $table->foreignId('quotation_id')->nullable()->constrained('quotations')->nullOnDelete();
            $table->string('title');
            $table->string('status')->default('draft')->index();
            $table->foreignId('project_manager_id')->nullable()->constrained('users')->nullOnDelete();
            $table->bigInteger('agreed_kobo')->nullable();
            $table->date('starts_on')->nullable();
            $table->date('due_on')->nullable()->index();
            $table->timestamp('agreement_accepted_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('service_projects');
    }
};
