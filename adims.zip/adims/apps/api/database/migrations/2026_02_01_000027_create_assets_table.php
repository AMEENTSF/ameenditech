<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('assets', function (Blueprint $table) {
            $table->id();
            $table->string('tag')->unique();
            $table->string('name');
            $table->string('category')->index();
            $table->string('serial_number')->nullable();
            $table->date('purchased_on')->nullable();
            $table->bigInteger('cost_kobo')->nullable();
            $table->string('condition')->default('good');
            $table->string('status')->default('available')->index();
            $table->foreignId('assignee_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('location')->nullable();
            $table->timestamp('disposed_at')->nullable();
            $table->text('disposal_reason')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('assets');
    }
};
