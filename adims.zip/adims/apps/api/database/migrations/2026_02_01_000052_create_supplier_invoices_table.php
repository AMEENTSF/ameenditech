<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('supplier_invoices', function (Blueprint $table) {
            $table->id();
            $table->string('number');
            $table->foreignId('supplier_id')->constrained('suppliers')->restrictOnDelete();
            $table->bigInteger('total_kobo');
            $table->bigInteger('paid_kobo')->default(0);
            $table->string('status')->default('received')->index();
            $table->date('received_on');
            $table->date('due_on')->nullable()->index();
            $table->foreignId('file_id')->nullable()->constrained('files')->nullOnDelete();
            $table->timestamps();
            $table->unique(['supplier_id', 'number']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('supplier_invoices');
    }
};
