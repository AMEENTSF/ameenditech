<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('milestones', function (Blueprint $table) {
            $table->id();
            $table->foreignId('service_project_id')->constrained('service_projects')->cascadeOnDelete();
            $table->string('title');
            $table->date('due_on')->nullable();
            $table->bigInteger('amount_kobo')->nullable();
            $table->string('status')->default('pending')->index();
            $table->foreignId('approved_by_contact_id')->nullable()->constrained('contacts')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('milestones');
    }
};
