<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('invoices', function (Blueprint $table) {
            $table->id();
            $table->string('number')->unique();
            $table->foreignId('contact_id')->constrained()->restrictOnDelete();
            $table->nullableMorphs('billable'); // research project, service project, enrolment
            $table->string('status')->default('draft')->index(); // draft, issued, partially_paid, paid, void
            $table->bigInteger('total_kobo');
            $table->bigInteger('paid_kobo')->default(0);
            $table->date('issued_on')->nullable();
            $table->date('due_on')->nullable()->index();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('invoice_lines', function (Blueprint $table) {
            $table->id();
            $table->foreignId('invoice_id')->constrained()->cascadeOnDelete();
            $table->string('description');
            $table->unsignedInteger('quantity')->default(1);
            $table->bigInteger('unit_price_kobo');
            $table->bigInteger('line_total_kobo');
        });

        // A payment is only "verified" after staff verification or gateway confirmation.
        // An uploaded receipt is stored as a file and leaves the payment in 'pending_verification'.
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->string('reference')->unique();
            $table->foreignId('contact_id')->constrained()->restrictOnDelete();
            $table->bigInteger('amount_kobo');
            $table->string('method'); // bank_transfer, gateway, cash
            $table->string('status')->default('pending_verification')->index(); // pending_verification, verified, rejected
            $table->string('gateway_reference')->nullable()->unique();
            $table->foreignId('receipt_file_id')->nullable()->constrained('files')->nullOnDelete();
            $table->foreignId('verified_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('verified_at')->nullable();
            $table->timestamps();
        });

        Schema::create('payment_allocations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('payment_id')->constrained()->restrictOnDelete();
            $table->foreignId('invoice_id')->constrained()->restrictOnDelete();
            $table->bigInteger('amount_kobo');
            $table->timestamps();
            $table->unique(['payment_id', 'invoice_id']);
        });

        Schema::create('expenses', function (Blueprint $table) {
            $table->id();
            $table->string('reference')->unique();
            $table->foreignId('requested_by')->constrained('users')->restrictOnDelete();
            $table->string('description');
            $table->bigInteger('amount_kobo');
            $table->string('status')->default('pending_approval')->index();
            $table->timestamps();
        });

        Schema::create('approval_requests', function (Blueprint $table) {
            $table->id();
            $table->morphs('subject'); // expense, payment, purchase order, supplier invoice
            $table->foreignId('requested_by')->constrained('users')->restrictOnDelete();
            $table->bigInteger('amount_kobo');
            $table->unsignedSmallInteger('required_approvals');
            $table->string('status')->default('pending')->index();
            $table->timestamp('resolved_at')->nullable();
            $table->timestamps();
        });

        Schema::create('approval_decisions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('approval_request_id')->constrained()->cascadeOnDelete();
            $table->foreignId('approver_id')->constrained('users')->restrictOnDelete();
            $table->string('decision'); // approved | rejected
            $table->text('comment')->nullable();
            $table->timestamp('decided_at')->useCurrent();
            // One decision per approver per request, enforced by the database.
            $table->unique(['approval_request_id', 'approver_id']);
        });

        if (DB::getDriverName() === 'pgsql') {
            DB::statement('ALTER TABLE invoices ADD CONSTRAINT invoices_paid_within_total CHECK (paid_kobo >= 0 AND paid_kobo <= total_kobo)');
            DB::statement('ALTER TABLE payment_allocations ADD CONSTRAINT allocation_positive CHECK (amount_kobo > 0)');
            DB::statement('ALTER TABLE payments ADD CONSTRAINT payment_positive CHECK (amount_kobo > 0)');
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('approval_decisions');
        Schema::dropIfExists('approval_requests');
        Schema::dropIfExists('expenses');
        Schema::dropIfExists('payment_allocations');
        Schema::dropIfExists('payments');
        Schema::dropIfExists('invoice_lines');
        Schema::dropIfExists('invoices');
    }
};
