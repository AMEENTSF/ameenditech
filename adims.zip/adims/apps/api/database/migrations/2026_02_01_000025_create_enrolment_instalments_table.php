<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('enrolment_instalments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('enrolment_id')->constrained('enrolments')->cascadeOnDelete();
            $table->foreignId('invoice_id')->nullable()->constrained('invoices')->nullOnDelete();
            $table->unsignedInteger('sequence');
            $table->bigInteger('amount_kobo');
            $table->date('due_on')->index();
            $table->string('status')->default('pending');
            $table->timestamps();
            $table->unique(['enrolment_id', 'sequence']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('enrolment_instalments');
    }
};
