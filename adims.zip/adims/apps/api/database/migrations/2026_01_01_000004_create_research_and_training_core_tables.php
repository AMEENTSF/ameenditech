<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('research_projects', function (Blueprint $table) {
            $table->id();
            $table->string('reference')->unique(); // ADM-RES-YYYY-NNNN
            $table->foreignId('client_contact_id')->constrained('contacts')->restrictOnDelete();
            $table->string('title');
            $table->text('scope')->nullable();
            $table->string('stage')->default('enquiry')->index();
            $table->bigInteger('quoted_kobo')->nullable();
            $table->unsignedSmallInteger('deposit_basis_points')->default(5000);
            $table->bigInteger('deposit_kobo')->nullable();
            $table->foreignId('manager_id')->nullable()->constrained('users')->nullOnDelete();
            $table->date('due_on')->nullable()->index();
            $table->timestamp('closed_at')->nullable();
            $table->timestamps();
        });

        Schema::create('project_reference_counters', function (Blueprint $table) {
            $table->unsignedSmallInteger('year')->primary();
            $table->unsignedInteger('last_number')->default(0);
        });

        Schema::create('datasets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('research_project_id')->constrained()->cascadeOnDelete();
            $table->foreignId('file_id')->constrained()->restrictOnDelete();
            $table->string('label');
            $table->string('classification')->default('confidential');
            $table->timestamps();
        });

        Schema::create('courses', function (Blueprint $table) {
            $table->id();
            $table->string('slug')->unique();
            $table->string('title');
            $table->text('description')->nullable();
            $table->bigInteger('fee_kobo');
            $table->unsignedSmallInteger('duration_weeks');
            $table->string('status')->default('draft')->index(); // draft, published, archived
            $table->timestamps();
        });

        Schema::create('cohorts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('course_id')->constrained()->restrictOnDelete();
            $table->string('name');
            $table->date('starts_on');
            $table->date('ends_on')->nullable();
            $table->unsignedSmallInteger('capacity')->nullable();
            $table->timestamps();
        });

        Schema::create('enrolments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cohort_id')->constrained()->restrictOnDelete();
            $table->foreignId('contact_id')->constrained()->restrictOnDelete();
            $table->string('status')->default('enrolled')->index();
            $table->timestamps();
            $table->unique(['cohort_id', 'contact_id']);
        });

        Schema::create('certificates', function (Blueprint $table) {
            $table->id();
            $table->foreignId('enrolment_id')->unique()->constrained()->restrictOnDelete();
            $table->string('verification_number')->unique();
            $table->timestamp('issued_at');
            $table->foreignId('issued_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('revoked_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('certificates');
        Schema::dropIfExists('enrolments');
        Schema::dropIfExists('cohorts');
        Schema::dropIfExists('courses');
        Schema::dropIfExists('datasets');
        Schema::dropIfExists('project_reference_counters');
        Schema::dropIfExists('research_projects');
    }
};
