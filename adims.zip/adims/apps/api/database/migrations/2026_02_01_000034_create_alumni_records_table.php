<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('alumni_records', function (Blueprint $table) {
            $table->id();
            $table->foreignId('contact_id')->constrained('contacts')->restrictOnDelete()->unique();
            $table->foreignId('enrolment_id')->nullable()->constrained('enrolments')->nullOnDelete();
            $table->string('current_employer')->nullable();
            $table->string('current_role')->nullable();
            $table->boolean('open_to_mentoring')->default(false);
            $table->boolean('consent_to_contact')->default(false);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('alumni_records');
    }
};
