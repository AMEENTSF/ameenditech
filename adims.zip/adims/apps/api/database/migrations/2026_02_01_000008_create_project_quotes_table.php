<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('project_quotes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('research_project_id')->constrained('research_projects')->cascadeOnDelete();
            $table->unsignedInteger('revision')->default(1);
            $table->bigInteger('amount_kobo');
            $table->text('scope_summary')->nullable();
            $table->string('status')->default('draft')->index();
            $table->timestamp('accepted_at')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->unique(['research_project_id', 'revision']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('project_quotes');
    }
};
