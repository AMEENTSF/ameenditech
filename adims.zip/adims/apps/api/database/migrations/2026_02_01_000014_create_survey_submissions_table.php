<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('survey_submissions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('field_assignment_id')->constrained('field_assignments')->cascadeOnDelete();
            $table->string('external_id')->nullable()->unique();
            $table->json('payload')->nullable();
            $table->string('status')->default('received')->index();
            $table->timestamp('collected_at')->nullable();
            $table->timestamp('synced_at')->nullable();
            $table->decimal('gps_accuracy', 6, 2)->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('survey_submissions');
    }
};
