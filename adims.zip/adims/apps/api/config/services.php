<?php

return [
    'paystack' => [
        // Webhook signature secret. Without it the webhook endpoint rejects every request.
        'secret' => env('PAYSTACK_SECRET_KEY'),
    ],
];
