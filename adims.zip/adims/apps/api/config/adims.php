<?php

return [
    'currency' => 'NGN',

    'finance' => [
        // ₦100,000 expressed in kobo. Transactions strictly above this need two approvals.
        'dual_approval_threshold_kobo' => (int) env('FINANCE_DUAL_APPROVAL_THRESHOLD_KOBO', 10_000_000),
        'required_approvals_above_threshold' => 2,
    ],

    // Chart-of-accounts codes used by automatic postings. Override in system_settings if the chart differs.
    'accounts' => [
        'bank' => '1010',
        'receivable' => '1200',
        'payable' => '2100',
        'revenue' => '4000',
        'general_expense' => '5000',
    ],

    'notifications' => [
        // Replace the log driver with a provider adapter implementing ChannelDriver (e.g. Termii for SMS).
        'drivers' => [
            'email' => \App\Support\Channels\MailDriver::class,
            'sms' => \App\Support\Channels\LogDriver::class,
            'whatsapp' => \App\Support\Channels\LogDriver::class,
            'push' => \App\Support\Channels\LogDriver::class,
        ],
    ],

    'research' => [
        // Basis points: 5000 = 50%.
        'default_deposit_basis_points' => (int) env('RESEARCH_DEFAULT_DEPOSIT_PERCENT', 50) * 100,
        'reference_prefix' => 'ADM-RES',
    ],

    'privileged_roles' => [
        'super-administrator',
        'managing-director',
        'finance-manager',
        'accountant',
    ],
];
