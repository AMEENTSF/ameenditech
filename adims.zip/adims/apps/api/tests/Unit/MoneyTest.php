<?php

namespace Tests\Unit;

use App\Support\Money;
use PHPUnit\Framework\TestCase;

class MoneyTest extends TestCase
{
    public function test_parses_naira_without_float_error(): void
    {
        $this->assertSame(10, Money::fromNairaString('0.10')->kobo);
        $this->assertSame(10_000_000, Money::fromNairaString('100000')->kobo);
        $this->assertSame(150_050, Money::fromNairaString('1500.50')->kobo);
    }

    public function test_rejects_invalid_amounts(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        Money::fromNairaString('12.345');
    }

    public function test_fifty_percent_deposit(): void
    {
        $this->assertSame(
            25_000_000,
            Money::fromKobo(50_000_000)->percentOfBasisPoints(5000)->kobo
        );
    }

    public function test_formats_naira(): void
    {
        $this->assertSame('₦1,500.05', Money::fromKobo(150_005)->format());
    }
}
