<?php

namespace Tests\Unit;

use App\Support\ReportExporter;
use PHPUnit\Framework\TestCase;

class MoneyRulesTest extends TestCase
{
    public function test_report_cells_block_formula_injection(): void
    {
        $x = new ReportExporter();

        $this->assertSame("'=HYPERLINK(\"http://evil\")", $x->safe('=HYPERLINK("http://evil")'));
        $this->assertSame("'+1", $x->safe('+1'));
        $this->assertSame('Normal', $x->safe('Normal'));
    }

    public function test_kobo_cells_format_without_floats(): void
    {
        $x = new ReportExporter();

        $this->assertSame('1,500.05', $x->cell('kobo', 150005));
        $this->assertSame('-0.99', $x->cell('kobo', -99));
        $this->assertSame('0.00', $x->cell('kobo', 0));
    }
}
