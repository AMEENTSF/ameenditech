<?php

namespace Tests\Feature;

use App\Models\Contact;
use App\Models\Invoice;
use App\Models\Payment;
use App\Services\PaymentService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Validation\ValidationException;
use Tests\TestCase;

class PaymentVerificationTest extends TestCase
{
    use RefreshDatabase;

    private function claim(int $kobo): Payment
    {
        $contact = Contact::create(['first_name' => 'P', 'last_name' => 'Q']);

        return app(PaymentService::class)->recordClaim(['reference' => 'PAY-' . uniqid(), 'contact_id' => $contact->id, 'amount_kobo' => $kobo, 'method' => 'bank_transfer']);
    }

    public function test_an_uploaded_receipt_claim_is_not_a_payment(): void
    {
        $payment = $this->claim(5_000_000);

        $this->assertSame('pending_verification', $payment->status);
        $this->expectException(ValidationException::class);
        $invoice = Invoice::create(['number' => 'INV-1', 'contact_id' => $payment->contact_id, 'status' => 'issued', 'total_kobo' => 5_000_000]);
        app(PaymentService::class)->allocate($payment, $invoice, \App\Support\Money::fromKobo(5_000_000));
    }

    public function test_small_payment_is_verified_by_one_user(): void
    {
        $result = app(PaymentService::class)->verify($this->claim(5_000_000), $this->userWith());

        $this->assertTrue($result['verified']);
    }

    public function test_large_payment_needs_two_distinct_verifiers(): void
    {
        $payment = $this->claim(20_000_000);
        $first = $this->userWith();
        $second = $this->userWith();
        $service = app(PaymentService::class);

        $r1 = $service->verify($payment, $first);
        $this->assertFalse($r1['verified']);
        $this->assertSame('awaiting_second_verifier', $r1['status']);

        $this->expectException(ValidationException::class); // same person again
        try {
            $service->verify($payment->refresh(), $first);
        } finally {
            $this->assertSame('pending_verification', $payment->refresh()->status);
        }
    }

    public function test_second_verifier_completes_verification(): void
    {
        $payment = $this->claim(20_000_000);
        $service = app(PaymentService::class);
        $service->verify($payment, $this->userWith());
        $r2 = $service->verify($payment->refresh(), $this->userWith());

        $this->assertTrue($r2['verified']);
        $this->assertSame('verified', $payment->refresh()->status);
    }

    public function test_gateway_confirmation_verifies_immediately(): void
    {
        $result = app(PaymentService::class)->verify($this->claim(90_000_000), null);

        $this->assertTrue($result['verified']);
    }
}
