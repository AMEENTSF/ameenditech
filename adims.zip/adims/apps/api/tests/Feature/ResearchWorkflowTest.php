<?php

namespace Tests\Feature;

use App\Models\Contact;
use App\Models\Invoice;
use App\Services\ResearchWorkflowService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Validation\ValidationException;
use Tests\TestCase;

class ResearchWorkflowTest extends TestCase
{
    use RefreshDatabase;

    public function test_project_cannot_skip_stages_or_start_without_deposit(): void
    {
        $svc = app(ResearchWorkflowService::class);
        $user = $this->userWith(['research.projects.close']);
        $client = Contact::create(['first_name' => 'Client', 'last_name' => 'One']);

        $project = $svc->open(['client_contact_id' => $client->id, 'title' => 'Household survey', 'scope' => 'Design and analysis'], $user);
        $this->assertStringStartsWith('ADM-RES-', $project->reference);

        $project = $svc->advance($project, $user); // enquiry -> scope
        $project = $svc->advance($project, $user); // -> quotation (scope present)

        $svc->quote($project, 50_000_000, 'Full scope', $user);
        $project = $svc->advance($project, $user); // -> client_acceptance
        $svc->acceptQuote($project->quotes()->first(), $user);
        $project->refresh();
        $this->assertSame(25_000_000, $project->deposit_kobo); // configurable 50%

        $project = $svc->advance($project, $user); // -> deposit

        try {
            $svc->advance($project, $user); // -> execution without paid deposit
            $this->fail('Execution must be blocked until the deposit is paid.');
        } catch (ValidationException $e) {
            $this->assertArrayHasKey('stage', $e->errors());
        }

        Invoice::create(['number' => 'INV-D', 'contact_id' => $client->id, 'billable_type' => 'research_project', 'billable_id' => $project->id,
            'status' => 'partially_paid', 'total_kobo' => 50_000_000, 'paid_kobo' => 25_000_000]);

        $this->assertSame('execution', $svc->advance($project, $user)->stage);
    }
}
