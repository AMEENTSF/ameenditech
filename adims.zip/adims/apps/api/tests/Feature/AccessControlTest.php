<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class AccessControlTest extends TestCase
{
    use RefreshDatabase;

    public function test_guests_are_rejected(): void
    {
        $this->getJson('/api/v1/organisations')->assertUnauthorized();
        $this->getJson('/api/v1/finance/invoices')->assertUnauthorized();
    }

    public function test_permission_is_enforced_on_the_server(): void
    {
        Sanctum::actingAs($this->userWith(['crm.organisations.view']));

        $this->getJson('/api/v1/organisations')->assertOk();
        $this->postJson('/api/v1/organisations', ['name' => 'Acme'])->assertForbidden();
        $this->getJson('/api/v1/finance/invoices')->assertForbidden();
    }

    public function test_generic_endpoint_ignores_locked_columns(): void
    {
        Sanctum::actingAs($this->userWith(['crm.enquiries.create']));
        $contact = \App\Models\Contact::create(['first_name' => 'A', 'last_name' => 'B']);

        $res = $this->postJson('/api/v1/enquiries', [
            'contact_id' => $contact->id, 'service_line' => 'research', 'subject' => 'Survey help',
            'status' => 'won', 'reference' => 'HACKED',
        ])->assertCreated();

        $this->assertSame('new', $res->json('data.status'));
        $this->assertStringStartsWith('ENQ-', $res->json('data.reference'));
    }

    public function test_privileged_role_must_enrol_mfa_before_using_protected_features(): void
    {
        Sanctum::actingAs($this->userWith(['crm.organisations.view'], mfa: true));

        $this->getJson('/api/v1/organisations')->assertForbidden();
    }

    public function test_research_projects_are_record_level_scoped(): void
    {
        $analyst = $this->userWith(['research.projects.view']);
        $client = \App\Models\Contact::create(['first_name' => 'C', 'last_name' => 'D']);
        $mine = \App\Models\ResearchProject::create(['reference' => 'ADM-RES-2026-0001', 'client_contact_id' => $client->id, 'title' => 'Mine', 'manager_id' => $analyst->id]);
        \App\Models\ResearchProject::create(['reference' => 'ADM-RES-2026-0002', 'client_contact_id' => $client->id, 'title' => 'Not mine']);

        Sanctum::actingAs($analyst);
        $titles = collect($this->getJson('/api/v1/research/projects')->assertOk()->json('data'))->pluck('title');

        $this->assertEquals(['Mine'], $titles->all());
        $this->getJson('/api/v1/research/projects/' . ($mine->id + 1))->assertNotFound();
    }
}
