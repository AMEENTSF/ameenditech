<?php

namespace Tests\Feature;

use App\Enums\ApprovalStatus;
use App\Models\Contact;
use App\Models\Expense;
use App\Models\User;
use App\Services\ApprovalService;
use App\Support\Money;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Validation\ValidationException;
use Tests\TestCase;

class ApprovalServiceTest extends TestCase
{
    use RefreshDatabase;

    private function user(string $email): User
    {
        $contact = Contact::create(['first_name' => 'T', 'last_name' => $email]);

        return User::create([
            'contact_id' => $contact->id,
            'email' => $email,
            'password' => 'password-not-used',
        ]);
    }

    private function expense(User $requester, int $kobo): Expense
    {
        return Expense::create([
            'reference' => 'EXP-' . uniqid(),
            'requested_by' => $requester->id,
            'description' => 'Test',
            'amount_kobo' => $kobo,
        ]);
    }

    public function test_amount_at_threshold_needs_one_approval(): void
    {
        $service = app(ApprovalService::class);
        $this->assertSame(1, $service->requiredApprovalsFor(Money::fromKobo(10_000_000)));
    }

    public function test_amount_above_threshold_needs_two_approvals(): void
    {
        $service = app(ApprovalService::class);
        $this->assertSame(2, $service->requiredApprovalsFor(Money::fromKobo(10_000_001)));
    }

    public function test_two_distinct_approvers_are_required_above_threshold(): void
    {
        $service = app(ApprovalService::class);
        $requester = $this->user('req@example.test');
        $a = $this->user('a@example.test');
        $b = $this->user('b@example.test');

        $request = $service->request($this->expense($requester, 20_000_000), $requester, Money::fromKobo(20_000_000));

        $request = $service->approve($request, $a);
        $this->assertSame(ApprovalStatus::Pending, $request->status);

        $request = $service->approve($request, $b);
        $this->assertSame(ApprovalStatus::Approved, $request->status);
    }

    public function test_same_approver_cannot_approve_twice(): void
    {
        $service = app(ApprovalService::class);
        $requester = $this->user('req@example.test');
        $a = $this->user('a@example.test');

        $request = $service->request($this->expense($requester, 20_000_000), $requester, Money::fromKobo(20_000_000));
        $service->approve($request, $a);

        $this->expectException(ValidationException::class);
        $service->approve($request, $a);
    }

    public function test_requester_cannot_approve_own_request(): void
    {
        $service = app(ApprovalService::class);
        $requester = $this->user('req@example.test');

        $request = $service->request($this->expense($requester, 20_000_000), $requester, Money::fromKobo(20_000_000));

        $this->expectException(ValidationException::class);
        $service->approve($request, $requester);
    }
}
