<?php

namespace Tests\Feature;

use App\Models\Account;
use App\Models\AccountCategory;
use App\Models\BankAccount;
use App\Models\Expense;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/** The ₦100,000 rule, exercised through the real HTTP endpoints (no service shortcuts). */
class ExpenseApprovalFlowTest extends TestCase
{
    use RefreshDatabase;

    private function chart(): BankAccount
    {
        $cat = AccountCategory::create(['name' => 'A', 'kind' => 'asset']);
        $exp = AccountCategory::create(['name' => 'E', 'kind' => 'expense']);
        $bank = Account::create(['code' => '1010', 'name' => 'Bank', 'account_category_id' => $cat->id]);
        Account::create(['code' => '5000', 'name' => 'General', 'account_category_id' => $exp->id]);

        return BankAccount::create(['name' => 'Main', 'account_id' => $bank->id]);
    }

    public function test_expense_above_threshold_needs_two_distinct_approvers_before_it_can_be_paid(): void
    {
        $bank = $this->chart();
        $requester = $this->userWith(['finance.expenses.create', 'finance.expenses.approve']);
        $a = $this->userWith(['finance.expenses.approve']);
        $b = $this->userWith(['finance.expenses.approve']);
        $payer = $this->userWith(['finance.payments.record']);

        Sanctum::actingAs($requester);
        $id = $this->postJson('/api/v1/finance/expenses', ['description' => 'Laptops', 'amount_kobo' => 10_000_001])->assertCreated()->json('data.id');
        $approvalId = \App\Models\ApprovalRequest::where('subject_id', $id)->value('id');

        // Requester cannot approve their own request.
        $this->postJson("/api/v1/approvals/{$approvalId}/approve")->assertStatus(422);

        Sanctum::actingAs($a);
        $this->postJson("/api/v1/approvals/{$approvalId}/approve")->assertOk()->assertJson(['status' => 'pending']);
        // Same approver twice is refused.
        $this->postJson("/api/v1/approvals/{$approvalId}/approve")->assertStatus(422);

        // Paying after one approval fails.
        Sanctum::actingAs($payer);
        $this->postJson("/api/v1/finance/expenses/{$id}/pay", ['bank_account_id' => $bank->id])->assertStatus(422);

        Sanctum::actingAs($b);
        $this->postJson("/api/v1/approvals/{$approvalId}/approve")->assertOk()->assertJson(['status' => 'approved']);
        $this->assertSame('approved', Expense::find($id)->status);

        Sanctum::actingAs($payer);
        $this->postJson("/api/v1/finance/expenses/{$id}/pay", ['bank_account_id' => $bank->id])->assertOk();
        $this->assertSame('paid', Expense::find($id)->status);
    }

    public function test_expense_at_threshold_needs_only_one_approver(): void
    {
        $this->chart();
        Sanctum::actingAs($this->userWith(['finance.expenses.create']));
        $id = $this->postJson('/api/v1/finance/expenses', ['description' => 'Stationery', 'amount_kobo' => 10_000_000])->json('data.id');

        Sanctum::actingAs($this->userWith(['finance.expenses.approve']));
        $approvalId = \App\Models\ApprovalRequest::where('subject_id', $id)->value('id');
        $this->postJson("/api/v1/approvals/{$approvalId}/approve")->assertOk()->assertJson(['status' => 'approved']);
    }

    public function test_user_without_the_subject_permission_cannot_approve(): void
    {
        Sanctum::actingAs($this->userWith(['finance.expenses.create']));
        $id = $this->postJson('/api/v1/finance/expenses', ['description' => 'X', 'amount_kobo' => 500])->json('data.id');
        $approvalId = \App\Models\ApprovalRequest::where('subject_id', $id)->value('id');

        // Holds a procurement approval right but not the finance one.
        Sanctum::actingAs($this->userWith(['procurement.requests.approve']));
        $this->postJson("/api/v1/approvals/{$approvalId}/approve")->assertForbidden();
    }
}
