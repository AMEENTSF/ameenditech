<?php

namespace Tests;

use App\Models\Contact;
use App\Models\Permission;
use App\Models\Role;
use App\Models\User;
use Illuminate\Foundation\Testing\TestCase as BaseTestCase;

abstract class TestCase extends BaseTestCase
{
    /** Create an active user holding exactly the given permission slugs through a throwaway role. */
    protected function userWith(array $permissions = [], string $email = null, bool $mfa = false): User
    {
        $email ??= 'u' . uniqid() . '@example.test';
        $contact = Contact::create(['first_name' => 'Test', 'last_name' => 'User', 'email' => $email]);
        $user = User::create(['contact_id' => $contact->id, 'email' => $email, 'password' => 'Correct-Horse-9!battery']);

        if ($permissions) {
            $role = Role::create(['slug' => 'r' . uniqid(), 'name' => 'Role ' . uniqid(), 'requires_mfa' => $mfa]);
            foreach ($permissions as $slug) {
                $perm = Permission::firstOrCreate(['slug' => $slug], ['module' => explode('.', $slug)[0]]);
                $role->permissions()->attach($perm->id);
            }
            $user->roles()->attach($role->id);
        }

        return $user;
    }
}
