<?php

use Illuminate\Support\Facades\Schedule;

Schedule::command('adims:flag-overdue')->dailyAt('01:00')->timezone('Africa/Lagos');
Schedule::command('adims:care-plan-reminders')->dailyAt('07:00')->timezone('Africa/Lagos');
Schedule::command('adims:class-reminders')->dailyAt('18:00')->timezone('Africa/Lagos');
