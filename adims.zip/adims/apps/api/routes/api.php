<?php

use App\Http\Controllers\Admin;
use App\Http\Controllers\ApprovalController;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\CertificateVerificationController;
use App\Http\Controllers\CrmController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Finance;
use App\Http\Controllers\Governance\DocumentController;
use App\Http\Controllers\HR\StaffController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\PortalController;
use App\Http\Controllers\Procurement;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\ResourceController;
use App\Http\Controllers\Research;
use App\Http\Controllers\Services\DigitalServicesController;
use App\Http\Controllers\Training;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| ADIMS API v1
|--------------------------------------------------------------------------
| Authorisation is enforced here (permission middleware) and again inside services for rules that
| depend on data (record-level access, approver != requester, stage gates). The UI hides menu items
| for convenience only.
*/

Route::prefix('v1')->group(function () {
    // ---------- Public (throttled) ----------
    Route::get('certificates/verify/{number}', CertificateVerificationController::class)->middleware('throttle:20,1');
    Route::get('public/courses', [Training\AdmissionController::class, 'catalogue'])->middleware('throttle:60,1');
    Route::post('public/applications', [Training\AdmissionController::class, 'apply'])->middleware('throttle:5,1');
    Route::post('public/enquiries', [CrmController::class, 'publicEnquiry'])->middleware('throttle:5,1');
    Route::post('webhooks/paystack', Finance\PaystackWebhookController::class);

    Route::post('auth/login', [AuthController::class, 'login'])->middleware('throttle:login');
    Route::post('auth/forgot-password', [AuthController::class, 'forgotPassword'])->middleware('throttle:5,1');
    Route::post('auth/reset-password', [AuthController::class, 'resetPassword'])->middleware('throttle:5,1');

    // ---------- Authenticated ----------
    Route::middleware(['auth:sanctum', 'throttle:api'])->group(function () {
        Route::post('auth/logout', [AuthController::class, 'logout']);
        Route::get('auth/me', [AuthController::class, 'me']);
        Route::post('auth/change-password', [AuthController::class, 'changePassword']);
        Route::post('auth/mfa/setup', [AuthController::class, 'mfaSetup']);
        Route::post('auth/mfa/confirm', [AuthController::class, 'mfaConfirm']);
        Route::get('auth/sessions', [AuthController::class, 'sessions']);
        Route::delete('auth/sessions/{tokenId}', [AuthController::class, 'revokeToken']);

        Route::get('notifications', [NotificationController::class, 'index']);
        Route::post('notifications/read-all', [NotificationController::class, 'markAllRead']);
        Route::post('notifications/{id}/read', [NotificationController::class, 'markRead']);

        // Client and learner self-service (scoped to the user's own contact inside the controller)
        Route::prefix('portal')->group(function () {
            Route::get('overview', [PortalController::class, 'overview']);
            Route::post('payments', [PortalController::class, 'claimPayment']);
            Route::post('quotations/{quotation}/accept', [PortalController::class, 'acceptQuotation']);
            Route::post('milestones/{milestone}/decision', [PortalController::class, 'approveMilestone']);
            Route::post('tickets', [PortalController::class, 'openTicket']);
            Route::post('feedback', [PortalController::class, 'feedback']);
        });

        // Dashboard and reports
        Route::get('dashboard/executive', [DashboardController::class, 'executive'])->middleware('permission:dashboard.executive.view');
        Route::get('reports', [ReportController::class, 'catalogue'])->middleware('permission:reports.view');
        Route::get('reports/{slug}', [ReportController::class, 'show'])->middleware('permission:reports.view');

        // Approvals (subject-specific permission is checked inside the controller)
        Route::get('approvals/pending', [ApprovalController::class, 'pending']);
        Route::post('approvals/{approvalRequest}/approve', [ApprovalController::class, 'approve']);
        Route::post('approvals/{approvalRequest}/reject', [ApprovalController::class, 'reject']);

        // Administration
        Route::middleware('permission:admin.users.manage')->group(function () {
            Route::get('admin/users', [Admin\UserController::class, 'index']);
            Route::post('admin/users', [Admin\UserController::class, 'store']);
            Route::put('admin/users/{user}/roles', [Admin\UserController::class, 'updateRoles']);
            Route::post('admin/users/{user}/status', [Admin\UserController::class, 'setStatus']);
        });
        Route::middleware('permission:admin.roles.manage')->group(function () {
            Route::get('admin/roles', [Admin\RoleController::class, 'index']);
            Route::get('admin/permissions', [Admin\RoleController::class, 'permissions']);
            Route::post('admin/roles', [Admin\RoleController::class, 'store']);
            Route::put('admin/roles/{role}', [Admin\RoleController::class, 'update']);
            Route::delete('admin/roles/{role}', [Admin\RoleController::class, 'destroy']);
        });
        Route::get('admin/audit-logs', [Admin\AuditLogController::class, 'index'])->middleware('permission:admin.audit.view');
        Route::middleware('permission:admin.settings.manage')->group(function () {
            Route::get('admin/settings', [Admin\SettingsController::class, 'index']);
            Route::put('admin/settings', [Admin\SettingsController::class, 'update']);
        });

        // CRM workflows
        Route::post('crm/enquiries/{enquiry}/status', [CrmController::class, 'updateEnquiryStatus'])->middleware('permission:crm.enquiries.update');
        Route::post('crm/enquiries/{enquiry}/convert', [CrmController::class, 'convert'])->middleware('permission:crm.enquiries.update');
        Route::post('crm/quotations/{quotation}/send', [CrmController::class, 'sendQuotation'])->middleware('permission:crm.quotations.create');
        Route::post('crm/quotations/{quotation}/revise', [CrmController::class, 'reviseQuotation'])->middleware('permission:crm.quotations.create');

        // Research
        Route::prefix('research')->group(function () {
            Route::get('projects', [Research\ResearchProjectController::class, 'index'])->middleware('permission:research.projects.view');
            Route::get('projects/{id}', [Research\ResearchProjectController::class, 'show'])->middleware('permission:research.projects.view');
            Route::post('projects', [Research\ResearchProjectController::class, 'store'])->middleware('permission:research.projects.create');
            Route::put('projects/{id}', [Research\ResearchProjectController::class, 'update'])->middleware('permission:research.projects.update');
            Route::post('projects/{id}/advance', [Research\ResearchProjectController::class, 'advance'])->middleware('permission:research.projects.update');
            Route::post('projects/{id}/quotes', [Research\ResearchProjectController::class, 'quote'])->middleware('permission:research.projects.update');
            Route::post('quotes/{quote}/accept', [Research\ResearchProjectController::class, 'acceptQuote'])->middleware('permission:research.projects.update');
            Route::post('projects/{project}/datasets', [Research\DatasetController::class, 'store'])->middleware('permission:research.datasets.upload');
            Route::get('projects/{project}/datasets/{dataset}/download', [Research\DatasetController::class, 'download'])->middleware('permission:research.datasets.download');
            Route::post('projects/{project}/deliverables', [Research\DeliverableController::class, 'store'])->middleware('permission:research.deliverables.create');
            Route::post('deliverables/{deliverable}/review', [Research\DeliverableController::class, 'review'])->middleware('permission:research.deliverables.review');
            Route::post('deliverables/{deliverable}/deliver', [Research\DeliverableController::class, 'deliver'])->middleware('permission:research.deliverables.deliver');
            Route::get('deliverables/{deliverable}/download', [Research\DeliverableController::class, 'download'])->middleware('permission:research.deliverables.view');
        });

        // Training
        Route::prefix('training')->group(function () {
            Route::post('applications/{application}/decision', [Training\AdmissionController::class, 'decide'])->middleware('permission:training.applications.decide');
            Route::post('applications/{application}/enrol', [Training\AdmissionController::class, 'enrol'])->middleware('permission:training.enrolments.manage');
            Route::post('sessions/{session}/attendance', [Training\LearningController::class, 'recordAttendance'])->middleware('permission:training.attendance.record');
            Route::get('enrolments/{enrolment}/completion', [Training\LearningController::class, 'completion'])->middleware('permission:training.enrolments.view');
            Route::post('enrolments/{enrolment}/certificate', [Training\LearningController::class, 'issueCertificate'])->middleware('permission:training.certificates.issue');
            Route::post('certificates/{certificate}/revoke', [Training\LearningController::class, 'revokeCertificate'])->middleware('permission:training.certificates.revoke');
        });

        // Digital services
        Route::prefix('services')->group(function () {
            Route::post('projects/{project}/transition', [DigitalServicesController::class, 'transition'])->middleware('permission:services.projects.update');
            Route::post('milestones/{milestone}/submit', [DigitalServicesController::class, 'submitMilestone'])->middleware('permission:services.projects.update');
            Route::post('tickets/{ticket}/replies', [DigitalServicesController::class, 'replyToTicket'])->middleware('permission:services.tickets.update');
            Route::post('tickets/{ticket}/transition', [DigitalServicesController::class, 'transitionTicket'])->middleware('permission:services.tickets.update');
            Route::post('care-plans/{plan}/renew', [DigitalServicesController::class, 'renewCarePlan'])->middleware('permission:services.care_plans.manage');
        });

        // Finance
        Route::prefix('finance')->group(function () {
            Route::get('invoices', [Finance\InvoiceController::class, 'index'])->middleware('permission:finance.invoices.view');
            Route::get('invoices/{invoice}', [Finance\InvoiceController::class, 'show'])->middleware('permission:finance.invoices.view');
            Route::post('invoices', [Finance\InvoiceController::class, 'store'])->middleware('permission:finance.invoices.create');
            Route::post('invoices/{invoice}/issue', [Finance\InvoiceController::class, 'issue'])->middleware('permission:finance.invoices.update');
            Route::post('invoices/{invoice}/void', [Finance\InvoiceController::class, 'void'])->middleware('permission:finance.invoices.update');

            Route::get('payments', [Finance\PaymentController::class, 'index'])->middleware('permission:finance.payments.view');
            Route::post('payments', [Finance\PaymentController::class, 'store'])->middleware('permission:finance.payments.record');
            Route::post('payments/{payment}/verify', [Finance\PaymentController::class, 'verify'])->middleware('permission:finance.payments.verify');
            Route::post('payments/{payment}/reject', [Finance\PaymentController::class, 'reject'])->middleware('permission:finance.payments.verify');
            Route::post('payments/{payment}/allocate', [Finance\PaymentController::class, 'allocate'])->middleware('permission:finance.payments.record');

            Route::get('expenses', [Finance\ExpenseController::class, 'index'])->middleware('permission:finance.expenses.view,finance.expenses.create');
            Route::post('expenses', [Finance\ExpenseController::class, 'store'])->middleware('permission:finance.expenses.create');
            Route::post('expenses/{expense}/pay', [Finance\ExpenseController::class, 'pay'])->middleware('permission:finance.payments.record');
        });

        // HR
        Route::post('hr/leave', [StaffController::class, 'requestLeave'])->middleware('permission:hr.leave.create');
        Route::post('hr/leave/{leave}/decision', [StaffController::class, 'decideLeave'])->middleware('permission:hr.leave.approve');
        Route::post('hr/staff/{staff}/deactivate', [StaffController::class, 'deactivate'])->middleware('permission:hr.staff.manage');

        // Procurement and assets
        Route::prefix('procurement')->group(function () {
            Route::post('requests/{purchaseRequest}/submit', [Procurement\ProcurementController::class, 'submitRequest'])->middleware('permission:procurement.requests.create');
            Route::post('requests/{purchaseRequest}/order', [Procurement\ProcurementController::class, 'createOrder'])->middleware('permission:procurement.orders.create');
            Route::post('orders/{order}/submit', [Procurement\ProcurementController::class, 'submitOrder'])->middleware('permission:procurement.orders.create');
            Route::post('orders/{order}/send', [Procurement\ProcurementController::class, 'sendOrder'])->middleware('permission:procurement.orders.create');
            Route::post('orders/{order}/receive', [Procurement\ProcurementController::class, 'receiveGoods'])->middleware('permission:procurement.orders.create');
            Route::post('supplier-invoices/{invoice}/submit', [Procurement\ProcurementController::class, 'submitSupplierInvoice'])->middleware('permission:finance.invoices.create');
            Route::post('inventory/{item}/movements', [Procurement\ProcurementController::class, 'stockMovement'])->middleware('permission:procurement.assets.manage');
            Route::post('assets/{asset}/assign', [Procurement\AssetController::class, 'assign'])->middleware('permission:procurement.assets.manage');
            Route::post('assets/{asset}/return', [Procurement\AssetController::class, 'return'])->middleware('permission:procurement.assets.manage');
            Route::post('assets/{asset}/transfer', [Procurement\AssetController::class, 'transfer'])->middleware('permission:procurement.assets.manage');
            Route::post('assets/{asset}/dispose', [Procurement\AssetController::class, 'dispose'])->middleware('permission:procurement.assets.manage');
        });

        // Governance
        Route::get('governance/documents', [DocumentController::class, 'index'])->middleware('permission:governance.documents.view');
        Route::post('governance/documents', [DocumentController::class, 'store'])->middleware('permission:governance.documents.manage');
        Route::get('governance/documents/{document}/download/{version?}', [DocumentController::class, 'download'])->middleware('permission:governance.documents.view');

        // Generic CRUD for plain reference/operational tables. Permissions, rules and locked columns
        // come from config/resources.php; workflow-heavy tables are read-only here.
        Route::pattern('resource', 'organisations|enquiries|opportunities|communications|customer-notes|customer-feedback|quotations|research-projects|datasets|project-quotes|project-tasks|project-team-members|survey-forms|survey-versions|field-assignments|survey-submissions|deliverables|quality-reviews|project-feedback|courses|course-categories|course-prerequisites|course-modules|cohorts|cohort-instructors|rooms|class-sessions|applications|enrolments|enrolment-instalments|attendance-records|laptop-allocations|learning-resources|assignments|assessments|assessment-results|assignment-submissions|certificates|alumni-records|service-catalogue|service-projects|service-tasks|milestones|support-tickets|ticket-replies|care-plans|care-plan-renewals|account-categories|accounts|expense-categories|bank-accounts|journal-entries|journal-entry-lines|reconciliations|petty-cash-entries|supplier-invoices|departments|job-titles|staff-profiles|employment-contracts|leave-types|leave-requests|staff-assignments|performance-reviews|staff-training-records|staff-attendance|payroll-inputs|suppliers|purchase-requests|purchase-orders|purchase-order-lines|goods-receipts|goods-receipt-lines|inventory-items|stock-movements|assets|asset-movements|maintenance-records|documents|document-versions|board-meetings|consents|risks|compliance-items|incidents|notification-templates|notifications|integration-events');
        Route::get('{resource}', [ResourceController::class, 'index']);
        Route::get('{resource}/{id}', [ResourceController::class, 'show'])->whereNumber('id');
        Route::post('{resource}', [ResourceController::class, 'store']);
        Route::put('{resource}/{id}', [ResourceController::class, 'update'])->whereNumber('id');
        Route::delete('{resource}/{id}', [ResourceController::class, 'destroy'])->whereNumber('id');
    });
});
