<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<style>
  body { font-family: DejaVu Sans, sans-serif; font-size: 10px; color: #111827; }
  h1 { font-size: 16px; margin: 0 0 2px; color: #0b5cab; }
  .meta { color: #6b7280; margin-bottom: 12px; }
  table { width: 100%; border-collapse: collapse; }
  th { text-align: left; background: #eef4fb; border-bottom: 1px solid #0b5cab; padding: 5px 6px; }
  td { padding: 4px 6px; border-bottom: 1px solid #e5e7eb; }
  tr:nth-child(even) td { background: #fafafa; }
</style>
</head>
<body>
  <h1>Ameen Digitech Ltd</h1>
  <div class="meta">{{ $title }} · generated {{ $generated }} (Africa/Lagos)</div>
  <table>
    <thead><tr>@foreach ($headers as $h)<th>{{ $h }}</th>@endforeach</tr></thead>
    <tbody>
    @foreach ($rows as $row)<tr>@foreach ($row as $cell)<td>{{ $cell }}</td>@endforeach</tr>@endforeach
    </tbody>
  </table>
</body>
</html>
