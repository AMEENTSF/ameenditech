import AsyncStorage from "@react-native-async-storage/async-storage";
import { post } from "@/services/api";

/**
 * Offline-safe drafts for NON-FINANCIAL workflows only (class attendance). Entries are kept on the
 * device until the API confirms them. Money, approvals and payments are never queued offline.
 */
export interface AttendanceDraft {
  sessionId: number;
  records: { enrolment_id: number; status: "present" | "absent" | "late" | "excused" }[];
  savedAt: string;
}

const KEY = "adims.attendance.drafts";

async function load(): Promise<AttendanceDraft[]> {
  const raw = await AsyncStorage.getItem(KEY);
  return raw ? (JSON.parse(raw) as AttendanceDraft[]) : [];
}

export async function saveDraft(d: AttendanceDraft) {
  const rest = (await load()).filter((x) => x.sessionId !== d.sessionId);
  await AsyncStorage.setItem(KEY, JSON.stringify([...rest, d]));
}

export const pendingDrafts = load;

/** Re-sending is safe: the API upserts one row per session and learner. */
export async function syncDrafts(): Promise<{ sent: number; failed: number }> {
  const drafts = await load();
  const remaining: AttendanceDraft[] = [];
  let sent = 0;

  for (const d of drafts) {
    try {
      await post(`/training/sessions/${d.sessionId}/attendance`, { records: d.records });
      sent++;
    } catch {
      remaining.push(d);
    }
  }

  await AsyncStorage.setItem(KEY, JSON.stringify(remaining));
  return { sent, failed: remaining.length };
}
