import { create } from "zustand";
import { api, post, tokenStore } from "@/services/api";

export interface Me {
  id: number;
  email: string;
  name: string | null;
  roles: { slug: string; name: string }[];
  permissions: string[];
}

interface AuthState {
  me: Me | null;
  ready: boolean;
  signIn: (email: string, password: string, otp?: string) => Promise<{ mfaRequired?: boolean }>;
  restore: () => Promise<void>;
  signOut: () => Promise<void>;
  can: (permission: string) => boolean;
}

export const useAuth = create<AuthState>((set, get) => ({
  me: null,
  ready: false,

  async restore() {
    try {
      if (await tokenStore.get()) set({ me: (await api<{ user: Me }>("/auth/me")).user });
    } catch {
      await tokenStore.clear();
    } finally {
      set({ ready: true });
    }
  },

  async signIn(email, password, otp) {
    try {
      const res = await post<{ token: string; user: Me }>("/auth/login", { email, password, otp, device_name: "ADIMS mobile" });
      await tokenStore.set(res.token);
      set({ me: res.user });
      return {};
    } catch (e: unknown) {
      const err = e as { body?: { mfa_required?: boolean } };
      if (err.body?.mfa_required) return { mfaRequired: true };
      throw e;
    }
  },

  async signOut() {
    await post("/auth/logout").catch(() => undefined);
    await tokenStore.clear();
    set({ me: null });
  },

  can: (p) => !!get().me && (get().me!.permissions.includes("*") || get().me!.permissions.includes(p)),
}));
