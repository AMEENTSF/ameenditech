import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Alert, FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { api, post } from "@/services/api";

interface Pending { id: number; subject_type: string; amount_kobo: number; required_approvals: number; decisions: { decision: string }[] }

const naira = (k: number) => `₦${Math.trunc(k / 100).toLocaleString("en-NG")}.${String(k % 100).padStart(2, "0")}`;

/** Approvals are online-only on purpose: the server enforces the two-approver rule and must see each decision live. */
export default function Approvals() {
  const qc = useQueryClient();
  const { data, refetch, isFetching } = useQuery({ queryKey: ["approvals"], queryFn: () => api<{ data: Pending[] }>("/approvals/pending") });

  async function approve(p: Pending) {
    try {
      const r = await post<{ status: string; approvals_recorded: number; approvals_required: number }>(`/approvals/${p.id}/approve`);
      Alert.alert(r.status === "pending" ? `Recorded (${r.approvals_recorded}/${r.approvals_required})` : `Request ${r.status}`);
      qc.invalidateQueries({ queryKey: ["approvals"] });
    } catch (e) {
      Alert.alert("Could not approve", (e as Error).message);
    }
  }

  return (
    <FlatList
      contentContainerStyle={{ padding: 20, gap: 10 }}
      data={data?.data ?? []}
      refreshing={isFetching}
      onRefresh={refetch}
      keyExtractor={(p) => String(p.id)}
      ListEmptyComponent={<Text style={{ padding: 20 }}>Nothing is waiting for you.</Text>}
      renderItem={({ item }) => (
        <View style={s.card}>
          <Text style={s.title}>{item.subject_type.replace(/_/g, " ")} · {naira(item.amount_kobo)}</Text>
          <Text>{item.decisions.filter((d) => d.decision === "approved").length} of {item.required_approvals} approvals</Text>
          <Pressable style={s.btn} onPress={() => approve(item)} accessibilityRole="button"><Text style={s.btnText}>Approve</Text></Pressable>
        </View>
      )}
    />
  );
}

const s = StyleSheet.create({
  card: { backgroundColor: "#fff", borderRadius: 10, padding: 14, gap: 6, borderWidth: 1, borderColor: "#e2e8f0" },
  title: { fontWeight: "600", textTransform: "capitalize" },
  btn: { backgroundColor: "#186350", borderRadius: 8, padding: 10, alignItems: "center", marginTop: 6 },
  btnText: { color: "#fff", fontWeight: "600" },
});
