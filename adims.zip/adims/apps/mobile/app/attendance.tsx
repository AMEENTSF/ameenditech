import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Alert, FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { api } from "@/services/api";
import { pendingDrafts, saveDraft, syncDrafts, type AttendanceDraft } from "@/features/attendance/draftQueue";

type Status = AttendanceDraft["records"][number]["status"];
interface Row { id: number; contact: { first_name: string; last_name: string } }

/**
 * Register for one class session. Works offline: the register is saved on the device and sent
 * when a connection is available. Re-sending is idempotent on the server.
 */
export default function Attendance() {
  const sessionId = 1; // chosen from the timetable list in a full build; kept explicit here
  const [marks, setMarks] = useState<Record<number, Status>>({});
  const [pending, setPending] = useState(0);
  const { data } = useQuery({ queryKey: ["roster", sessionId], queryFn: () => api<{ data: Row[] }>(`/enrolments?filter[status]=enrolled&per_page=100`) });

  useEffect(() => { pendingDrafts().then((d) => setPending(d.length)); }, []);

  async function save() {
    const records = Object.entries(marks).map(([id, status]) => ({ enrolment_id: Number(id), status }));
    if (!records.length) return;
    await saveDraft({ sessionId, records, savedAt: new Date().toISOString() });
    const res = await syncDrafts();
    setPending(res.failed);
    Alert.alert(res.failed ? "Saved on this device" : "Attendance sent", res.failed ? "It will be sent when you are back online." : undefined);
  }

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        contentContainerStyle={{ padding: 20, gap: 8 }}
        data={data?.data ?? []}
        keyExtractor={(r) => String(r.id)}
        renderItem={({ item }) => (
          <View style={s.row}>
            <Text style={{ flex: 1 }}>Learner #{item.id}</Text>
            {(["present", "late", "absent"] as Status[]).map((st) => (
              <Pressable key={st} onPress={() => setMarks({ ...marks, [item.id]: st })} accessibilityRole="button" accessibilityState={{ selected: marks[item.id] === st }}
                style={[s.chip, marks[item.id] === st && s.chipOn]}><Text style={marks[item.id] === st ? { color: "#fff" } : undefined}>{st}</Text></Pressable>
            ))}
          </View>
        )}
      />
      <Pressable onPress={save} style={s.save} accessibilityRole="button"><Text style={s.saveText}>Save register{pending ? ` (${pending} waiting to sync)` : ""}</Text></Pressable>
    </View>
  );
}

const s = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#fff", borderRadius: 10, padding: 10, borderWidth: 1, borderColor: "#e2e8f0" },
  chip: { borderWidth: 1, borderColor: "#cbd5e1", borderRadius: 14, paddingHorizontal: 10, paddingVertical: 4 },
  chipOn: { backgroundColor: "#186350", borderColor: "#186350" },
  save: { backgroundColor: "#186350", padding: 16, alignItems: "center" },
  saveText: { color: "#fff", fontWeight: "600" },
});
