import { useState } from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { useAuth } from "@/store/auth";

export default function Login() {
  const signIn = useAuth((s) => s.signIn);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [needsOtp, setNeedsOtp] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true);
    setError(null);
    try {
      const r = await signIn(email.trim(), password, needsOtp ? otp : undefined);
      if (r.mfaRequired) setNeedsOtp(true);
    } catch {
      setError("Sign in failed. Check your details and try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <View style={s.wrap}>
      <Text style={s.title}>ADIMS</Text>
      <TextInput style={s.input} placeholder="Email" autoCapitalize="none" keyboardType="email-address" textContentType="username" value={email} onChangeText={setEmail} accessibilityLabel="Email" />
      <TextInput style={s.input} placeholder="Password" secureTextEntry textContentType="password" value={password} onChangeText={setPassword} accessibilityLabel="Password" />
      {needsOtp && <TextInput style={s.input} placeholder="6-digit code" keyboardType="number-pad" maxLength={6} value={otp} onChangeText={setOtp} accessibilityLabel="Authentication code" />}
      {error && <Text accessibilityRole="alert" style={s.error}>{error}</Text>}
      <Pressable style={s.button} onPress={submit} disabled={busy} accessibilityRole="button">
        {busy ? <ActivityIndicator color="#fff" /> : <Text style={s.buttonText}>{needsOtp ? "Verify and sign in" : "Sign in"}</Text>}
      </Pressable>
    </View>
  );
}

const s = StyleSheet.create({
  wrap: { flex: 1, justifyContent: "center", padding: 24, gap: 12, backgroundColor: "#f7f8f9" },
  title: { fontSize: 28, fontWeight: "700", color: "#134e40", marginBottom: 12 },
  input: { backgroundColor: "#fff", borderWidth: 1, borderColor: "#cbd5e1", borderRadius: 8, padding: 12, fontSize: 16 },
  button: { backgroundColor: "#186350", borderRadius: 8, padding: 14, alignItems: "center" },
  buttonText: { color: "#fff", fontWeight: "600", fontSize: 16 },
  error: { color: "#b91c1c" },
});
