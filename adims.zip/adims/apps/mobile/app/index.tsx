import { useQuery } from "@tanstack/react-query";
import { Link } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { api } from "@/services/api";
import { useAuth } from "@/store/auth";

function kobo(v: number) {
  const abs = Math.abs(v);
  return `${v < 0 ? "-" : ""}₦${Math.trunc(abs / 100).toLocaleString("en-NG")}.${String(abs % 100).padStart(2, "0")}`;
}

export default function Home() {
  const { me, can, signOut } = useAuth();
  const staff = can("dashboard.executive.view");
  const { data } = useQuery({
    enabled: !!me,
    queryKey: ["portal"],
    queryFn: () => api<{ invoices: { id: number; number: string; total_kobo: number; paid_kobo: number }[]; enrolments: { id: number; cohort: { name: string; course: { title: string } } }[] }>("/portal/overview"),
  });

  return (
    <ScrollView contentContainerStyle={s.wrap}>
      <Text style={s.h1}>Hello{me?.name ? `, ${me.name.split(" ")[0]}` : ""}</Text>

      <View style={s.card}>
        {can("finance.expenses.approve") || can("finance.payments.verify") ? (
          <Link href="/approvals" asChild><Pressable style={s.row} accessibilityRole="link"><Text style={s.rowText}>Pending approvals</Text></Pressable></Link>
        ) : null}
        {can("training.attendance.record") ? (
          <Link href="/attendance" asChild><Pressable style={s.row} accessibilityRole="link"><Text style={s.rowText}>Take attendance</Text></Pressable></Link>
        ) : null}
      </View>

      {!staff && data && (
        <>
          <Text style={s.h2}>My courses</Text>
          {data.enrolments.map((e) => <View key={e.id} style={s.card}><Text>{e.cohort.course.title} · {e.cohort.name}</Text></View>)}
          <Text style={s.h2}>Invoices</Text>
          {data.invoices.map((i) => <View key={i.id} style={s.card}><Text>{i.number}: {kobo(i.total_kobo - i.paid_kobo)} due</Text></View>)}
        </>
      )}

      <Pressable onPress={signOut} style={s.link} accessibilityRole="button"><Text style={{ color: "#186350" }}>Sign out</Text></Pressable>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  wrap: { padding: 20, gap: 12 },
  h1: { fontSize: 22, fontWeight: "700", marginTop: 40 },
  h2: { fontSize: 16, fontWeight: "600", marginTop: 12 },
  card: { backgroundColor: "#fff", borderRadius: 10, padding: 14, borderWidth: 1, borderColor: "#e2e8f0" },
  row: { paddingVertical: 12 },
  rowText: { fontSize: 16 },
  link: { alignSelf: "flex-start", paddingVertical: 12 },
});
