import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack, useRouter, useSegments } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { useEffect } from "react";
import { useAuth } from "@/store/auth";

const client = new QueryClient();

export default function RootLayout() {
  const { me, ready, restore } = useAuth();
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => { restore(); }, [restore]);

  useEffect(() => {
    if (!ready) return;
    const inAuth = segments[0] === "login";
    if (!me && !inAuth) router.replace("/login");
    if (me && inAuth) router.replace("/");
  }, [me, ready, segments, router]);

  return (
    <QueryClientProvider client={client}>
      <StatusBar style="auto" />
      <Stack screenOptions={{ headerShown: false }} />
    </QueryClientProvider>
  );
}
