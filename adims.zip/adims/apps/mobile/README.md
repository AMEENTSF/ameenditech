# ADIMS Mobile (Expo)

Staff, learner and client companion app. React Native + Expo Router + TypeScript.

- Auth: bearer token from `/auth/login` with `device_name`; stored in SecureStore (keychain/keystore).
- Online-only by design: approvals, payments, anything involving money.
- Offline-safe drafts: class attendance (`features/attendance/draftQueue.ts`), synced idempotently.
- Push notifications: `expo-notifications` is installed; register the device token with a `push` channel driver on the API (see `docs/developer-guides/notifications.md`).

```bash
cd apps/mobile && npm install && npx expo start
```
Set the API URL in `app.json` (`extra.apiUrl`).
