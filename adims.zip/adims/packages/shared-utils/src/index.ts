/** Canonical money helpers. Money is integer kobo everywhere; never use floats for arithmetic. */
export type Kobo = number;

export function formatKobo(kobo: Kobo): string {
  const abs = Math.abs(kobo);
  return `${kobo < 0 ? "-" : ""}₦${Math.trunc(abs / 100).toLocaleString("en-NG")}.${String(abs % 100).padStart(2, "0")}`;
}

export function nairaToKobo(input: string): Kobo | null {
  const m = input.replace(/[,\s₦]/g, "").match(/^(\d+)(?:\.(\d{1,2}))?$/);
  return m ? Number(m[1]) * 100 + Number((m[2] ?? "").padEnd(2, "0") || 0) : null;
}

/** Basis points: 5000 = 50%. Rounds half up, integer maths only. */
export function percentOfBasisPoints(kobo: Kobo, basisPoints: number): Kobo {
  return Math.floor((kobo * basisPoints + 5000) / 10000);
}

export const LAGOS_TZ = "Africa/Lagos";
