/** Money is always integer kobo on the wire. */
export type Kobo = number;

export type ApprovalStatus = "pending" | "approved" | "rejected" | "cancelled";

export type ResearchStage =
  | "enquiry" | "scope" | "quotation" | "client_acceptance" | "deposit"
  | "execution" | "quality_review" | "client_delivery" | "balance_payment"
  | "feedback" | "closed";

export interface ApprovalProgress {
  status: ApprovalStatus;
  approvals_recorded: number;
  approvals_required: number;
}

export type InvoiceStatus = "draft" | "issued" | "partially_paid" | "paid" | "void";
export type PaymentStatus = "pending_verification" | "verified" | "rejected";
export type ExpenseStatus = "pending_approval" | "approved" | "rejected" | "paid";
export type ServiceLine = "research" | "training" | "digital_services" | "other";

export interface Paginated<T> {
  data: T[];
  current_page: number;
  last_page: number;
  total: number;
  per_page: number;
}
