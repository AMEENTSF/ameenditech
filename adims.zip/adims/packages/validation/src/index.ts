import { z } from "zod";

/** Client-side schemas mirror the API rules for fast feedback. The API remains the authority. */
export const kobo = z.number().int().min(0);

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
  otp: z.string().regex(/^\d{6}$/).optional(),
});

export const passwordSchema = z
  .string()
  .min(12, "At least 12 characters")
  .regex(/[a-z]/, "Add a lowercase letter")
  .regex(/[A-Z]/, "Add an uppercase letter")
  .regex(/\d/, "Add a number")
  .regex(/[^A-Za-z0-9]/, "Add a symbol");

export const invoiceLineSchema = z.object({
  description: z.string().min(1).max(255),
  quantity: z.number().int().min(1),
  unit_price_kobo: z.number().int().min(1),
});

export const invoiceSchema = z.object({
  contact_id: z.number().int(),
  due_on: z.string().date().optional(),
  lines: z.array(invoiceLineSchema).min(1).max(100),
});

export const expenseSchema = z.object({
  description: z.string().min(1).max(255),
  amount_kobo: z.number().int().min(1),
  incurred_on: z.string().date().optional(),
});

export const enquirySchema = z.object({
  first_name: z.string().min(1).max(100),
  last_name: z.string().min(1).max(100),
  email: z.string().email(),
  phone: z.string().max(30).optional(),
  service_line: z.enum(["research", "training", "digital_services", "other"]),
  subject: z.string().min(1).max(255),
  message: z.string().max(5000).optional(),
  consent: z.literal(true),
});
