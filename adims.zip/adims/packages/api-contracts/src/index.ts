/** Endpoint paths shared by web and mobile. Keep in step with apps/api/routes/api.php and docs/api/openapi.yaml. */
export const endpoints = {
  login: "/auth/login",
  me: "/auth/me",
  logout: "/auth/logout",
  dashboard: "/dashboard/executive",
  approvalsPending: "/approvals/pending",
  approve: (id: number) => `/approvals/${id}/approve`,
  reject: (id: number) => `/approvals/${id}/reject`,
  portalOverview: "/portal/overview",
  reports: (slug: string) => `/reports/${slug}`,
  certificateVerify: (n: string) => `/certificates/verify/${encodeURIComponent(n)}`,
  recordAttendance: (sessionId: number) => `/training/sessions/${sessionId}/attendance`,
} as const;

export interface ApprovalOutcome {
  status: "pending" | "approved" | "rejected";
  approvals_recorded?: number;
  approvals_required?: number;
}
