/** Single source of truth for brand values used by web (Tailwind) and mobile (StyleSheet). Contrast ratios against white are AA or better for text tokens. */
export const colors = {
  brand: { 50: "#eef6f3", 100: "#d4eae2", 500: "#1f7a63", 600: "#186350", 700: "#134e40", 900: "#0b2d26" },
  accent: { blue: "#0b5cab" },
  surface: "#f7f8f9",
  text: { primary: "#0f172a", secondary: "#475569" },
  danger: "#b91c1c",
  warning: "#b45309",
} as const;

export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24 } as const;
export const radius = { sm: 6, md: 8, lg: 12 } as const;
