# Roles, permissions and access control

Authorisation is enforced on the server. Hiding a menu item in the web or mobile app is cosmetic; every API route checks a permission, and data-dependent rules (record ownership, approver ≠ requester, stage gates) are re-checked inside services.

## How access is decided

1. **Permission slug** `module.resource.action`, for example `finance.expenses.approve`. Roles are bundles of slugs; a user can hold several roles and gets the union.
2. **Route middleware** `permission:slug[,slug]` (`RequirePermission`) on every protected route. Users in a role flagged `requires_mfa` are refused until MFA is enrolled.
3. **Generic CRUD** (`ResourceController`) derives `view/create/update/delete` from `config/resources.php`. Workflow tables are read-only there and changed only through dedicated endpoints.
4. **Record-level rules**: research projects (`research.projects.view_all` or manager/team member only), expenses (own requests unless approver), client and learner portal (always scoped to the signed-in contact), restricted documents (`governance.documents.manage`).
5. **Approval rules** (`ApprovalService`): requester cannot approve; one decision per approver; above the threshold (default ₦100,000, setting `finance.dual_approval_threshold_kobo`) two distinct approvers are required. Applies to expenses, supplier invoices, purchase requests/orders and manual payment verification.
6. **Administrators** can create roles and edit permissions at `/admin/roles`; system roles cannot be deleted and `super-administrator` cannot be edited or left without a holder.

## Default roles

| Role | MFA required | Starting permission patterns |
|---|---|---|
| Super Administrator (`super-administrator`) | yes | `*` |
| Managing Director (`managing-director`) | yes | `dashboard.*`, `finance.*`, `reports.*`, `research.projects.view`, `research.projects.view_all`, `training.courses.view`, `training.certificates.view`, `services.projects.view`, `crm.contacts.view`, `hr.staff.view`, `governance.*` |
| Director / Board-level User (`director`) | no | `dashboard.executive.view`, `finance.reports.view`, `reports.view`, `governance.documents.view`, `governance.risks.view` |
| Operations Manager (`operations-manager`) | no | `dashboard.executive.view`, `reports.view`, `research.projects.*`, `services.*`, `procurement.*`, `training.courses.view`, `crm.contacts.view`, `hr.leave.approve`, `hr.leave.create` |
| Research Manager (`research-manager`) | no | `research.*`, `reports.view`, `crm.contacts.view`, `crm.enquiries.*`, `crm.quotations.*` |
| Research Analyst (`research-analyst`) | no | `research.projects.view`, `research.datasets.view`, `research.datasets.upload`, `research.deliverables.view`, `research.deliverables.create` |
| Field Supervisor (`field-supervisor`) | no | `research.projects.view`, `research.datasets.view` |
| Enumerator (`enumerator`) | no | none (portal only) |
| Training Manager (`training-manager`) | no | `training.*`, `reports.view`, `crm.contacts.view` |
| Instructor (`instructor`) | no | `training.courses.view`, `training.attendance.*`, `training.assessments.*` |
| Learner (`learner`) | no | none (portal only) |
| Digital Services Manager (`digital-services-manager`) | no | `services.*`, `reports.view`, `crm.contacts.view`, `crm.enquiries.*`, `crm.quotations.*` |
| Designer / Developer (`designer-developer`) | no | `services.projects.view`, `services.projects.update`, `services.tickets.*` |
| Finance Manager (`finance-manager`) | yes | `finance.*`, `reports.*`, `dashboard.executive.view`, `procurement.requests.approve` |
| Accountant (`accountant`) | yes | `finance.invoices.*`, `finance.payments.*`, `finance.expenses.view`, `finance.expenses.create`, `finance.reports.*`, `finance.bank.*`, `reports.view`, `reports.export` |
| Human Resources Officer (`hr-officer`) | no | `hr.*`, `reports.view` |
| Procurement Officer (`procurement-officer`) | no | `procurement.*` |
| Administrative Officer (`administrative-officer`) | no | `crm.*`, `governance.documents.view`, `hr.leave.create` |
| Client (`client`) | no | none (portal only) |
| External Partner (`external-partner`) | no | none (portal only) |

Enumerators, learners, clients and external partners hold no staff permissions: they use the mobile/portal endpoints, which only return their own records.

## Permission catalogue

**admin**: `admin.audit.view`, `admin.roles.manage`, `admin.settings.create`, `admin.settings.delete`, `admin.settings.manage`, `admin.settings.update`, `admin.settings.view`, `admin.users.manage`, `admin.users.view`

**crm**: `crm.contacts.create`, `crm.contacts.delete`, `crm.contacts.update`, `crm.contacts.view`, `crm.enquiries.create`, `crm.enquiries.delete`, `crm.enquiries.update`, `crm.enquiries.view`, `crm.organisations.create`, `crm.organisations.delete`, `crm.organisations.update`, `crm.organisations.view`, `crm.quotations.approve`, `crm.quotations.create`, `crm.quotations.delete`, `crm.quotations.update`, `crm.quotations.view`

**dashboard**: `dashboard.executive.view`

**finance**: `finance.accounts.create`, `finance.accounts.delete`, `finance.accounts.update`, `finance.accounts.view`, `finance.bank.create`, `finance.bank.delete`, `finance.bank.reconcile`, `finance.bank.update`, `finance.bank.view`, `finance.expenses.approve`, `finance.expenses.create`, `finance.expenses.delete`, `finance.expenses.update`, `finance.expenses.view`, `finance.invoices.approve`, `finance.invoices.create`, `finance.invoices.delete`, `finance.invoices.export`, `finance.invoices.update`, `finance.invoices.view`, `finance.invoices.void`, `finance.payments.record`, `finance.payments.verify`, `finance.payments.view`, `finance.reports.export`, `finance.reports.view`

**governance**: `governance.documents.create`, `governance.documents.delete`, `governance.documents.manage`, `governance.documents.update`, `governance.documents.view`, `governance.incidents.create`, `governance.incidents.delete`, `governance.incidents.update`, `governance.incidents.view`, `governance.risks.create`, `governance.risks.delete`, `governance.risks.manage`, `governance.risks.update`, `governance.risks.view`

**hr**: `hr.leave.approve`, `hr.leave.create`, `hr.leave.delete`, `hr.leave.update`, `hr.leave.view`, `hr.reviews.create`, `hr.reviews.delete`, `hr.reviews.manage`, `hr.reviews.update`, `hr.reviews.view`, `hr.staff.create`, `hr.staff.delete`, `hr.staff.manage`, `hr.staff.update`, `hr.staff.view`

**procurement**: `procurement.assets.create`, `procurement.assets.delete`, `procurement.assets.manage`, `procurement.assets.update`, `procurement.assets.view`, `procurement.orders.create`, `procurement.orders.delete`, `procurement.orders.update`, `procurement.orders.view`, `procurement.requests.approve`, `procurement.requests.create`, `procurement.requests.delete`, `procurement.requests.update`, `procurement.requests.view`

**reports**: `reports.export`, `reports.view`

**research**: `research.datasets.download`, `research.datasets.upload`, `research.datasets.view`, `research.deliverables.create`, `research.deliverables.delete`, `research.deliverables.deliver`, `research.deliverables.review`, `research.deliverables.update`, `research.deliverables.view`, `research.projects.assign`, `research.projects.close`, `research.projects.create`, `research.projects.delete`, `research.projects.update`, `research.projects.view`, `research.projects.view_all`

**services**: `services.care_plans.create`, `services.care_plans.delete`, `services.care_plans.manage`, `services.care_plans.update`, `services.care_plans.view`, `services.projects.create`, `services.projects.delete`, `services.projects.update`, `services.projects.view`, `services.tickets.create`, `services.tickets.delete`, `services.tickets.update`, `services.tickets.view`

**training**: `training.applications.create`, `training.applications.decide`, `training.applications.delete`, `training.applications.update`, `training.applications.view`, `training.assessments.create`, `training.assessments.delete`, `training.assessments.grade`, `training.assessments.update`, `training.assessments.view`, `training.attendance.create`, `training.attendance.delete`, `training.attendance.record`, `training.attendance.update`, `training.attendance.view`, `training.certificates.issue`, `training.certificates.revoke`, `training.certificates.view`, `training.courses.create`, `training.courses.delete`, `training.courses.manage`, `training.courses.update`, `training.courses.view`, `training.enrolments.create`, `training.enrolments.delete`, `training.enrolments.manage`, `training.enrolments.update`, `training.enrolments.view`
