# User guides by role

**Everyone**: sign in, enrol MFA (required for privileged roles), view notifications under the bell icon.

**Managing Director / Executive**: Dashboard shows live figures from records; Management > Approvals for pending decisions; Reports for export (CSV/XLSX/PDF).

**Finance (Accountant / Finance Manager)**: raise invoices, record and verify payments, submit expenses. Expenses and manual payment verifications above the threshold need two different approvers. A receipt upload does not confirm payment.

**Research team**: projects get a unique reference; deposit must be paid before work starts; a second reader approves before delivery; balance must be paid before final release. Confidential datasets are never public.

**Training**: manage courses, cohorts, admissions, attendance and assessments; issue certificates, which can be verified publicly at /verify showing approved fields only.

**HR**: staff profiles, leave, attendance. **Procurement/Inventory**: purchase requests/orders, goods receipts, assets. **Governance**: documents, policies, risks.

**Clients / Learners (portal)**: see only your own projects, invoices, enrolments and certificates.
