# Developer guide

## Schema generator
`tools/schema/schema.py` is the single DSL describing tables. `python tools/schema/generate.py` regenerates migrations, models, `config/resources.php`, the ERD and the permission catalogue. It is idempotent and skips existing models, so hand-written models are safe.

## Adding a module
1. Add tables to the DSL and regenerate.
2. Registry-driven CRUD is exposed automatically through `ResourceController` (permissions `<slug>.view|create|update|delete`).
3. Add workflow logic in `app/Services`, a dedicated controller for non-CRUD actions, and routes in `routes/api.php` guarded by `RequirePermission`.
4. Add permissions to `PermissionSeeder` and assign them in `RoleSeeder`.
5. Add the web page under `apps/web/src/app/(dashboard)/` and navigation in `constants/navigation.ts`.

## Non-negotiable rules
- Money is integer kobo everywhere; format only at the UI edge (`lib/money.ts`).
- Approvals go through `ApprovalService`; the requester can never approve; above the threshold two distinct approvers are needed.
- An uploaded receipt is never proof of payment: only gateway confirmation or a verified manual entry creates a payment.
- Dashboard numbers come from queries on real records, never constants.
- Authorisation is enforced on the backend; hiding UI is cosmetic.

## Notifications
Templates live in `notification_templates`; `NotificationService` queues per-channel drivers. Add a driver by implementing the channel interface and registering it in `config/adims.php`.

## Testing
```bash
cd apps/api && php artisan test
cd apps/web && npm run typecheck && npm test
```
Tests: approval service, expense flow, access control, payment verification, research workflow, money rules.
