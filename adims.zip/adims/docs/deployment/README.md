# Deployment guide

## Local / staging (Docker)
```bash
cp .env.example .env          # set strong passwords and APP_KEY
./infrastructure/scripts/setup.sh
```
`setup.sh` builds containers, layers the Laravel skeleton in (`bootstrap-api.sh`), migrates, seeds roles/permissions/chart of accounts and creates the first administrator from `ADMIN_EMAIL` / `ADMIN_PASSWORD` (12+ characters, only when no users exist).

## Production checklist
- **TLS**: terminate at Nginx/Caddy/load balancer; set `APP_URL`, `SANCTUM_STATEFUL_DOMAINS`, `SESSION_SECURE_COOKIE=true`.
- **Env**: `APP_ENV=production`, `APP_DEBUG=false`; never commit `.env`.
- **Database**: managed PostgreSQL, daily backups plus PITR; test restores quarterly.
- **Audit log immutability**: run `REVOKE UPDATE, DELETE ON audit_logs FROM <app_user>;` so the application role can only INSERT.
- **Storage**: S3-compatible bucket, private, no public ACL. Files are served only through 5-minute signed URLs. Enable server-side encryption and versioning.
- **Queue and scheduler**: run `php artisan queue:work redis --tries=3` under Supervisor/systemd and `* * * * * php artisan schedule:run` in cron.
- **Payments**: set `PAYSTACK_SECRET_KEY`; point the Paystack webhook to `/api/webhooks/paystack` (HMAC-SHA512 verified, idempotent).
- **Notifications**: mail works via SMTP; SMS/WhatsApp/push are log-driver placeholders until a provider driver is added.
- **MFA**: privileged roles are blocked until TOTP is enrolled; enrol admins before go-live.
- **Migrations**: `php artisan migrate --force` in the release step; take a backup first.

## Backups and recovery
Database dump + object storage versioning. Record RPO/RTO targets with the client; rehearse a restore from a clean environment.

## Monitoring
Ship Laravel logs to a central store, alert on failed jobs, webhook signature failures and repeated login lockouts.
