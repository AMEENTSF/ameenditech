# Architecture overview

ADIMS is an API-first, modular monolith: one Laravel API, one Next.js web app, one Expo mobile app, and shared TypeScript packages. One PostgreSQL database, Redis for queue and cache, S3-compatible private object storage.

```mermaid
flowchart LR
  Web[Next.js web] -->|session cookie + XSRF| API
  Mobile[Expo mobile] -->|bearer token, SecureStore| API
  Public[Public forms and certificate check] --> API
  Gateway[Payment gateway] -->|signed webhook| API
  API[Laravel API] --> PG[(PostgreSQL)]
  API --> Redis[(Redis: queue, cache)]
  API --> S3[(Private object storage)]
  API --> Channels[Email, SMS, WhatsApp, push drivers]
```

## Backend layering (`apps/api/app`)

| Layer | Responsibility |
|---|---|
| `Http/Controllers` | Validate input, call a service, return JSON. Grouped by module (Finance, Research, Training, Procurement, HR, Services, Governance, Admin). |
| `Services` | Business rules that must hold regardless of caller: `ApprovalService`, `PaymentService`, `ResearchWorkflowService`, `EnrolmentService`, `JournalService`, `CarePlanService`, `NotificationService`, `DashboardService`, `ReportService`. |
| `Models` | Eloquent models and relations (generated for plain tables, hand-written where behaviour matters). |
| `Support` | `Money` (integer kobo), channel drivers, report exporter. |
| `Listeners` / `Events` | `ApprovalResolved` moves the approved subject to its next state. |
| `Jobs` | `DeliverNotification` (queued, retried, status tracked). |
| `Console/Commands` | Scheduled: overdue flags, care-plan renewals, class reminders. |
| `config/resources.php` | Generated registry for generic CRUD (permissions, rules, locked columns). |

`Actions`, `DTOs`, `Repositories`, `Policies` folders are kept from the starting architecture for growth; the current code puts rules in services and permission checks in middleware and the registry.

## Key design decisions

- **One person model.** `contacts` holds every person (customer, learner, staff, partner); `users` is an optional login linked 1:1. No duplicated identity tables.
- **Money is integer kobo** end to end. Display formatting only at the edge. Postgres `CHECK` constraints back the important invariants (non-negative amounts, balanced journal lines, paid ≤ total).
- **Double-entry ledger.** Issuing an invoice, applying a payment and paying an expense each post a balanced journal entry through `JournalService`; the profit-and-loss report reads from the ledger.
- **A transfer receipt is not a payment.** Portal uploads create a `pending_verification` claim. Only staff verification (two verifiers above the threshold) or a signature-checked gateway webhook marks it verified; only verified payments can be allocated to invoices.
- **Workflows are state machines with gates**, not free-text status fields. Status columns are locked against generic CRUD.
- **Confidential files** (datasets, deliverables, receipts, documents) use the private disk under random keys and are served only as 5-minute signed URLs after a permission check, with an audit entry.
- **Audit trail** is append-only (`AuditLog` blocks update/delete in the model; revoke UPDATE/DELETE on the table for the app DB role in production).
- **Settings** (threshold, deposit %, attendance and pass marks, ledger account codes) live in `system_settings`, with `config/adims.php` as the fallback, so the business can change rules without a deploy.

## Frontend (`apps/web/src`)

`app/` routes (public, auth, dashboard groups), `features/` per module logic, `components/` shared UI, `constants/modules.ts` drives permission-filtered module pages (tabs, tables, create forms) so a new list screen is configuration, not new code. API access is in `lib/api-client.ts` (cookie + XSRF) and `services/`.
