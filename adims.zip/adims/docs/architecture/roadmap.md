# Roadmap

## Implemented (unexecuted, statically checked)
All 12 modules at API level, RBAC for 20 roles, dual approval, double-entry ledger, research state machine, MFA, web pages, mobile shell, docs.

## Next
1. Run migrations and tests on PostgreSQL; fix any findings.
2. Mobile attendance: real session picker and scoped roster.
3. SMS/WhatsApp/push provider drivers.
4. Bank reconciliation UI; ODK/survey sync; phone verification.
5. Playwright end-to-end tests; load testing; security review/pen test.
