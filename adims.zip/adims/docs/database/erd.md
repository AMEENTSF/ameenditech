# Entity Relationship Diagram

Generated from `tools/schema/schema.py`. Core identity, finance control and platform tables are in the first four migrations; every other table has one migration in `apps/api/database/migrations/2026_02_01_*`.

Design rules: one `contacts` row per person (customer, learner, staff, partner) linked 1:1 to an optional `users` login; money is integer kobo; deletes are `RESTRICT` for business records and `CASCADE` only for owned child rows.

## Core and finance control
```mermaid
erDiagram
  contacts ||--o| users : "login"
  organisations ||--o{ contacts : employs
  users }o--o{ roles : user_roles
  roles }o--o{ permissions : role_permissions
  contacts ||--o{ invoices : billed
  invoices ||--o{ invoice_lines : has
  payments ||--o{ payment_allocations : allocated
  invoices ||--o{ payment_allocations : settled_by
  approval_requests ||--o{ approval_decisions : decided_by
```

## Crm

```mermaid
erDiagram
  users ||--o| organisations : created_by
  contacts ||--o{ enquiries : contact_id
  organisations ||--o| enquiries : organisation_id
  users ||--o| enquiries : assigned_to
  enquiries ||--o{ opportunities : enquiry_id
  users ||--o| opportunities : owner_id
  contacts ||--o{ communications : contact_id
  users ||--o| communications : logged_by
  contacts ||--o{ customer_notes : contact_id
  users ||--o| customer_notes : author_id
  contacts ||--o{ customer_feedback : contact_id
  contacts ||--o{ quotations : contact_id
  enquiries ||--o| quotations : enquiry_id
  users ||--o| quotations : created_by
```

| Table | Columns | Deletion behaviour |
|---|---|---|
| `organisations` (soft delete) | name, type, registration_number, email, phone, address, state, website, category, created_by | created_by: set null |
| `enquiries` | reference, contact_id, organisation_id, service_line, subject, message, source, status, assigned_to, converted_at, follow_up_at | contact_id: restrict; organisation_id: set null; assigned_to: set null |
| `opportunities` | enquiry_id, title, value_kobo, stage, expected_close_on, owner_id | enquiry_id: cascade; owner_id: set null |
| `communications` | contact_id, channel, direction, subject, body, logged_by, occurred_at, follow_up_at, follow_up_done | contact_id: cascade; logged_by: set null |
| `customer_notes` | contact_id, body, author_id | contact_id: cascade; author_id: set null |
| `customer_feedback` | contact_id, subject_type, subject_id, rating, comment | contact_id: cascade |
| `quotations` | number, contact_id, enquiry_id, service_line, title, total_kobo, status, revision, valid_until, accepted_at, created_by, lines | contact_id: restrict; enquiry_id: set null; created_by: set null |

## Research

```mermaid
erDiagram
  contacts ||--o{ research_projects : client_contact_id
  users ||--o| research_projects : manager_id
  research_projects ||--o{ datasets : research_project_id
  files ||--o{ datasets : file_id
  research_projects ||--o{ project_quotes : research_project_id
  users ||--o| project_quotes : created_by
  research_projects ||--o{ project_tasks : research_project_id
  users ||--o| project_tasks : assignee_id
  research_projects ||--o{ project_team_members : research_project_id
  users ||--o{ project_team_members : user_id
  research_projects ||--o{ survey_forms : research_project_id
  survey_forms ||--o{ survey_versions : survey_form_id
  files ||--o| survey_versions : file_id
  users ||--o| survey_versions : created_by
  survey_versions ||--o{ field_assignments : survey_version_id
  users ||--o{ field_assignments : enumerator_id
  users ||--o| field_assignments : supervisor_id
  field_assignments ||--o{ survey_submissions : field_assignment_id
  research_projects ||--o{ deliverables : research_project_id
  files ||--o| deliverables : file_id
  users ||--o| deliverables : created_by
  deliverables ||--o{ quality_reviews : deliverable_id
  users ||--o{ quality_reviews : reviewer_id
  research_projects ||--o{ project_feedback : research_project_id
  contacts ||--o| project_feedback : contact_id
```

| Table | Columns | Deletion behaviour |
|---|---|---|
| `research_projects` | reference, client_contact_id, title, scope, stage, quoted_kobo, deposit_basis_points, deposit_kobo, manager_id, due_on, closed_at | client_contact_id: restrict; manager_id: set null |
| `datasets` | research_project_id, file_id, label, classification | research_project_id: cascade; file_id: restrict |
| `project_quotes` | research_project_id, revision, amount_kobo, scope_summary, status, accepted_at, created_by | research_project_id: cascade; created_by: set null |
| `project_tasks` | research_project_id, title, description, status, phase, assignee_id, due_on, completed_at | research_project_id: cascade; assignee_id: set null |
| `project_team_members` | research_project_id, user_id, project_role | research_project_id: cascade; user_id: cascade |
| `survey_forms` | research_project_id, title, odk_form_id, status | research_project_id: cascade |
| `survey_versions` | survey_form_id, version, definition, file_id, published_at, created_by | survey_form_id: cascade; file_id: set null; created_by: set null |
| `field_assignments` | survey_version_id, enumerator_id, supervisor_id, area, target_count, status | survey_version_id: cascade; enumerator_id: restrict; supervisor_id: set null |
| `survey_submissions` | field_assignment_id, external_id, payload, status, collected_at, synced_at, gps_accuracy | field_assignment_id: cascade |
| `deliverables` | research_project_id, title, version, file_id, status, created_by, delivered_at | research_project_id: cascade; file_id: set null; created_by: set null |
| `quality_reviews` | deliverable_id, reviewer_id, outcome, comments, reviewed_at | deliverable_id: cascade; reviewer_id: restrict |
| `project_feedback` | research_project_id, contact_id, rating, comment | research_project_id: cascade; contact_id: set null |

## Training

```mermaid
erDiagram
  courses ||--o{ course_prerequisites : course_id
  courses ||--o{ course_prerequisites : prerequisite_course_id
  courses ||--o{ course_modules : course_id
  courses ||--o{ cohorts : course_id
  cohorts ||--o{ cohort_instructors : cohort_id
  users ||--o{ cohort_instructors : user_id
  cohorts ||--o{ class_sessions : cohort_id
  course_modules ||--o| class_sessions : course_module_id
  rooms ||--o| class_sessions : room_id
  users ||--o| class_sessions : instructor_id
  contacts ||--o{ applications : contact_id
  courses ||--o{ applications : course_id
  cohorts ||--o| applications : cohort_id
  users ||--o| applications : decided_by
  cohorts ||--o{ enrolments : cohort_id
  contacts ||--o{ enrolments : contact_id
  enrolments ||--o{ enrolment_instalments : enrolment_id
  invoices ||--o| enrolment_instalments : invoice_id
  class_sessions ||--o{ attendance_records : class_session_id
  enrolments ||--o{ attendance_records : enrolment_id
  users ||--o| attendance_records : recorded_by
  cohorts ||--o{ laptop_allocations : cohort_id
  enrolments ||--o{ laptop_allocations : enrolment_id
  assets ||--o{ laptop_allocations : asset_id
  course_modules ||--o{ learning_resources : course_module_id
  files ||--o| learning_resources : file_id
  cohorts ||--o{ assignments : cohort_id
  cohorts ||--o{ assessments : cohort_id
  assessments ||--o{ assessment_results : assessment_id
  enrolments ||--o{ assessment_results : enrolment_id
  users ||--o| assessment_results : graded_by
  assignments ||--o{ assignment_submissions : assignment_id
  enrolments ||--o{ assignment_submissions : enrolment_id
  files ||--o| assignment_submissions : file_id
  enrolments ||--o{ certificates : enrolment_id
  users ||--o| certificates : issued_by
  contacts ||--o{ alumni_records : contact_id
  enrolments ||--o| alumni_records : enrolment_id
```

| Table | Columns | Deletion behaviour |
|---|---|---|
| `courses` | slug, title, description, fee_kobo, duration_weeks, status | - |
| `course_categories` | name, description | - |
| `course_prerequisites` | course_id, prerequisite_course_id | course_id: cascade; prerequisite_course_id: cascade |
| `course_modules` | course_id, title, outline, position, hours | course_id: cascade |
| `cohorts` | course_id, name, starts_on, ends_on, capacity | course_id: restrict |
| `cohort_instructors` | cohort_id, user_id | cohort_id: cascade; user_id: cascade |
| `rooms` | name, capacity, location | - |
| `class_sessions` | cohort_id, course_module_id, room_id, instructor_id, starts_at, ends_at, topic, status | cohort_id: cascade; course_module_id: set null; room_id: set null; instructor_id: set null |
| `applications` | reference, contact_id, course_id, cohort_id, status, statement, decided_by, decided_at, decision_note | contact_id: restrict; course_id: restrict; cohort_id: set null; decided_by: set null |
| `enrolments` | cohort_id, contact_id, status | cohort_id: restrict; contact_id: restrict |
| `enrolment_instalments` | enrolment_id, invoice_id, sequence, amount_kobo, due_on, status | enrolment_id: cascade; invoice_id: set null |
| `attendance_records` | class_session_id, enrolment_id, status, recorded_by, recorded_at | class_session_id: cascade; enrolment_id: cascade; recorded_by: set null |
| `laptop_allocations` | cohort_id, enrolment_id, asset_id, allocated_on, returned_on | cohort_id: cascade; enrolment_id: cascade; asset_id: restrict |
| `learning_resources` | course_module_id, title, kind, file_id, url, published | course_module_id: cascade; file_id: set null |
| `assignments` | cohort_id, title, instructions, due_at, max_score | cohort_id: cascade |
| `assessments` | cohort_id, title, kind, max_score, weight_percent, held_at | cohort_id: cascade |
| `assessment_results` | assessment_id, enrolment_id, score, feedback, graded_by, graded_at | assessment_id: cascade; enrolment_id: cascade; graded_by: set null |
| `assignment_submissions` | assignment_id, enrolment_id, file_id, notes, score, submitted_at | assignment_id: cascade; enrolment_id: cascade; file_id: set null |
| `certificates` | enrolment_id, verification_number, issued_at, issued_by, revoked_at | enrolment_id: restrict; issued_by: set null |
| `alumni_records` | contact_id, enrolment_id, current_employer, current_role, open_to_mentoring, consent_to_contact | contact_id: restrict; enrolment_id: set null |

## Services

```mermaid
erDiagram
  contacts ||--o{ service_projects : contact_id
  service_catalogue ||--o| service_projects : service_catalogue_id
  quotations ||--o| service_projects : quotation_id
  users ||--o| service_projects : project_manager_id
  service_projects ||--o{ service_tasks : service_project_id
  users ||--o| service_tasks : assignee_id
  service_projects ||--o{ milestones : service_project_id
  contacts ||--o| milestones : approved_by_contact_id
  contacts ||--o{ support_tickets : contact_id
  service_projects ||--o| support_tickets : service_project_id
  care_plans ||--o| support_tickets : care_plan_id
  users ||--o| support_tickets : assignee_id
  support_tickets ||--o{ ticket_replies : support_ticket_id
  users ||--o| ticket_replies : author_id
  contacts ||--o{ care_plans : contact_id
  care_plans ||--o{ care_plan_renewals : care_plan_id
  invoices ||--o| care_plan_renewals : invoice_id
```

| Table | Columns | Deletion behaviour |
|---|---|---|
| `service_catalogue` | slug, name, description, category, base_price_kobo, active | - |
| `service_projects` | reference, contact_id, service_catalogue_id, quotation_id, title, status, project_manager_id, agreed_kobo, starts_on, due_on, agreement_accepted_at, completed_at | contact_id: restrict; service_catalogue_id: set null; quotation_id: set null; project_manager_id: set null |
| `service_tasks` | service_project_id, title, description, status, assignee_id, due_on | service_project_id: cascade; assignee_id: set null |
| `milestones` | service_project_id, title, due_on, amount_kobo, status, approved_by_contact_id, approved_at | service_project_id: cascade; approved_by_contact_id: set null |
| `support_tickets` | reference, contact_id, service_project_id, care_plan_id, subject, description, priority, status, assignee_id, resolved_at | contact_id: restrict; service_project_id: set null; care_plan_id: set null; assignee_id: set null |
| `ticket_replies` | support_ticket_id, author_id, body, internal | support_ticket_id: cascade; author_id: set null |
| `care_plans` | contact_id, name, tier, monthly_fee_kobo, starts_on, renews_on, status, auto_renew | contact_id: restrict |
| `care_plan_renewals` | care_plan_id, invoice_id, period_start, period_end, status, reminded_at | care_plan_id: cascade; invoice_id: set null |

## Finance

```mermaid
erDiagram
  account_categories ||--o{ accounts : account_category_id
  accounts ||--o| expense_categories : account_id
  accounts ||--o| bank_accounts : account_id
  users ||--o| journal_entries : posted_by
  journal_entries ||--o{ journal_entry_lines : journal_entry_id
  accounts ||--o{ journal_entry_lines : account_id
  bank_accounts ||--o{ reconciliations : bank_account_id
  users ||--o| reconciliations : reconciled_by
  bank_accounts ||--o{ petty_cash_entries : bank_account_id
  expenses ||--o| petty_cash_entries : expense_id
  users ||--o| petty_cash_entries : recorded_by
  suppliers ||--o{ supplier_invoices : supplier_id
  files ||--o| supplier_invoices : file_id
```

| Table | Columns | Deletion behaviour |
|---|---|---|
| `account_categories` | name, kind | - |
| `accounts` | code, name, account_category_id, parent_id, active | account_category_id: restrict; parent_id: set null |
| `expense_categories` | name, account_id, active | account_id: set null |
| `bank_accounts` | name, bank_name, account_number_last4, kind, account_id, opening_balance_kobo, active | account_id: set null |
| `journal_entries` | number, entry_date, memo, source_type, source_id, posted_by, reversed_at | posted_by: set null |
| `journal_entry_lines` | journal_entry_id, account_id, debit_kobo, credit_kobo | journal_entry_id: cascade; account_id: restrict |
| `reconciliations` | bank_account_id, period_start, period_end, statement_balance_kobo, book_balance_kobo, status, reconciled_by, reconciled_at | bank_account_id: restrict; reconciled_by: set null |
| `petty_cash_entries` | bank_account_id, description, amount_kobo, direction, expense_id, recorded_by, entry_date | bank_account_id: restrict; expense_id: set null; recorded_by: set null |
| `supplier_invoices` | number, supplier_id, total_kobo, paid_kobo, status, received_on, due_on, file_id | supplier_id: restrict; file_id: set null |

## Hr

```mermaid
erDiagram
  users ||--o| departments : head_id
  departments ||--o| job_titles : department_id
  users ||--o{ staff_profiles : user_id
  contacts ||--o{ staff_profiles : contact_id
  departments ||--o| staff_profiles : department_id
  job_titles ||--o| staff_profiles : job_title_id
  users ||--o| staff_profiles : line_manager_id
  staff_profiles ||--o{ employment_contracts : staff_profile_id
  files ||--o| employment_contracts : file_id
  staff_profiles ||--o{ leave_requests : staff_profile_id
  leave_types ||--o{ leave_requests : leave_type_id
  users ||--o| leave_requests : decided_by
  staff_profiles ||--o{ staff_assignments : staff_profile_id
  staff_profiles ||--o{ performance_reviews : staff_profile_id
  users ||--o{ performance_reviews : reviewer_id
  staff_profiles ||--o{ staff_training_records : staff_profile_id
  files ||--o| staff_training_records : file_id
  staff_profiles ||--o{ staff_attendance : staff_profile_id
  staff_profiles ||--o{ payroll_inputs : staff_profile_id
```

| Table | Columns | Deletion behaviour |
|---|---|---|
| `departments` | name, head_id | head_id: set null |
| `job_titles` | name, department_id | department_id: set null |
| `staff_profiles` | user_id, contact_id, staff_number, department_id, job_title_id, line_manager_id, employment_type, hired_on, left_on, status | user_id: restrict; contact_id: restrict; department_id: set null; job_title_id: set null; line_manager_id: set null |
| `employment_contracts` | staff_profile_id, contract_type, starts_on, ends_on, file_id, monthly_pay_kobo | staff_profile_id: cascade; file_id: set null |
| `leave_types` | name, default_days, paid | - |
| `leave_requests` | staff_profile_id, leave_type_id, starts_on, ends_on, reason, status, decided_by, decided_at | staff_profile_id: cascade; leave_type_id: restrict; decided_by: set null |
| `staff_assignments` | staff_profile_id, assignable_type, assignable_id, assignment_role, starts_on, ends_on | staff_profile_id: cascade |
| `performance_reviews` | staff_profile_id, reviewer_id, period, rating, strengths, improvement_areas, status | staff_profile_id: cascade; reviewer_id: restrict |
| `staff_training_records` | staff_profile_id, title, provider, completed_on, file_id | staff_profile_id: cascade; file_id: set null |
| `staff_attendance` | staff_profile_id, work_date, clock_in, clock_out | staff_profile_id: cascade |
| `payroll_inputs` | staff_profile_id, period, kind, label, amount_kobo, status | staff_profile_id: cascade |

## Procurement

```mermaid
erDiagram
  users ||--o{ purchase_requests : requested_by
  departments ||--o| purchase_requests : department_id
  suppliers ||--o{ purchase_orders : supplier_id
  purchase_requests ||--o| purchase_orders : purchase_request_id
  users ||--o| purchase_orders : created_by
  purchase_orders ||--o{ purchase_order_lines : purchase_order_id
  inventory_items ||--o| purchase_order_lines : inventory_item_id
  purchase_orders ||--o{ goods_receipts : purchase_order_id
  users ||--o| goods_receipts : received_by
  goods_receipts ||--o{ goods_receipt_lines : goods_receipt_id
  purchase_order_lines ||--o{ goods_receipt_lines : purchase_order_line_id
  inventory_items ||--o{ stock_movements : inventory_item_id
  users ||--o| stock_movements : recorded_by
  users ||--o| assets : assignee_id
  assets ||--o{ asset_movements : asset_id
  users ||--o| asset_movements : from_user_id
  users ||--o| asset_movements : to_user_id
  users ||--o| asset_movements : recorded_by
  assets ||--o{ maintenance_records : asset_id
```

| Table | Columns | Deletion behaviour |
|---|---|---|
| `suppliers` (soft delete) | name, email, phone, address, tax_id, status | - |
| `purchase_requests` | reference, requested_by, department_id, title, justification, estimated_kobo, status | requested_by: restrict; department_id: set null |
| `purchase_orders` | number, supplier_id, purchase_request_id, total_kobo, status, expected_on, created_by | supplier_id: restrict; purchase_request_id: set null; created_by: set null |
| `purchase_order_lines` | purchase_order_id, inventory_item_id, description, quantity, unit_price_kobo, received_quantity | purchase_order_id: cascade; inventory_item_id: set null |
| `goods_receipts` | purchase_order_id, number, received_on, received_by, notes | purchase_order_id: restrict; received_by: set null |
| `goods_receipt_lines` | goods_receipt_id, purchase_order_line_id, quantity | goods_receipt_id: cascade; purchase_order_line_id: restrict |
| `inventory_items` | sku, name, unit, quantity_on_hand, reorder_level | - |
| `stock_movements` | inventory_item_id, kind, quantity, reason, recorded_by | inventory_item_id: restrict; recorded_by: set null |
| `assets` (soft delete) | tag, name, category, serial_number, purchased_on, cost_kobo, condition, status, assignee_id, location, disposed_at, disposal_reason | assignee_id: set null |
| `asset_movements` | asset_id, kind, from_user_id, to_user_id, location, recorded_by | asset_id: cascade; from_user_id: set null; to_user_id: set null; recorded_by: set null |
| `maintenance_records` | asset_id, description, cost_kobo, performed_on, next_due_on, performed_by | asset_id: cascade |

## Governance

```mermaid
erDiagram
  users ||--o| documents : owner_id
  documents ||--o{ document_versions : document_id
  files ||--o{ document_versions : file_id
  users ||--o| document_versions : uploaded_by
  files ||--o| board_meetings : minutes_file_id
  contacts ||--o{ consents : contact_id
  users ||--o| risks : owner_id
  users ||--o| compliance_items : owner_id
  users ||--o| incidents : reported_by
```

| Table | Columns | Deletion behaviour |
|---|---|---|
| `documents` (soft delete) | title, category, confidentiality, owner_id, current_version, review_on, retain_until, status | owner_id: set null |
| `document_versions` | document_id, version, file_id, change_note, uploaded_by | document_id: cascade; file_id: restrict; uploaded_by: set null |
| `board_meetings` | title, held_at, location, agenda, minutes, minutes_file_id, status | minutes_file_id: set null |
| `consents` | contact_id, purpose, status, source, recorded_at | contact_id: restrict |
| `risks` | title, description, likelihood, impact, status, owner_id, mitigation, review_on | owner_id: set null |
| `compliance_items` | title, due_on, authority, status, owner_id | owner_id: set null |
| `incidents` | reference, title, description, severity, status, reported_by, occurred_at | reported_by: set null |

## Platform

```mermaid
erDiagram
  users ||--o| notifications : user_id
  contacts ||--o| notifications : contact_id
  notification_templates ||--o| notifications : notification_template_id
```

| Table | Columns | Deletion behaviour |
|---|---|---|
| `notification_templates` | code, channel, subject, body, active | - |
| `notifications` | user_id, contact_id, notification_template_id, channel, subject, body, status, provider_message_id, failure_reason, sent_at, read_at | user_id: set null; contact_id: set null; notification_template_id: set null |
| `integration_events` | provider, event_type, external_id, payload, status, processed_at | - |
