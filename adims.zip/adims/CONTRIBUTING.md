# Contributing

- Branch from `main`: `feature/<module>-<summary>`; open a pull request; CI must pass.
- PHP: PSR-12, strict types, Pint. TypeScript: strict mode, ESLint.
- Controllers stay thin: validate with a FormRequest, call an Action or Service, return a Resource.
- No float arithmetic on money. Use `App\Support\Money`.
- Every new permission is added to `PermissionSeeder` and documented in `docs/security/permissions.md`.
- Every state-changing endpoint writes an audit log entry.
- API calls from the web app live in `src/services`, never inside components.
- New tables need: keys, indexes, constraints, deletion behaviour, factory, and an ERD entry.
