FROM php:8.3-fpm-alpine

RUN apk add --no-cache git unzip libpq-dev icu-dev libzip-dev \
    && docker-php-ext-install pdo_pgsql intl zip bcmath pcntl \
    && apk add --no-cache --virtual .build $PHPIZE_DEPS \
    && pecl install redis && docker-php-ext-enable redis \
    && apk del .build

COPY --from=composer:2 /usr/bin/composer /usr/bin/composer

WORKDIR /var/www/html
