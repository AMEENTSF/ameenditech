#!/usr/bin/env bash
# The repository ships ADIMS's own application code, config overrides and migrations. Laravel's stock
# skeleton files (public/, artisan helpers, default config, Tests helpers) are layered underneath by
# running `composer create-project` once in a scratch directory and copying only files that are missing.
# Safe to re-run: it never overwrites an existing file.
set -euo pipefail

API=apps/api
[ -f "$API/vendor/autoload.php" ] && [ -f "$API/config/app.php" ] && exit 0

TMP=$(mktemp -d)
composer create-project laravel/laravel "$TMP/skeleton" "^12.0" --no-interaction --no-scripts
cd "$TMP/skeleton"

# Remove skeleton parts that clash with ADIMS (its own users/contacts model and auth tables).
rm -f database/migrations/0001_01_01_00000*.php app/Models/User.php database/factories/UserFactory.php \
      database/seeders/DatabaseSeeder.php tests/Feature/ExampleTest.php tests/Unit/ExampleTest.php \
      routes/web.php routes/console.php bootstrap/app.php bootstrap/providers.php app/Providers/AppServiceProvider.php \
      tests/TestCase.php composer.json phpunit.xml

cd - >/dev/null
cp -Rn "$TMP/skeleton/." "$API/"
rm -rf "$TMP"
echo "Laravel skeleton layered into $API. Now run composer install inside the api container."
