#!/usr/bin/env bash
# First-time local setup. Run from the repository root: ./infrastructure/scripts/setup.sh
set -euo pipefail

[ -f .env ] || cp .env.example .env
echo "Edit .env: set DB_PASSWORD, AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY (MinIO), ADMIN_EMAIL and ADMIN_PASSWORD, then re-run."
for v in DB_PASSWORD AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY ADMIN_EMAIL ADMIN_PASSWORD; do
  grep -Eq "^${v}=.+" .env || { echo "Missing ${v} in .env"; exit 1; }
done

bash infrastructure/scripts/bootstrap-api.sh

docker compose up -d --build postgres redis minio mailpit
docker compose run --rm api composer install --no-interaction --prefer-dist
docker compose run --rm api php artisan key:generate
docker compose up -d
docker compose exec api php artisan migrate --seed --force
docker compose exec minio sh -c 'true' >/dev/null 2>&1 || true
echo "Done. Web http://localhost:3000  API http://localhost:8080/api/v1  Mailpit http://localhost:8025"
